define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';
  class vbAfterNavigateListener extends ActionChain {
    async run(context, { event }) {
      const { $application, $constants, $variables, $functions } = context;
      await Actions.resetVariables(context, {
        variables: [
    '$variables.code',
  ],
      });

   
    }
  }


  return vbAfterNavigateListener;
});
