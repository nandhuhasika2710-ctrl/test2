define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterListener extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $application, $constants, $variables, $functions } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'pfmGateway/getClientconfig',
      });



      $variables.opaUserGroup = response.body.items[0].opa_group_name;

      $variables.objectStorageDetails.bucket = response.body.items[0].bucket_name;
      $variables.objectStorageDetails.namespace = response.body.items[0].namespace;
      $variables.objectStorageDetails.prefix = response.body.items[0].prefix;
      $variables.objectStorageDetails.json_files_folder_name = response.body.items[0].json_files_folder_name;
      $variables.objectStorageDetails.template_folder_name = response.body.items[0].template_folder_name;
      $variables.objectStorageDetails.fpn_documents_folder_name = response.body.items[0].fpn_documents_folder_name;
      $variables.objectStorageDetails.fpnAconexUploadFolderName  = response.body.items[0].fpn_aconex_upload_folder_name;
      $variables.objectStorageDetails.pfrAconexUploadFolderName = response.body.items[0].pfr_aconex_upload_folder_name;

      // added
      if (!$application.variables.code) {
        const response5 = await Actions.callRest(context, {
          endpoint: 'pfmGateway/putClientconfig',
          uriParams: {
            'external_redirect_url': $variables.currentFpnCode,
            'prepayment_number': $variables.currentPpCode,
            'pfr_code': $variables.currentPfrCode,
          },
        });
        // await $functions.getCode();
        // await $application.functions.getCode(response.body.items[0].client_id, response.body.items[0].redirect_url);
      } else {
        const response4 = await Actions.callRest(context, {
          endpoint: 'pfmGateway/getClientconfig',
        });
        $variables.sepratedPfrCode = response4.body.items[0].pfr_code;
        $variables.sepratedFPNCode = response4.body.items[0].external_redirect_url;
        $variables.sepratedPpCode = response4.body.items[0].prepayment_number;
        $variables.userProfileinput.userID = $application.user.email;
        $variables.userProfileinput.userToken = $application.variables.code;
        const responseoic = await Actions.callRest(context, {
          endpoint: 'OICService/postUserprofile',
          body: $variables.userProfileinput,
        });

        if (responseoic.body.Status && responseoic.body.Status.toUpperCase() === 'ERROR') {
          await Actions.fireNotificationEvent(context, {
            summary: 'User Info Data Load Failed',
            message: responseoic.body.StatusMessage,
          });
        } else {
          // Assign user info to variables
          $variables.userInfoObj.UserID = responseoic.body.UserProfile[0].UserID;
          $variables.userInfoObj.FirstName = responseoic.body.UserProfile[0].FirstName;
          $variables.userInfoObj.LastName = responseoic.body.UserProfile[0].LastName;
          $variables.userInfoObj.Salutation = responseoic.body.UserProfile[0].Salutation;
          $variables.userInfoObj.OrganizationId = responseoic.body.UserProfile[0].OrganizationId;
          const roleAndBUCodes = await $functions.getRoleAndBUCodes(responseoic.body);
          $variables.userInfoObj.RoleName = roleAndBUCodes.rolesDisplay;

          const email = $variables.userInfoObj.UserID;
          if (email.endsWith('@unhcr.org')) {
            $variables.loginType = 'UNHCR';
          }
          else {
            $variables.loginType = 'Partner';
            const response2 = await Actions.callRest(context, {
              endpoint: 'pfmGateway/getGetpartnerlov',
              uriParams: {
                'p_organizationid': $variables.userInfoObj.OrganizationId,
                'p_usertype': 'PARTNER',
              },
            });
            $variables.defaultPartnerNumber = response2?.body?.items?.length > 0 ? response2.body.items[0].partner_number : '';
          }
          // Role-based access
          const pfmRoles = responseoic.body.UserProfile[0].Roles.map(role => ({
            roleCode: role.RoleName
          }));
          if (pfmRoles.length === 1) {


            $variables.pfmRolesAccessObj = pfmRoles;
            $variables.userInfoObj.SelectedRoleName = pfmRoles[0].roleCode;
            $variables.userInfoObj.SelectedDisplayRoleName = pfmRoles[0].roleCode.replace(/_/g, " ");


            // Use RoleName from user profile instead of pfmRoles

          }

          else if (pfmRoles.length > 1) {

            $variables.isMultiRole = true;


            const response6 = await Actions.callRest(context, {
              endpoint: 'pfmGateway/getGetuserinfo',
              uriParams: {
                'user_id': $variables.userInfoObj.UserID,
              },
            });

            const selectedRole =
              response6?.body?.items?.[0]?.user_role || pfmRoles[0]?.roleCode || '';

            $variables.userInfoObj.SelectedRoleName = selectedRole;
            $variables.userInfoObj.SelectedDisplayRoleName = selectedRole.replace(/_/g, " ") || '';
          }
          const results = await Promise.all([
            async () => {
              const roleName = $variables.userInfoObj.SelectedRoleName;

              const isPartner = roleName === 'HCR_PFM_PARTNERS';
              const isPartnerActor = roleName === 'HCR_PFM_PARTNER_ACTOR';
              const isSuperUser = roleName === 'HCR_PFM_ADMINISTRATOR';
              const isViewOnly = roleName === 'HCR_PFM_VIEW_ONLY';
              const isJuniorPO = roleName === 'HCR_PFM_JUNIOR_PROGRAMME_OFFICERS';
              const isSeniorPO = roleName === 'HCR_PFM_SENIOR_PROGRAMME_OFFICERS';
              const isJuniorPC = roleName === 'HCR_PFM_JUNIOR_PROJECT_CONTROL';
              const isSeniorPC = roleName === 'HCR_PFM_SENIOR_PROJECT_CONTROL';

              let userRole = 'DEFAULT'; // Default role
              let userRoleCode;

              if ($variables.loginType === 'Partner') {
                userRole = 'PARTNER_USER';
                userRoleCode = 'HCR_PFM_PARTNERS';
              }
              else if (isSuperUser) {
                userRole = 'PFM_SUPERUSER';
                userRoleCode = 'HCR_PFM_ADMINISTRATOR';
              }
              else if (isPartnerActor) {
                userRole = 'PARTNER_USER';
                userRoleCode = 'HCR_PFM_PARTNER_ACTOR';
              }
              else if (
                (isJuniorPO && isJuniorPC && isPartner) ||
                (isSeniorPO && isSeniorPC && isPartner) ||
                (isSeniorPO && isJuniorPC) ||
                (isSeniorPC && isJuniorPO) ||
                (isSeniorPO && isSeniorPC) ||
                (isJuniorPO && isSeniorPO && isSuperUser)
              ) {
                userRole = 'PFM_SUPERUSER';
              }
              else if (isJuniorPO && isSeniorPO) {
                userRole = 'SENIOR_PROGRAMME_OFFICER';
                userRoleCode = 'HCR_PFM_SENIOR_PROGRAMME_OFFICERS';
              }
              else if (isSeniorPC) {
                userRole = 'SENIOR_PROJECT_CONTROL';
                userRoleCode = 'HCR_PFM_SENIOR_PROJECT_CONTROL';
              } else if (isJuniorPC) {
                userRole = 'JUNIOR_PROJECT_CONTROL';
                userRoleCode = 'HCR_PFM_JUNIOR_PROJECT_CONTROL';
              } else if (isSeniorPO) {
                userRole = 'SENIOR_PROGRAMME_OFFICER';
                userRoleCode = 'HCR_PFM_SENIOR_PROGRAMME_OFFICERS';
              } else if (isJuniorPO) {
                userRole = 'JUNIOR_PROGRAMME_OFFICER';
                userRoleCode = 'HCR_PFM_JUNIOR_PROGRAMME_OFFICERS';
              } else if (isPartner) {
                userRole = 'PARTNER_USER';
                userRoleCode = 'HCR_PFM_PARTNERS';
              }
              else if (isViewOnly) {
                userRole = 'VIEW_ONLY';
                userRoleCode = 'HCR_PFM_VIEW_ONLY';
              }

              console.log('Assigned userRole:', userRole);

              // Update role-related UI visibility
              $variables.showProgrammeOfficerButtons = isJuniorPO || isSeniorPO;
              $variables.showProjectControlButtons = isJuniorPC || isSeniorPC;
              $variables.userRole = userRole;
              // if (email === 'LOGANATN@unhcr.org') {
              // $variables.userRole = 'PFM_SUPERUSER';
              // $variables.userRole = 'JUNIOR_PROJECT_CONTROL';
              //  $variables.userRole = 'SENIOR_PROJECT_CONTROL';

              // }
              // added

              console.log('Login Type:', $variables.loginType);
              console.log('Assigned Role Codes:', pfmRoles.map(r => r.roleCode));
              console.log('Final User Role:', $variables.userRole);


            },
            async () => {


              const roleAndBUCodes = await $functions.getRoleAndBUCodesByRole(responseoic.body, $variables.userInfoObj.SelectedRoleName);
              $variables.userInfoObj.BUCode = roleAndBUCodes.buCodes;
              $variables.UserRoleADP.data = roleAndBUCodes.rolesArray;
            },

            async () => {
              const createPayloadFromIndividualNames = await $functions.createPayloadFromIndividualNames($variables.userInfoObj.UserID, $variables.userInfoObj.FirstName, $variables.userInfoObj.LastName, $variables.userInfoObj.SelectedRoleName);

              const response3 = await Actions.callRest(context, {
                endpoint: 'pfmGateway/postUserinfo',
                body: createPayloadFromIndividualNames,
              });

              $variables.ovUserInfo.login_time = response3.body.previouslogintime;
              $variables.ovUserInfo.checked_out_fpns = response3.body.checkedoutfpns;
            },
            async () => {
              const matchedBUOperations = await $functions.getMatchedBUOperations(responseoic.body, $variables.userInfoObj.SelectedRoleName);
              const operationCodes = await $functions.getOperationCodes(matchedBUOperations);

              $variables.securityOperationCodes = operationCodes;

              let items = matchedBUOperations;
              items.unshift({
                operation_name: "Select All / Clear All",
                operation_code: "ALL"
              });

              $variables.ovOperationLovADP.data = matchedBUOperations;
              $variables.fpOperationLovADP.data = matchedBUOperations;
              $variables.pfrOperationLovADP.data = matchedBUOperations;
              $variables.ppOperationLovADP.data = matchedBUOperations;
            }
          ].map(sequence => sequence()));
        }
      }

      // Email Logic to determine login type

      $variables.userRole = 'PFM_SUPERUSER';

    }

  }

  return vbEnterListener;
});
