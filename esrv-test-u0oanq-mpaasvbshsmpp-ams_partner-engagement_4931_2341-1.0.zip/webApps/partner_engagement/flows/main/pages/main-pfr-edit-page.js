define(['ojs/ojpagingdataproviderview', 'ojs/ojarraydataprovider', 'knockout', 'ojs/ojarraytreedataprovider', 'ojs/ojflattenedtreedataproviderview', 'ojs/ojknockouttemplateutils'], function (PagingDataProviderView, ArrayDataProvider, ko, ArrayTreeDataProvider, FlattenedTreeDataProviderView, KnockoutTemplateUtils) {
  'use strict';

  const ExcelJS = window.ExcelJS;
  const XLSX = window.XLSX;

  class PageModule {

    // Direct Shared table user preference test

    dstableColumn(columns) {
      return JSON.parse(localStorage.getItem("do1table")) || columns;
    }

    // indirect Support table user preference

    idstableColumn(columns) {
      return JSON.parse(localStorage.getItem("idistable")) || columns;
    }




    // buildPFROPAPostMessagePayload(pfrdata, reportingPeriod, headerDetail, comments, userDetails, fpnCode, instanceId) {

    //   const pfr = pfrdata[0].pfr; // Extract the pfr object from the first item of pfrdata

    //   const payload = {
    //     message: [
    //       {
    //         pfr: {
    //           pfr_code: pfr.pfr_code,
    //           pfr_status: pfr.pfr_status,
    //           pfr_minor_version: pfr.pfr_minor_version,
    //           pfr_major_version: pfr.pfr_major_version,
    //           pfr_type: reportingPeriod.pfr_type,
    //           fpn_code: fpnCode, // Adjust if you have fpn_code directly
    //           budget_year: pfr.budget_year,
    //           cost_center: headerDetail.costCenter,
    //           cost_center_name: headerDetail.costCenterName || "",
    //           operation_code: headerDetail.operationCode || "",
    //           operation_name: pfr.operation_name,
    //           po_number: headerDetail.poNumber,
    //           reporting_period_start_date: reportingPeriod.reporting_period_start_date,
    //           reporting_period_end_date: reportingPeriod.reporting_period_end_date,

    //           total_pfr_expenses: pfr.total_pfr_expenses,
    //           partner_site_code: pfr.partner_site_code,
    //           partner_number: headerDetail.partnerNumber,
    //           partner_name: pfr.partner_name,
    //           total_original_budget: pfr.total_original_budget,
    //           total_negotiated_budget: pfr.total_negotiated_budget,
    //           total_direct_programme_cost: pfr.total_direct_programme_cost,
    //           total_direct_shared_cost: pfr.total_direct_shared_cost,
    //           total_indirect_support_cost: pfr.total_indirect_support_cost,
    //           contract_currency_code: pfr.contract_currency_code,
    //           contract_number: pfr.contract_number,
    //           created_by: userDetails,
    //           created_date: new Date().toISOString().split("T")[0],
    //           last_updated_by: userDetails,

    //           pfr_comments: [
    //             {
    //               comment_type: "General",
    //               comment: comments,
    //               created_by: userDetails,
    //               last_updated_by: userDetails
    //             }
    //           ],

    //           outputs: (pfr.outputs || []).map(output => ({
    //             output_code: output.outputCode,
    //             output_description: output.outputDescription,
    //             output_line_status: output.lineStatus,
    //             output_total_budget: output.baseLine || 0,
    //             output_direct_programme_cost: "",
    //             output_indirect_support_cost: "",
    //             output_direct_shared_cost: "",
    //             output_expenses_ytd: output.expenses_ytd || 0,
    //             output_remaining_balance: output.remaining_balance || 0,
    //             output_reported_expenses: output.reported_expenses || 0,
    //             created_by: userDetails,
    //             last_updated_by: userDetails,
    //             output_line_comments: [
    //               {
    //                 comment_type: "Justification",
    //                 comment: output.comments || "",
    //                 created_by: userDetails,
    //                 last_updated_by: userDetails
    //               }
    //             ],
    //             locations: (output.locations || []).map(location => ({
    //               location_code: location.locationCode,
    //               location_description: location.location_description || "",
    //               location_line_status: location.lineStatus,
    //               location_original_budget: location.baseLine || 0,
    //               location_direct_programme_cost: "",
    //               location_indirect_support_cost: "",
    //               location_direct_shared_cost: "",
    //               location_expenses_ytd: location.expenses_ytd || 0,
    //               location_remaining_balance: location.remaining_balance || 0,
    //               location_reported_expenses: location.reported_expenses || 0,
    //               created_by: userDetails,
    //               last_updated_by: userDetails,
    //               location_line_comments: [
    //                 {
    //                   comment_type: "Details",
    //                   comment: location.comments || "",
    //                   created_by: userDetails,
    //                   last_updated_by: userDetails
    //                 }
    //               ],
    //               accounts: (location.accounts || []).map(account => ({
    //                 account: account.accountCode,
    //                 account_category: "", // Add mapping if available
    //                 account_description: account.accountDescription || "",
    //                 account_line_status: account.lineStatus,
    //                 account_line_amount: account.value || 0,
    //                 account_expenses_ytd: account.expenses_ytd || 0,
    //                 account_remaining_balance: account.remaining_balance || 0,
    //                 account_reported_expenses: account.reported_expenses || 0,
    //                 created_by: userDetails,
    //                 last_updated_by: userDetails,
    //                 account_line_comments: [
    //                   {
    //                     comment_type: "Breakdown",
    //                     comment: account.comments || "",
    //                     created_by: userDetails,
    //                     last_updated_by: userDetails
    //                   }
    //                 ]
    //               }))
    //             }))
    //           })),

    //           direct_shared: (pfr.direct_shared || []).map(ds => ({
    //             account: ds.accountCode || ds.account || "",
    //             account_category: "DS",
    //             account_description: ds.account_description || "",
    //             account_line_status: ds.account_line_status || "",
    //             account_line_amount: ds.account_line_amount || 0,
    //             account_expenses_ytd: ds.account_expenses_ytd || 0,
    //             account_remaining_balance: ds.account_remaining_balance || 0,
    //             account_reported_expenses: ds.account_reported_expenses || 0,
    //             created_by: userDetails,
    //             last_updated_by: userDetails,
    //             account_line_comments: [
    //               {
    //                 comment_type: "Details",
    //                 comment: ds.account_line_comments || "",
    //                 created_by: userDetails,
    //                 last_updated_by: userDetails
    //               }
    //             ]
    //           })),

    //           indirect_support: (pfr.indirect_support || []).map(is => ({
    //             partner_type: "National NGO",
    //             partner_percentage: parseFloat((is.shared_cost || "0").split(":")[1]) / 100 || 0.04,
    //             account: is.account || is.accountCode || "",
    //             account_category: "IS",
    //             account_description: is.account_description || "",
    //             total_cost: is.total_cost || 0,
    //             account_expenses_ytd: is.account_expenses_ytd || 0,
    //             account_remaining_balance: is.account_remaining_balance || 0,
    //             account_reported_expenses: is.account_reported_expenses || 0,
    //             created_by: userDetails,
    //             last_updated_by: userDetails
    //           }))
    //         }
    //       }
    //     ],
    //     instanceId: instanceId, // New instanceId parameter added to the payload
    //     appName: "PartnerFinancialManagmentApplication",
    //     processName: "NegotiateProjectFinancialReportProcess",
    //     operation: "receiveExpenses"
    //   };

    //   return payload;
    // }


    buildPFROPAPostInstancesPayload(pfrdata, reportingPeriod, headerDetail, comments, userDetails, direct_shared, indirect_support, shared_cost, budget_flexibility, status, indirectPartnerType, indirectPartnerPercentage, userCurrentRole, validationState, mode) {
      console.log("pfrdata" + JSON.stringify(pfrdata));
      console.log("reportingPeriod" + JSON.stringify(reportingPeriod));
      console.log("headerDetail" + JSON.stringify(headerDetail));
      console.log("comments" + JSON.stringify(comments));
      console.log("userDetails" + JSON.stringify(userDetails));
      let createdBy = '';

      const lastUpdatedBy = userDetails;

      const pfr = pfrdata[0].pfr;
      if (mode === 'CREATE') {
        createdBy = userDetails;
      }
      else {
        createdBy = pfr.created_by;
      }

      return {
        params: {
          applicationName: "PartnerFinancialManagmentApplication",
          processName: "NegotiateProjectFinancialReportProcess"
        },
        dataObject: {
          inputRequest: {
            pfr_code: pfr.pfr_code,
            fpn_code: pfr.fpn_code,
            pfr_status: pfr.pfr_status,
            pfr_minor_version: pfr.pfr_minor_version,
            pfr_major_version: pfr.pfr_major_version,
            pfr_type: reportingPeriod.pfr_type,
            budget_year: pfr.budget_year,
            cost_center: headerDetail.costCenter,
            cost_center_name: headerDetail.costCenterName || "",
            operation_code: headerDetail.operationCode || "",
            operation_name: pfr.operation_name,
            budget_flexibility: pfr.budget_flexibility || "",
            po_number: headerDetail.poNumber,
            reporting_period_start_date: reportingPeriod.reporting_period_start_date,
            reporting_period_end_date: reportingPeriod.reporting_period_end_date,
            total_pfr_expenses: pfr.total_pfr_expenses,
            partner_site_code: pfr.partner_site_code,
            created_date: pfr.created_date,
            business_unit: pfr.business_unit,
            in_capacity_of: userCurrentRole,
            partner_number: headerDetail.partnerNumber || "",
            partner_name: pfr.partner_name,
            total_original_budget: pfr.total_original_budget,
            total_negotiated_budget: pfr.total_negotiated_budget,
            total_direct_programme_cost: pfr.total_direct_programme_cost,
            total_direct_shared_cost: pfr.otal_direct_shared_cost,
            total_indirect_support_cost: pfr.total_indirect_support_cost,
            contract_currency_code: pfr.contract_currency_code,
            contract_number: pfr.contract_number,
            created_by: createdBy || '',
            last_updated_by: lastUpdatedBy || '',

            pfr_comments: [
              {
                comment_type: "Comments",
                comment: comments,
                created_by: userDetails,
                last_updated_by: userDetails
              }
            ],

            outputs: (pfr.outputs || []).map(output => ({
              output_code: output.outputCode,
              output_description: output.outputDescription,
              output_line_status: output.lineStatus,
              output_total_negotiated_budget: output.negotiated_budget || 0,
              output_direct_programme_budget: output.value || 0,
              output_direct_shared_budget: output.ds || 0,
              output_indirect_support_budget: output.psc || 0,
              output_expenses_ytd: output.expenses_ytd || 0,
              output_remaining_balance: output.remaining_balance || 0,
              output_direct_programme_expenses: output.reported_expenses || 0,
              output_indirect_support_expenses: output.psc_expenses || 0,
              output_direct_shared_expenses: output.ds_expenses || 0,
              output_total_negotiated_expenses: output.negotiated_expenses || 0,
              // implementation_rate: output.implementation_rate || ''
              created_by: userDetails,
              last_updated_by: userDetails,

              output_line_comments: [
                {
                  comment_type: "Output Comments",
                  comment: output.comments || "",
                  created_by: userDetails,
                  last_updated_by: userDetails
                }
              ],

              locations: (output.locations || []).map(location => ({
                location_code: location.locationCode,
                location_description: location.location_description || "",
                location_line_status: location.lineStatus,
                location_total_negotiated_budget: location.negotiated_budget || 0,
                location_direct_programme_budget: location.value || 0,
                location_direct_shared_budget: location.ds || 0,
                location_indirect_support_budget: location.psc || 0,
                location_expenses_ytd: location.expenses_ytd || 0,
                location_remaining_balance: location.remaining_balance || 0,
                // location_reported_expenses: location.reported_expenses || 0,
                location_direct_programme_expenses: location.reported_expenses || 0,
                location_indirect_support_expenses: location.psc_expenses || 0,
                location_direct_shared_expenses: location.ds_expenses || 0,
                location_total_negotiated_expenses: location.negotiated_expenses || 0,
                // implementation_rate: location.implementation_rate || ''
                created_by: userDetails,
                last_updated_by: userDetails,

                location_line_comments: [
                  {
                    comment_type: "Location Comments",
                    comment: location.comments || "",
                    created_by: userDetails,
                    last_updated_by: userDetails
                  }
                ],

                accounts: (location.accounts || []).map(account => ({
                  account: Number(account.accountCode),
                  account_category: account.account_category,
                  account_description: account.accountDescription || "",
                  account_line_status: account.lineStatus,
                  account_line_amount: account.value,
                  account_expenses_ytd: account.expenses_ytd,
                  account_remaining_balance: account.remaining_balance,
                  account_reported_expenses: account.reported_expenses,
                  // implementation_rate: account.implementation_rate || ''
                  created_by: userDetails,
                  last_updated_by: userDetails,

                  account_line_comments: [
                    {
                      comment_type: "Account Comments",
                      comment: account.comments || "",
                      created_by: userDetails,
                      last_updated_by: userDetails
                    }
                  ]
                }))
              }))
            })),

            direct_shared: (pfr.direct_shared || []).map(ds => ({
              account: Number(ds.account || ds.accountCode || ds.account_number),
              account_category: "DS",
              account_description: ds.account_description,
              account_line_status: ds.account_line_status,
              account_line_amount: ds.account_line_amount,
              account_expenses_ytd: ds.expenses_ytd,
              account_remaining_balance: ds.remaining_balance,
              account_reported_expenses: ds.reported_expenses,
              created_by: userDetails,
              last_updated_by: userDetails,

              account_line_comments: [
                {
                  comment_type: "Account Comments",
                  comment: ds.account_line_comments || "",
                  created_by: userDetails,
                  last_updated_by: userDetails
                }
              ]
            })),

            indirect_support: (pfr.indirect_support || []).map(is => {


              return {
                partner_type: is.partner_type || indirectPartnerType || '',
                partner_percentage: is.partner_percentage || indirectPartnerPercentage || '',
                account: Number(is.account || is.accountCode || is.account_number),
                account_category: "IS",
                account_description: is.account_description || "",
                total_cost: is.total_cost,
                account_expenses_ytd: is.expenses_ytd,
                account_remaining_balance: is.remaining_balance,
                account_reported_expenses: is.reported_expenses,
                created_by: userDetails,
                last_updated_by: userDetails
              };
            })
          }
        }
      };
    }



    buildPFROPAUpdateInstancesPayload(pfrdata, reportingPeriod, headerDetail, comments, userDetails, direct_shared, indirect_support, shared_cost, budget_flexibility, status, indirectPartnerType, indirectPartnerPercentage, userCurrentRole, validationState, mode) {
      // console.log("pfrdata" + JSON.stringify(pfrdata));
      // console.log("reportingPeriod" + JSON.stringify(reportingPeriod));
      // console.log("headerDetail" + JSON.stringify(headerDetail));
      // console.log("comments" + JSON.stringify(comments));
      // console.log("userDetails" + JSON.stringify(userDetails));
      let createdBy = '';

      const lastUpdatedBy = userDetails;

      const pfr = pfrdata[0].pfr;
      if (mode === 'CREATE') {
        createdBy = userDetails;
      }
      else {
        createdBy = pfr.created_by;
      }

      const payload = {

        inputRequest: {
          pfr_code: pfr.pfr_code,
          fpn_code: pfr.fpn_code,
          pfr_status: pfr.pfr_status,
          pfr_minor_version: pfr.pfr_minor_version,
          pfr_major_version: pfr.pfr_major_version,
          pfr_type: reportingPeriod.pfr_type,
          budget_year: pfr.budget_year,
          cost_center: headerDetail.costCenter,
          cost_center_name: headerDetail.costCenterName || "",
          operation_code: headerDetail.operationCode || "",
          operation_name: pfr.operation_name,
          budget_flexibility: pfr.budget_flexibility || "",
          po_number: headerDetail.poNumber,
          reporting_period_start_date: reportingPeriod.reporting_period_start_date,
          reporting_period_end_date: reportingPeriod.reporting_period_end_date,
          total_pfr_expenses: pfr.total_pfr_expenses,
          partner_site_code: pfr.partner_site_code,
          created_date: pfr.created_date,
          business_unit: pfr.business_unit,
          in_capacity_of: userCurrentRole,
          partner_number: headerDetail.partnerNumber || "",
          partner_name: pfr.partner_name,
          total_original_budget: pfr.total_original_budget,
          total_negotiated_budget: pfr.total_negotiated_budget,
          total_direct_programme_cost: pfr.total_direct_programme_cost,
          total_direct_shared_cost: pfr.otal_direct_shared_cost,
          total_indirect_support_cost: pfr.total_indirect_support_cost,
          contract_currency_code: pfr.contract_currency_code,
          contract_number: pfr.contract_number,
          created_by: createdBy || '',
          last_updated_by: lastUpdatedBy || '',

          pfr_comments: [
            {
              comment_type: "Comments",
              comment: comments,
              created_by: userDetails,
              last_updated_by: userDetails
            }
          ],

          outputs: (pfr.outputs || []).map(output => ({
            output_code: output.outputCode,
            output_description: output.outputDescription,
            output_line_status: output.lineStatus,
            output_total_negotiated_budget: output.negotiated_budget || 0,
            output_direct_programme_budget: output.value || 0,
            output_direct_shared_budget: output.ds || 0,
            output_indirect_support_budget: output.psc || 0,
            output_expenses_ytd: output.expenses_ytd || 0,
            output_remaining_balance: output.remaining_balance || 0,
            output_direct_programme_expenses: output.reported_expenses || 0,
            output_indirect_support_expenses: output.psc_expenses || 0,
            output_direct_shared_expenses: output.ds_expenses || 0,
            output_total_negotiated_expenses: output.negotiated_expenses || 0,
            // implementation_rate: output.implementation_rate || ''
            created_by: userDetails,
            last_updated_by: userDetails,

            output_line_comments: [
              {
                comment_type: "Output Comments",
                comment: output.comments || "",
                created_by: userDetails,
                last_updated_by: userDetails
              }
            ],

            locations: (output.locations || []).map(location => ({
              location_code: location.locationCode,
              location_description: location.location_description || "",
              location_line_status: location.lineStatus,
              location_total_negotiated_budget: location.negotiated_budget || 0,
              location_direct_programme_budget: location.value || 0,
              location_direct_shared_budget: location.ds || 0,
              location_indirect_support_budget: location.psc || 0,
              location_expenses_ytd: location.expenses_ytd || 0,
              location_remaining_balance: location.remaining_balance || 0,
              // location_reported_expenses: location.reported_expenses || 0,
              location_direct_programme_expenses: location.reported_expenses || 0,
              location_indirect_support_expenses: location.psc_expenses || 0,
              location_direct_shared_expenses: location.ds_expenses || 0,
              location_total_negotiated_expenses: location.negotiated_expenses || 0,
              // implementation_rate: location.implementation_rate || ''
              created_by: userDetails,
              last_updated_by: userDetails,

              location_line_comments: [
                {
                  comment_type: "Location Comments",
                  comment: location.comments || "",
                  created_by: userDetails,
                  last_updated_by: userDetails
                }
              ],

              accounts: (location.accounts || []).map(account => ({
                account: Number(account.accountCode),
                account_category: account.account_category,
                account_description: account.accountDescription || "",
                account_line_status: account.lineStatus,
                account_line_amount: account.value,
                account_expenses_ytd: account.expenses_ytd,
                account_remaining_balance: account.remaining_balance,
                account_reported_expenses: account.reported_expenses,
                // implementation_rate: account.implementation_rate || ''
                created_by: userDetails,
                last_updated_by: userDetails,

                account_line_comments: [
                  {
                    comment_type: "Account Comments",
                    comment: account.comments || "",
                    created_by: userDetails,
                    last_updated_by: userDetails
                  }
                ]
              }))
            }))
          })),

          direct_shared: (pfr.direct_shared || []).map(ds => ({
            account: Number(ds.account || ds.accountCode || ds.account_number),
            account_category: "DS",
            account_description: ds.account_description,
            account_line_status: ds.account_line_status,
            account_line_amount: ds.account_line_amount,
            account_expenses_ytd: ds.expenses_ytd,
            account_remaining_balance: ds.remaining_balance,
            account_reported_expenses: ds.reported_expenses,
            created_by: userDetails,
            last_updated_by: userDetails,

            account_line_comments: [
              {
                comment_type: "Account Comments",
                comment: ds.account_line_comments || "",
                created_by: userDetails,
                last_updated_by: userDetails
              }
            ]
          })),

          indirect_support: (pfr.indirect_support || []).map(is => {


            return {
              partner_type: is.partner_type || indirectPartnerType || '',
              partner_percentage: is.partner_percentage || indirectPartnerPercentage || '',
              account: Number(is.account || is.accountCode || is.account_number),
              account_category: "IS",
              account_description: is.account_description || "",
              total_cost: is.total_cost,
              account_expenses_ytd: is.expenses_ytd,
              account_remaining_balance: is.remaining_balance,
              account_reported_expenses: is.reported_expenses,
              created_by: userDetails,
              last_updated_by: userDetails
            };
          })
        }

      };

      return payload;
    }

    buildPFRRunValidationPayload(pfrdata, reportingPeriod, headerDetail, comments, userDetails, direct_shared, indirect_support, shared_cost, budget_flexibility, status, indirectPartnerType, indirectPartnerPercentage, userCurrentRole, validationState, mode) {
      if (!Array.isArray(pfrdata) || !pfrdata.length) {
        return { pfr: [] };
      }

      const pfr = pfrdata[0].pfr;
      let createdBy = '';

      const lastUpdatedBy = userDetails;
      if (mode === 'CREATE') {
        createdBy = userDetails;
      }
      else {
        createdBy = pfr.created_by;
      }

      return {
        pfr: [
          {

            pfr_code: pfr.pfr_code,
            fpn_code: pfr.fpn_code,
            pfr_status: pfr.pfr_status,
            pfr_major_version: pfr.pfr_major_version,
            pfr_minor_version: pfr.pfr_minor_version,
            contract_currency_code: pfr.contract_currency_code,
            cost_center: pfr.cost_center,
            cost_center_name: pfr.cost_center_name,
            operation_code: pfr.operation_code,
            po_number: pfr.po_number,
            partner_number: pfr.partner_number,
            validation_state: validationState,
            created_date: pfr.created_date,
            business_unit: pfr.business_unit,
            in_capacity_of: userCurrentRole,
            total_pfr_expenses: pfr.total_pfr_expenses,
            pfr_comments: comments,
            draft_submission_status: status,
            budget_flexibility: pfr.budget_flexibility || '',
            reporting_period: reportingPeriod ? [{
              ...reportingPeriod
            }] : [],
            operation_name: pfr.operation_name,
            budget_year: pfr.budget_year,
            partner_name: pfr.partner_name,
            partner_site_code: pfr.partner_site_code,
            contract_number: pfr.contract_number,
            total_original_budget: pfr.total_original_budget,
            total_negotiated_budget: pfr.total_negotiated_budget,
            total_direct_programme_cost: pfr.total_direct_programme_cost,
            total_direct_shared_cost: pfr.total_direct_shared_cost,
            total_indirect_support_cost: pfr.total_indirect_support_cost,
            created_by: createdBy || '',
            last_updated_by: lastUpdatedBy || '',

            // ----- Outputs -----
            outputs: (pfr.outputs || []).map(output => ({
              // pfr_output_id: output.pfr_output_id,
              output_line_status: output.lineStatus,
              output_line_comments: output.comments || "",
              output_total_negotiated_budget: output.negotiated_budget || 0,
              output_direct_programme_budget: output.value || 0,
              output_direct_shared_budget: output.ds || 0,
              output_indirect_support_budget: output.psc || 0,
              output_expenses_ytd: output.expenses_ytd || 0,
              output_remaining_balance: output.remaining_balance || 0,
              output_direct_programme_expenses: output.reported_expenses || 0,
              output_indirect_support_expenses: output.psc_expenses || 0,
              output_direct_shared_expenses: output.ds_expenses || 0,
              output_total_negotiated_expenses: output.negotiated_expenses || 0,
              // fpn_output_id: output.fpn_output_id,
              output_code: output.outputCode,
              output_description: output.outputDescription,
              created_by: createdBy || '',
              last_updated_by: lastUpdatedBy || '',
              // last_baseline: output.last_baseline,
              // total_expenses: output.total_expenses,
              implementation_rate: output.implementation_rate || '',
              // ----- Locations -----
              locations: (output.locations || []).map(location => ({
                // pfr_output_id: location.pfr_output_id,
                // pfr_location_id: location.pfr_location_id,
                location_line_status: location.lineStatus,
                location_line_comments: location.comments || "",
                location_total_negotiated_budget: location.negotiated_budget || 0,
                location_direct_programme_budget: location.value || 0,
                location_direct_shared_budget: location.ds || 0,
                location_indirect_support_budget: location.psc || 0,
                location_expenses_ytd: location.expenses_ytd || 0,
                location_remaining_balance: location.remaining_balance || 0,
                // location_reported_expenses: location.reported_expenses || 0,
                location_direct_programme_expenses: location.reported_expenses || 0,
                location_indirect_support_expenses: location.psc_expenses || 0,
                location_direct_shared_expenses: location.ds_expenses || 0,
                location_total_negotiated_expenses: location.negotiated_expenses || 0,
                location_code: location.locationCode,
                location_description: location.location_description,
                created_by: createdBy || '',
                last_updated_by: lastUpdatedBy || '',
                // last_baseline: location.last_baseline ,
                // total_expenses: location.total_expenses,
                implementation_rate: location.implementation_rate || '',

                // ----- Accounts -----
                accounts: (location.accounts || []).map(account => ({
                  // pfr_output_id: account.pfr_output_id,
                  // pfr_location_id: account.pfr_location_id,
                  // pfr_account_id: account.pfr_account_id,
                  account_line_status: account.lineStatus,
                  account_line_comments: account.comments || "",
                  account_expenses_ytd: account.expenses_ytd || 0,
                  account_remaining_balance: account.remaining_balance || 0,
                  account_reported_expenses: account.reported_expenses || 0,
                  account_line_amount: account.value,
                  account: account.accountCode,
                  account_description: account.accountDescription,
                  created_by: pfr.created_by || '',
                  last_updated_by: userDetails || '',
                  implementation_rate: account.implementation_rate || ''
                }))
              }))
            })),

            // ----- Direct Shared -----
            direct_shared: (direct_shared || []).map(ds => ({
              account_expenses_ytd: ds.expenses_ytd || 0,
              account_remaining_balance: ds.remaining_balance || 0,
              account_reported_expenses: ds.reported_expenses || 0,
              account_line_status: ds.account_line_status || "",
              account_line_comments: ds.account_line_comments || "",
              // fpn_ds_id: ds.fpn_ds_id,
              account_line_amount: ds.account_line_amount,
              account: ds.account_number,
              account_description: ds.account_description,
              created_by: pfr.created_by || '',
              last_updated_by: userDetails || ''
            })),

            // ----- Indirect Support -----
            indirect_support: (indirect_support || []).map(isc => ({
              account_expenses_ytd: isc.expenses_ytd || 0,
              account_remaining_balance: isc.remaining_balance || 0,
              account_reported_expenses: isc.reported_expenses || 0,
              total_cost: isc.total_cost || 0,
              partner_type: indirectPartnerType || '',
              partner_percentage: indirectPartnerPercentage || '',
              account: isc.account_number,
              account_description: isc.account_description,
              created_by: pfr.created_by || '',
              last_updated_by: userDetails || ''
            }))
          }
        ]
      };
    }








    validvateCorrectExpenses(pfrType) {
      return {
        validate: function (value) {
          if (value === null || value === undefined) {
            throw new Error('Please enter a value.');
          }

          if (pfrType === 'Credit Note') {
            if (value >= 0) {
              throw new Error('Only negative amounts are allowed for Credit Notes.');
            }
          } else {
            if (value < 0) {
              throw new Error('Negative amounts are not allowed for non-Credit Note types.');
            }
          }

          return value;
        }
      };
    }


    /**
     *
     * @param {string} arg1
     * @return {string}
     */
    testCode(input) {
      // console.log("input: " + JSON.stringify(input));

      const renameRules = [
        { key: "pfr_status", rename: "pfr_status" },
        { key: "output_code", rename: "outputCode" },
        { key: "output_description", rename: "outputDescription" },
        { key: "output_total_negotiated_budget", rename: "negotiated_budget" },
        { key: "output_direct_programme_budget", rename: "value" },
        { key: "output_direct_shared_budget", rename: "ds" },
        { key: "output_indirect_support_budget", rename: "psc" },
        { key: "output_direct_programme_expenses", rename: "reported_expenses" },
        { key: "output_indirect_support_expenses", rename: "psc_expenses" },
        { key: "output_direct_shared_expenses", rename: "ds_expenses" },
        { key: "output_total_negotiated_expenses", rename: "negotiated_expenses" },
        { key: "output_line_comments", rename: "comments" },
        { key: "output_line_status", rename: "lineStatus" },
        { key: "output_expenses_ytd", rename: "expenses_ytd" },
        { key: "output_remaining_balance", rename: "remaining_balance" },
        // { key: "fpn_location_code", parentMatches: ["accounts"], rename: "loc" },
        { key: "location_code", parentMatches: ["locations"], rename: "locationCode" },
        { key: "location_total_negotiated_budget", rename: "negotiated_budget" },
        { key: "location_direct_programme_budget", rename: "value" },
        { key: "location_direct_shared_budget", rename: "ds" },
        { key: "location_indirect_support_budget", rename: "psc" },
        { key: "location_direct_programme_expenses", rename: "reported_expenses" },
        { key: "location_indirect_support_expenses", rename: "psc_expenses" },
        { key: "location_direct_shared_expenses", rename: "ds_expenses" },
        { key: "location_total_negotiated_expenses", rename: "negotiated_expenses" },
        { key: "location_line_status", rename: "lineStatus" },
        { key: "location_expenses_ytd", rename: "expenses_ytd" },
        { key: "location_remaining_balance", rename: "remaining_balance" },
        { key: "location_line_comments", rename: "comments" },
        // { key: "negotiated_amount", parentMatches: ["direct_shared"], rename: "account_negotiated_amount" },
        // { key: "pfr_account_id", parentMatches: ["accounts"], rename: "id" },
        { key: "account_line_amount", parentMatches: ["accounts"], rename: "value" },
        { key: "account", parentMatches: ["accounts"], rename: "accountCode" },
        { key: "account_description", parentMatches: ["accounts"], rename: "accountDescription" },
        { key: "account_line_comments", parentMatches: ["accounts"], rename: "comments" },
        { key: "account_expenses_ytd", rename: "expenses_ytd" },
        { key: "account_remaining_balance", rename: "remaining_balance" },
        { key: "account_reported_expenses", rename: "reported_expenses" },
        { key: "account_line_status", parentMatches: ["direct_shared"], rename: "account_line_status" },
        { key: "account_expenses_ytd", parentMatches: ["direct_shared"], rename: "expenses_ytd" },
        { key: "account_remaining_balance", parentMatches: ["direct_shared"], rename: "remaining_balance" },
        { key: "account_reported_expenses", parentMatches: ["direct_shared"], rename: "reported_expenses" },
        { key: "account_line_status", parentMatches: ["accounts"], rename: "lineStatus" },
        { key: "account", parentMatches: ["direct_shared", "indirect_support"], rename: "account_number" },
        { key: "total_cost", parentMatches: ["indirect_support"], rename: "total_cost" },

        // 
        { key: "account_line_comments", parentMatches: ["direct_shared"], rename: "account_line_comments" }
      ];

      // Recursive rename function
      const deepRename = function (obj, parentKey = null, ancestors = []) {
        const getRename = (key, parentKey, ancestors) => {
          for (const r of renameRules) {
            if (r.key === key) {
              if (r.parentMatches) {
                // Check if any ancestor matches the parentMatches condition
                if (ancestors && ancestors.some(a => r.parentMatches.includes(a))) return r.rename;
                if (parentKey && r.parentMatches.includes(parentKey)) return r.rename;
              } else {
                return r.rename;
              }
            }
          }
          return key; // return the original key if no match
        };

        if (Array.isArray(obj)) {
          return obj.map(item => deepRename(item, parentKey, ancestors)); // Recursively handle arrays
        }

        if (obj && typeof obj === "object") {
          const out = {};
          const newAncestors = parentKey ? [parentKey, ...ancestors] : ancestors;
          for (const [k, v] of Object.entries(obj)) {
            const newKey = getRename(k, parentKey, ancestors); // Get the renamed key
            out[newKey] = deepRename(v, k, newAncestors); // Recursively process nested objects
          }
          return out;
        }

        return obj; // Return primitive values as they are
      };

      // Process the input based on whether it's an array or object
      let finalArray;
      if (Array.isArray(input)) {
        finalArray = deepRename(input); // Process as array
      } else if (input && typeof input === "object" && Array.isArray(input.items)) {
        finalArray = deepRename(input.items, "items"); // Handle special case for items
      } else {
        finalArray = [deepRename(input)]; // Process as a single object
      }
      // console.log("finalarray" + JSON.stringify(finalArray));
      return finalArray;  // Return the final array
    }
    async exportPFRDataToExcel(pfrData, directPFRAccounts, sharedPFRAccounts, directSharedPFRData, pfrCode) {

      if (!Array.isArray(pfrData) || !Array.isArray(directSharedPFRData)) {
        console.error('Data is not in array format:', { pfrData, directSharedPFRData });
        return;
      }

      const workbook = new ExcelJS.Workbook();
      const headers = ['PFR', 'Output', 'Location', 'Account', 'Account Description', 'Value', 'Expenses to Date', 'Balance', 'New Expense', 'Comments'];
      const lastRowNumber = 1000;

      //Direct Programme Sheet
      const sheetDP = workbook.addWorksheet('Direct Programme');
      sheetDP.addRow(headers);
      this.styleHeaderDP(sheetDP);
      this.populatePFRRows(sheetDP, pfrData);

      // const directDropdown = `"${directPFRAccounts.map(a => a.accountCode).join(',')}"`;
      // for (let i = 2; i <= lastRowNumber; i++) {
      //   this.applyAccountDropdown(sheetDP.getCell(`E${i}`), directDropdown);
      // }

      sheetDP.columns.forEach(col => col.width = 25);
      sheetDP.views = [{ state: 'frozen', ySplit: 1 }];

      for (let i = 2; i <= lastRowNumber; i++) {
        sheetDP.getCell(i, 9).protection = { locked: false };
        sheetDP.getCell(i, 10).protection = { locked: false };
      }

      // Protect sheet
      await sheetDP.protect('pfrpassword', {
        selectLockedCells: false,
        selectUnlockedCells: true,
        formatCells: false,
        formatColumns: false,
        formatRows: false,
        insertColumns: false,
        insertRows: false,
        deleteColumns: false,
        deleteRows: false,
        sort: false,
        autoFilter: false
      });

      // Direct Shared Sheet
      const sheetDS = workbook.addWorksheet('Direct Shared');
      sheetDS.addRow(['Account',
        'Account Description',
        'Planned',
        'Expenses To Date',
        'Balance',
        'New Expense',
        'Comments']);
      this.styleHeaderDS(sheetDS);
      this.populateDirectsharedRows(sheetDS, directSharedPFRData);

      // const sharedDropdown = `"${sharedPFRAccounts.map(a => a.account_number).join(',')}"`;
      // for (let i = 2; i <= lastRowNumber; i++) {
      //   this.applyAccountDropdown(sheetDS.getCell(`A${i}`), sharedDropdown);
      // }

      sheetDS.columns.forEach(col => col.width = 25);
      sheetDS.views = [{ state: 'frozen', ySplit: 1 }];

      for (let i = 2; i <= lastRowNumber; i++) {
        sheetDS.getCell(i, 6).protection = { locked: false };
        sheetDS.getCell(i, 7).protection = { locked: false };
      }

      // Protect sheet


      await sheetDS.protect('pfrpassword', {
        selectLockedCells: false,
        selectUnlockedCells: true,
        formatCells: false,
        formatColumns: false,
        formatRows: false,
        insertColumns: false,
        insertRows: false,
        deleteColumns: false,
        deleteRows: false,
        sort: false,
        autoFilter: false
      });

      // === 3. Export Workbook ===
      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      });

      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${pfrCode || 'PFR_DATA'}.xlsx`;
      a.click();
      URL.revokeObjectURL(url);
    }
    styleHeaderDP(worksheet, rowIndex = 1) {
      worksheet.getRow(rowIndex).eachCell((cell, colNumber) => {
        cell.font = { bold: true, color: { argb: 'FFFFFFFF' }, size: 11 };
        cell.alignment = { vertical: 'middle', horizontal: 'left' };
        cell.fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: [1, 2, 3, 4, 5, 6, 7, 8].includes(colNumber) ? '000000' : '4472C4' }
        };
        cell.border = {
          top: { style: 'thin' },
          left: { style: 'thin' },
          bottom: { style: 'thin' },
          right: { style: 'thin' }
        };
      });
    }


    styleHeaderDS(worksheet, rowIndex = 1) {
      worksheet.getRow(rowIndex).eachCell((cell, colNumber) => {
        cell.font = { bold: true, color: { argb: 'FFFFFFFF' }, size: 11 };
        cell.alignment = { vertical: 'middle', horizontal: 'left' };
        cell.fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: [1, 2, 3, 4, 5].includes(colNumber) ? '000000' : '4472C4' }
        };
        cell.border = {
          top: { style: 'thin' },
          left: { style: 'thin' },
          bottom: { style: 'thin' },
          right: { style: 'thin' }
        };
      });
    }

    styleDataRow(row) {
      row.eachCell((cell, colNumber) => {
        cell.fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: [1, 2, 3, 4, 5, 6, 7, 8].includes(colNumber) ? 'D9D9D9' : 'FFFFFF' }
        };
        cell.border = {
          top: { style: 'thin' },
          left: { style: 'thin' },
          bottom: { style: 'thin' },
          right: { style: 'thin' }
        };
        cell.alignment = { vertical: 'middle', horizontal: 'left' };
      });
    }


    styleDataRowDs(row) {
      row.eachCell((cell, colNumber) => {
        cell.fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: [1, 2, 3, 4, 5].includes(colNumber) ? 'D9D9D9' : 'FFFFFF' }
        };
        cell.border = {
          top: { style: 'thin' },
          left: { style: 'thin' },
          bottom: { style: 'thin' },
          right: { style: 'thin' }
        };
        cell.alignment = { vertical: 'middle', horizontal: 'left' };
      });
    }




    applyAccountDropdown(cell, dropdownFormula) {
      cell.dataValidation = {
        type: 'list',
        allowBlank: true,
        formulae: [dropdownFormula],
        showErrorMessage: true,
        errorTitle: 'Invalid Entry',
        error: 'Please select a valid account number from the dropdown list.'
      };
    }

    populatePFRRows(sheet, pfrData) {
      pfrData.forEach(wrapper => {
        const pfr = wrapper.pfr;
        if (!pfr || !Array.isArray(pfr.outputs)) return;

        const pfr_code = pfr.pfr_code;

        pfr.outputs.forEach(output => {
          const outputCode = output.outputCode || '';
          const baseline = output.baseLine || '';
          const comments = output.comments || '';

          (output.locations || []).forEach(location => {
            const locationCode = location.locationCode;
            const accounts = location.accounts || [];

            if (accounts.length > 0) {
              accounts.filter(account => account.account_category === 'DP')
                .forEach(account => {
                  const row = sheet.addRow([
                    pfr_code,
                    outputCode,
                    locationCode,
                    // account.lineStatus || '',
                    account.accountCode || '',
                    account.accountDescription || '',
                    // baseline,
                    account.value || '',
                    account.expenses_ytd || '',
                    account.remaining_balance || '',
                    account.reported_expenses || '',
                    account.comments || comments || ''
                  ]);


                  this.styleDataRow(row);
                });
            } else {
              const row = sheet.addRow([
                pfr_code,
                outputCode,
                locationCode,
                '', '', '', baseline, '', comments || ''
              ]);


              this.styleDataRow(row);
            }
          });
        });
      });
    }

    populatePFRDirectSharedRows(sheet, pfrData) {
      // console.log("directshareddata" + JSON.stringify(pfrData));
      if (!Array.isArray(pfrData)) return;

      for (const { pfr } of pfrData) {
        if (!pfr?.outputs?.length) continue;

        const pfrCode = pfr.pfr_code || '';

        for (const output of pfr.outputs) {
          const outputCode = output.outputCode || '';
          const baseline = output.baseLine || '';
          const outputComments = output.comments || '';

          const locations = output.locations || [];
          for (const location of locations) {
            const locationCode = location.locationCode || '';
            const lineStatus = location.lineStatus || '';
            const expensesYtd = location.expenses_ytd || 0;
            const remainingBalance = location.remaining_balance || 0;
            const reportedExpenses = location.reported_expenses || 0;
            const locationComments = location.comments || '';

            const accounts = location.accounts || [];
            const commonRowData = [
              pfrCode,
              outputCode,
              locationCode,
              lineStatus,
            ];

            if (accounts.length > 0) {
              for (const account of accounts) {
                const row = sheet.addRow([
                  ...commonRowData,
                  account.accountCode || '',
                  account.accountDescription || '',
                  baseline,
                  account.value || '',
                  expensesYtd,
                  remainingBalance,
                  reportedExpenses,
                  account.comments || locationComments || outputComments || ''
                ]);
                this.styleDataRowDs(row);
              }
            } else {
              const row = sheet.addRow([
                ...commonRowData,
                '', '',         // accountCode, accountDescription
                baseline,
                '',             // value
                expensesYtd,
                remainingBalance,
                reportedExpenses,
                locationComments || outputComments || ''
              ]);
              this.styleDataRowDs(row);
            }
          }
        }
      }
    }

    transformData(inputData) {
      // console.log("Input data:", JSON.stringify(inputData));

      const transformedData = inputData.map(item => {
        const fpn = item.fpn || {};

        const pfr = {
          pfr_id: fpn.fpn_id,
          fpn_id: fpn.fpn_id,
          pfr_code: fpn.fpn_code || "",
          pfr_status: fpn.fpn_status_code || "",
          pfr_major_version: fpn.fpn_major_version || 1,
          pfr_minor_version: fpn.fpn_minor_version || 0,
          total_pfr_expenses: fpn.total_expenses || 0,
          pfr_comments: fpn.fpn_comments || "",
          draft_submission_status: fpn.draft_submission_status || "",
          reporting_period: [],
          operation_name: fpn.operation_name || "",
          budget_year: fpn.budget_year || "",
          partner_name: fpn.partner_name || "",
          partner_site_code: fpn.partner_site_code || "",
          contract_currency_code: fpn.contract_currency_code || "",
          contract_number: fpn.contract_number || "",
          total_original_budget: fpn.total_original_budget || 0,
          total_negotiated_budget: fpn.total_negotiated_budget || 0,
          total_direct_programme_cost: fpn.total_direct_programme_cost || 0,
          total_direct_shared_cost: fpn.total_direct_shared_cost || 0,
          total_indirect_support_cost: fpn.total_indirect_support_cost || 0,
          created_by: "TEST_USER",
          last_updated_by: "TEST_USER",

          // --- Outputs ---
          outputs: (fpn.outputs || []).map(output => ({
            pfr_output_id: output.fpn_output_id,
            outputCode: output.fpn_output_code || "",
            outputDescription: output.outputDescription || "",
            baseLine: output.baseLine || 0,
            value: output.value || 0,
            ds: output.ds || 0,
            psc: output.psc || 0,
            expenses_ytd: output.total_expenses || 0,
            reported_expenses: 0,
            remaining_balance: 0,
            comments: output.fpn_output_comments || "",
            lineStatus: output.output_status_code || "",
            created_by: "TEST_USER",
            last_updated_by: "TEST_USER",

            // --- Locations ---
            locations: (output.locations || []).map(location => ({
              pfr_location_id: location.fpn_location_id,
              locationCode: location.fpn_location_code || "",
              location_description: location.location_description || "",
              baseLine: location.output_location_original_budget || 0,
              value: location.value || 0,
              ds: 0,
              psc: 0,
              expenses_ytd: location.total_expenses || 0,
              reported_expenses: 0,
              remaining_balance: 0,
              comments: location.fpn_location_comments || "",
              lineStatus: location.location_status_code || "",
              created_by: "TEST_USER",
              last_updated_by: "TEST_USER",

              // --- Accounts ---
              accounts: (location.accounts || []).map(account => ({
                id: account.fpn_account_id || null,
                accountCode: account.accountCode || account.account_number || "",
                accountDescription:
                  account.accountDescription || account.account_description || "",
                value: account.value || 0,
                expenses_ytd: account.total_expenses || 0,
                reported_expenses: 0,
                remaining_balance: 0,
                comments: account.comments || "",
                lineStatus: account.account_line_status_code || "",
                created_by: "TEST_USER",
                last_updated_by: "TEST_USER"
              }))
            }))
          })),

          // --- Direct Shared (if available) ---
          direct_shared: Array.isArray(fpn.direct_shared) ? fpn.direct_shared : [],

          // --- Indirect Support ---
          indirect_support: (fpn.indirect_support || []).map(isc => ({
            account_number: isc.account_number || "",
            account_description: isc.account_description || "",
            total_cost: isc.total_cost || 0,
            expenses_ytd: 0,
            reported_expenses: 0,
            remaining_balance: 0,
            created_by: "TEST_USER",
            last_updated_by: "TEST_USER"
          }))
        };

        return { pfr };
      });

      // console.log("Transformed Data:", JSON.stringify(transformedData, null, 2));
      // return transformedData;
    }

    createPFRPayloadWithIds(fpnItems, incrementPfrCode, approvedPfrCode) {

      console.log("fpnItems" + JSON.stringify(fpnItems));
      const uuid = () => Math.floor(1000 + Math.random() * 9000);

      if (!fpnItems || !Array.isArray(fpnItems)) return { items: [] };

      const items = fpnItems.map(item => {
        const fpn = item.fpn;

        // ----------------------------------------------------------
        //                PFR CODE GENERATION LOGIC
        // ----------------------------------------------------------
        let newPfrCode = fpn.fpn_code.replace('-FPN', '-PFR');
        const match = newPfrCode.match(/-PFR-(\d{3})$/);  // check -PFR-001 like format

        if (match) {
          // already has numeric suffix -> no change
          newPfrCode = newPfrCode;
        } else {
          // missing suffix -> append default
          newPfrCode = `${newPfrCode}-001`;
        }

        // If increment flag enabled -> generate next version
        if (incrementPfrCode) {
          const baseCode = approvedPfrCode || newPfrCode;
          const numMatch = baseCode.match(/(\d+)$/);

          if (numMatch) {
            const currentNum = parseInt(numMatch[1], 10);
            const nextNum = String(currentNum + 1).padStart(3, "0");
            newPfrCode = baseCode.replace(/\d+$/, nextNum);
          } else {
            newPfrCode = `${baseCode}-002`;
          }
        }

        return {
          pfr: {
            pfr_id: uuid(),
            fpn_id: uuid(),
            pfr_code: newPfrCode,
            fpn_code: fpn.fpn_code,
            pfr_status: 'Draft',
            pfr_major_version: fpn.fpn_major_version || '',
            pfr_minor_version: fpn.fpn_minor_version || '',
            total_pfr_expenses: fpn.total_pfr_expenses || '',
            pfr_comments: '',
            draft_submission_status: 'DRAFT',
            reporting_period: fpn.reporting_period || [],
            operation_name: fpn.operation_name || '',
            budget_year: fpn.budget_year || '',
            partner_name: fpn.partner_name || '',
            partner_site_code: fpn.partner_site_code || '',
            contract_currency_code: fpn.contract_currency_code || '',
            contract_number: fpn.contract_number || '',
            total_negotiated_budget: fpn.total_negotiated_budget || '',
            total_direct_programme_cost: fpn.total_direct_programme_cost || '',
            total_direct_shared_cost: fpn.total_direct_shared_cost || '',
            total_indirect_support_cost: fpn.total_indirect_support_cost || '',
            total_original_budget: fpn.total_original_budget || '',
            created_by: fpn.created_by || '',
            last_updated_by: fpn.last_updated_by || '',
            cost_center: fpn.cost_center || '',
            cost_center_name: fpn.cost_center_name || '',
            operation_code: fpn.operation_code || '',
            po_number: fpn.po_number || '',
            partner_number: fpn.partner_number || '',
            business_unit: fpn.business_unit || '',
            in_capacity_of: "tester",
            budget_flexibility: fpn.budget_flexibility || '',
            created_date: fpn.created_date || '',


            // ----------------------- OUTPUTS -----------------------
            outputs: fpn.outputs?.map(out => {
              const outputId = uuid();
              return {
                pfr_output_id: outputId,
                output_line_status: 'Draft',
                output_line_comments: '',
                output_total_negotiated_budget: out.output_total_cost || '',
                output_direct_programme_budget: out.output_direct_programme_cost || '',
                output_direct_shared_budget: out.output_direct_shared_cost || '',
                output_indirect_support_budget: out.output_indirect_support_cost || '',
                output_direct_programme_expenses: out.output_direct_programme_expenses || '',
                output_indirect_support_expenses: out.output_indirect_support_expenses || '',
                output_direct_shared_expenses: out.output_direct_shared_expenses || '',
                output_total_negotiated_expenses: out.output_total_negotiated_expenses || '',
                output_expenses_ytd: out.output_expenses_ytd || 0,
                output_remaining_balance: out.output_remaining_balance || 0,
                fpn_output_id: uuid(),
                output_code: out.fpn_output_code,
                output_description: out.output_description,
                created_by: out.created_by,
                last_updated_by: out.last_updated_by,
                implementation_rate: out.implementation_rate || '',

                // ----------------------- LOCATIONS -----------------------
                locations: out.locations?.map(loc => {
                  const locationId = uuid();
                  return {
                    pfr_output_id: outputId,
                    pfr_location_id: locationId,
                    location_line_status: 'Draft',
                    location_line_comments: '',
                    location_direct_programme_budget: loc.output_location_direct_programme_cost || '',
                    location_direct_shared_budget: loc.output_location_direct_shared_cost || '',
                    location_indirect_support_budget: loc.output_location_indirect_support_cost || '',
                    location_total_negotiated_budget: loc.output_location_total_cost || '',
                    location_direct_programme_expenses: loc.location_direct_programme_expenses || '',
                    location_indirect_support_expenses: loc.location_indirect_support_expenses || '',
                    location_direct_shared_expenses: loc.location_direct_shared_expenses || '',
                    location_total_negotiated_expenses: loc.location_total_negotiated_expenses || '',
                    location_expenses_ytd: loc.locations_expenses_ytd || 0,
                    location_remaining_balance: loc.location_remaining_balance || 0,
                    fpn_location_id: uuid(),
                    location_code: loc.fpn_location_code,
                    location_description: loc.location_description,
                    created_by: loc.created_by,
                    last_updated_by: loc.last_updated_by,
                    implementation_rate: loc.implementation_rate,

                    // ----------------------- ACCOUNTS -----------------------
                    accounts: loc.accounts?.map(acc => ({
                      pfr_output_id: outputId,
                      pfr_location_id: locationId,
                      pfr_account_id: uuid(),
                      account_line_status: 'Draft',
                      account_line_comments: '',
                      account_expenses_ytd: acc.expenses_ytd || 0,
                      account_remaining_balance: acc.remaining_balance || 0,
                      account_reported_expenses: acc.reported_expenses || 0,
                      fpn_account_id: uuid(),
                      account_line_amount: acc.account_line_amount,
                      account: acc.account,
                      account_category: 'DP',
                      account_description: acc.account_description,
                      created_by: acc.created_by,
                      last_updated_by: acc.last_updated_by
                    })) || []
                  }
                }) || []
              }
            }) || [],

            // ----------------------- DIRECT SHARED -----------------------
            direct_shared: fpn.direct_shared?.map(ds => ({
              pfr_ds_id: uuid(),
              fpn_ds_id: uuid(),
              account_id: uuid(),
              account_expenses_ytd: Number(ds.total_expenses) || 0,
              account_remaining_balance: Number(ds.remaining_balance) || 0,
              account_reported_expenses: Number(ds.reported_expenses) || 0,
              account_line_status: 'Draft',
              account_line_comments: '',
              account_line_amount: Number(ds.account_line_amount) || 0,
              account: ds.account,
              account_category: 'DS',
              account_description: ds.account_description,
              created_by: ds.created_by,
              last_updated_by: ds.last_updated_by
            })) || [],

            // ----------------------- INDIRECT SUPPORT -----------------------
            indirect_support: fpn.indirect_support
              ?.map(isc => ({
                pfr_isc_id: uuid(),
                fpn_isc_id: uuid(),
                account_id: uuid(),
                account_category: 'IS',
                // lookup_type_id: uuid(),
                account_expenses_ytd: Number(isc.total_expenses) || 0, // Convert to number
                account_remaining_balance: Number(isc.remaining_balance) || 0, // Convert to number
                account_reported_expenses: Number(isc.reported_expenses) || 0, // Convert to number
                total_cost: Number(isc.total_cost) || 0, // Convert to number
                shared_cost: isc.shared_cost,
                partner_type: isc.partner_type,
                partner_percentage: isc.partner_percentage,
                account: isc.account,
                account_description: isc.account_description,
                created_by: isc.created_by,
                last_updated_by: isc.last_updated_by
              })) || []
          }
        };
      });
      console.log("fpnItemsreturn" + JSON.stringify({ items }));
      return { items };
    }

    editPFRPayloadWithIds(input) {

      // Correct format: input = [ { pfr: {...} } ]
      if (!input || !Array.isArray(input) || !input[0]?.pfr) {
        return { items: [] };
      }

      const uuid = () => Math.floor(Math.random() * 900) + 100;

      const source = input[0].pfr;



      const result = {
        items: [
          {
            pfr: {
              pfr_id: uuid(),
              fpn_id: source.fpn_id,
              pfr_code: source.pfr_code,
              fpn_code: source.fpn_code,
              pfr_status: source.pfr_status,
              pfr_major_version: source.pfr_major_version,
              pfr_minor_version: source.pfr_minor_version,
              total_pfr_expenses: source.total_pfr_expenses,
              pfr_comments: source.pfr_comments,
              cost_center: source.cost_center,
              cost_center_name: source.cost_center_name,
              operation_code: source.operation_code,
              po_number: source.po_number,
              partner_number: source.partner_number,
              business_unit: source.business_unit,
              in_capacity_of: source.in_capacity_of,
              budget_flexibility: source.budget_flexibility,
              draft_submission_status: source.draft_submission_status,
              reporting_period: source.reporting_period || [],
              operation_name: source.operation_name,
              budget_year: source.budget_year,
              partner_name: source.partner_name,
              partner_site_code: source.partner_site_code,
              contract_currency_code: source.contract_currency_code,
              contract_number: source.contract_number,
              total_original_budget: source.total_original_budget,
              total_negotiated_budget: source.total_negotiated_budget || '',
              total_direct_programme_cost: source.total_direct_programme_cost || '',
              total_direct_shared_cost: source.total_direct_shared_cost || '',
              total_indirect_support_cost: source.total_indirect_support_cost || '',
              created_by: source.created_by,
              created_date: source.created_date,
              last_updated_by: source.last_updated_by,

              // ----------------------- OUTPUTS -----------------------
              outputs: source.outputs?.map(out => {
                const outputId = uuid();
                return {
                  pfr_output_id: outputId,
                  output_line_status: out.output_line_status,
                  output_line_comments: out.output_line_comments,
                  output_total_budget: out.output_total_budget,
                  output_total_negotiated_budget: out.output_total_negotiated_budget || 0,
                  output_direct_programme_budget: out.output_direct_programme_budget || 0,
                  output_direct_shared_budget: out.output_direct_shared_budget || 0,
                  output_indirect_support_budget: out.output_indirect_support_budget || 0,
                  output_direct_programme_expenses: out.output_direct_programme_expenses || 0,
                  output_indirect_support_expenses: out.output_indirect_support_expenses || 0,
                  output_direct_shared_expenses: out.output_direct_shared_expenses || 0,
                  output_total_negotiated_expenses: out.output_total_negotiated_expenses || 0,
                  output_expenses_ytd: out.output_expenses_ytd || 0,
                  output_remaining_balance: out.output_remaining_balance || 0,
                  fpn_output_id: uuid(),
                  output_code: out.output_code,
                  output_description: out.output_description,
                  implementation_rate: out.implementation_rate,
                  created_by: out.created_by,
                  last_updated_by: out.last_updated_by,

                  // ----------------------- LOCATIONS -----------------------
                  locations: out.locations?.map(loc => {
                    const locationId = uuid();
                    return {
                      pfr_output_id: outputId,
                      pfr_location_id: locationId,
                      location_line_status: loc.location_line_status,
                      location_line_comments: loc.location_line_comments,
                      lolocation_direct_programme_budget: loc.location_direct_programme_budget || 0,
                      location_direct_shared_budget: loc.location_direct_shared_budget || 0,
                      location_indirect_support_budget: loc.location_indirect_support_budget || 0,
                      location_total_negotiated_budget: loc.location_total_negotiated_budget || 0,
                      location_direct_programme_expenses: loc.location_direct_programme_expenses || 0,
                      location_indirect_support_expenses: loc.location_indirect_support_expenses || 0,
                      location_direct_shared_expenses: loc.location_direct_shared_expenses || 0,
                      location_total_negotiated_expenses: loc.location_total_negotiated_expenses || 0,
                      location_expenses_ytd: loc.locations_expenses_ytd || 0,
                      location_remaining_balance: loc.location_remaining_balance || 0,
                      fpn_location_id: uuid(),
                      location_code: loc.location_code,
                      location_description: loc.location_description,
                      implementation_rate: loc.implementation_rate,
                      created_by: loc.created_by,
                      last_updated_by: loc.last_updated_by,

                      // ----------------------- ACCOUNTS -----------------------
                      accounts: loc.accounts?.map(acc => ({
                        pfr_output_id: outputId,
                        pfr_location_id: locationId,
                        pfr_account_id: uuid(),
                        account_line_status: acc.account_line_status,
                        account_line_comments: acc.account_line_comments,
                        account_expenses_ytd: acc.account_expenses_ytd || 0,
                        account_remaining_balance: acc.account_remaining_balance || 0,
                        account_reported_expenses: acc.account_reported_expenses || 0,
                        implementation_rate: acc.implementation_rate,
                        fpn_account_id: uuid(),
                        account_line_amount: acc.account_line_amount,
                        account: acc.account,
                        account_description: acc.account_description,
                        created_by: acc.created_by,
                        account_category: acc.account_category,
                        last_updated_by: acc.last_updated_by
                      })) || []
                    };
                  }) || []
                };
              }) || [],

              // ----------------------- DIRECT SHARED -----------------------
              direct_shared: source.direct_shared?.map(ds => ({
                pfr_ds_id: uuid(),
                fpn_ds_id: uuid(),
                account_id: uuid(),
                account_expenses_ytd: ds.account_expenses_ytd,
                account_remaining_balance: ds.account_remaining_balance,
                account_reported_expenses: ds.account_reported_expenses,
                account_line_status: ds.account_line_status,
                account_line_comments: ds.account_line_comments,
                account_line_amount: ds.account_line_amount,
                account: ds.account,
                account_description: ds.account_description,
                created_by: ds.created_by,
                last_updated_by: ds.last_updated_by
              })) || [],

              // ----------------------- INDIRECT SUPPORT -----------------------
              indirect_support: source.indirect_support?.map(isc => ({
                pfr_isc_id: uuid(),
                fpn_isc_id: uuid(),
                account_id: uuid(),
                lookup_type_id: uuid(),
                account_expenses_ytd: isc.account_expenses_ytd,
                account_remaining_balance: isc.account_remaining_balance,
                account_reported_expenses: isc.account_reported_expenses,
                partner_type: isc.partner_type,
                partner_percentage: isc.partner_percentage,
                total_cost: isc.total_cost,
                // shared_cost: isc.shared_cost,
                account: isc.account,
                account_description: isc.account_description,
                created_by: isc.created_by,
                last_updated_by: isc.last_updated_by
              })) || []
            }
          }
        ]
      };

      return result;
    }

    createPayloadForPFR(pfrdata, reportingPeriod, headerDetail, comments, userDetails, direct_shared, indirect_support, shared_cost, budget_flexibility, status, indirectPartnerType, indirectPartnerPercentage, userCurrentRole, validationState, mode) {
      // console.log("reportingPeriod" + JSON.stringify(reportingPeriod));
      if (!Array.isArray(pfrdata)) return { items: [] };
      let createdBy = '';

      const lastUpdatedBy = userDetails;

      const items = pfrdata.map(item => {
        const pfr = item.pfr || {};
        // const draftSubmissionStatus = status;
        // let updatedDraftStatus = draftSubmissionStatus;
        // const budgetFlexibilityValue = budget_flexibility.replace('%', '');
        // if (draftSubmissionStatus.includes("-")) {
        //   const [status] = draftSubmissionStatus.split("-");
        //   updatedDraftStatus = `${status}-${budgetFlexibilityValue}`;
        // } else {
        //   updatedDraftStatus = `${draftSubmissionStatus}-${budgetFlexibilityValue}`;
        // }
        if (mode === 'CREATE') {
          createdBy = userDetails;
        }
        else {
          createdBy = pfr.created_by;
        }
        return {
          pfr: {
            // pfr_id: pfr.pfr_id,
            // fpn_id: pfr.fpn_id,
            pfr_code: pfr.pfr_code,
            fpn_code: pfr.fpn_code,
            pfr_status: pfr.pfr_status,
            pfr_major_version: pfr.pfr_major_version,
            pfr_minor_version: pfr.pfr_minor_version,
            contract_currency_code: pfr.contract_currency_code,
            cost_center: pfr.cost_center,
            cost_center_name: pfr.cost_center_name,
            operation_code: pfr.operation_code,
            po_number: pfr.po_number,
            partner_number: pfr.partner_number,
            validation_state: validationState,
            created_date: pfr.created_date,
            business_unit: pfr.business_unit,
            in_capacity_of: userCurrentRole,
            total_pfr_expenses: pfr.total_pfr_expenses,
            pfr_comments: comments,
            draft_submission_status: status,
            budget_flexibility: budget_flexibility,
            reporting_period: reportingPeriod ? [{
              ...reportingPeriod
            }] : [],
            operation_name: pfr.operation_name,
            budget_year: pfr.budget_year,
            partner_name: pfr.partner_name,
            partner_site_code: pfr.partner_site_code,
            contract_number: pfr.contract_number,
            total_original_budget: pfr.total_original_budget,
            total_negotiated_budget: pfr.total_negotiated_budget,
            total_direct_programme_cost: pfr.total_direct_programme_cost,
            total_direct_shared_cost: pfr.total_direct_shared_cost,
            total_indirect_support_cost: pfr.total_indirect_support_cost,
            created_by: createdBy || '',
            last_updated_by: lastUpdatedBy || '',

            // ----- Outputs -----
            outputs: (pfr.outputs || []).map(output => ({
              // pfr_output_id: output.pfr_output_id,
              output_line_status: output.lineStatus,
              output_line_comments: output.comments || "",
              output_total_negotiated_budget: output.negotiated_budget || 0,
              output_direct_programme_budget: output.value || 0,
              output_direct_shared_budget: output.ds || 0,
              output_indirect_support_budget: output.psc || 0,
              output_expenses_ytd: output.expenses_ytd || 0,
              output_remaining_balance: output.remaining_balance || 0,
              output_direct_programme_expenses: output.reported_expenses || 0,
              output_indirect_support_expenses: output.psc_expenses || 0,
              output_direct_shared_expenses: output.ds_expenses || 0,
              output_total_negotiated_expenses: output.negotiated_expenses || 0,
              // fpn_output_id: output.fpn_output_id,
              output_code: output.outputCode,
              output_description: output.outputDescription,
              created_by: createdBy || '',
              last_updated_by: lastUpdatedBy || '',
              // last_baseline: output.last_baseline,
              // total_expenses: output.total_expenses,
              implementation_rate: output.implementation_rate || '',
              // ----- Locations -----
              locations: (output.locations || []).map(location => ({
                // pfr_output_id: location.pfr_output_id,
                // pfr_location_id: location.pfr_location_id,
                location_line_status: location.lineStatus,
                location_line_comments: location.comments || "",
                location_total_negotiated_budget: location.negotiated_budget || 0,
                location_direct_programme_budget: location.value || 0,
                location_direct_shared_budget: location.ds || 0,
                location_indirect_support_budget: location.psc || 0,
                location_expenses_ytd: location.expenses_ytd || 0,
                location_remaining_balance: location.remaining_balance || 0,
                // location_reported_expenses: location.reported_expenses || 0,
                location_direct_programme_expenses: location.reported_expenses || 0,
                location_indirect_support_expenses: location.psc_expenses || 0,
                location_direct_shared_expenses: location.ds_expenses || 0,
                location_total_negotiated_expenses: location.negotiated_expenses || 0,
                location_code: location.locationCode,
                location_description: location.location_description,
                created_by: createdBy || '',
                last_updated_by: lastUpdatedBy || '',
                // last_baseline: location.last_baseline ,
                // total_expenses: location.total_expenses,
                implementation_rate: location.implementation_rate || '',

                // ----- Accounts -----
                accounts: (location.accounts || []).map(account => ({
                  // pfr_output_id: account.pfr_output_id,
                  // pfr_location_id: account.pfr_location_id,
                  // pfr_account_id: account.pfr_account_id,
                  account_line_status: account.lineStatus,
                  account_line_comments: account.comments || "",
                  account_expenses_ytd: account.expenses_ytd || 0,
                  account_remaining_balance: account.remaining_balance || 0,
                  account_reported_expenses: account.reported_expenses || 0,
                  account_category: account.account_category,
                  // fpn_account_id: account.fpn_account_id,
                  account_line_amount: account.value,
                  account: account.accountCode,
                  account_description: account.accountDescription,
                  created_by: createdBy || '',
                  last_updated_by: lastUpdatedBy || '',
                  // last_baseline: account.last_baseline,
                  // total_expenses: account.total_expenses,
                  implementation_rate: account.implementation_rate || ''
                }))
              }))
            })),

            // ----- Direct Shared -----
            direct_shared: (direct_shared || []).map(ds => ({
              // pfr_ds_id: ds.pfr_ds_id,
              // account_id: ds.account_id,
              account_expenses_ytd: ds.expenses_ytd || 0,
              account_category: "DS",
              account_remaining_balance: ds.remaining_balance || 0,
              account_reported_expenses: ds.reported_expenses || 0,
              account_line_status: ds.account_line_status || "",
              account_line_comments: ds.account_line_comments || "",
              // fpn_ds_id: ds.fpn_ds_id,
              account_line_amount: ds.account_line_amount,
              account: ds.account_number,
              account_description: ds.account_description,
              created_by: createdBy || '',
              last_updated_by: lastUpdatedBy || ''
            })),

            // ----- Indirect Support -----
            indirect_support: (indirect_support || []).map(isc => ({
              // pfr_isc_id: isc.pfr_isc_id,
              // account_id: isc.account_id,
              // lookup_type_id: shared_cost,
              account_expenses_ytd: isc.expenses_ytd || 0,
              account_category: "IS",
              account_remaining_balance: isc.remaining_balance || 0,
              account_reported_expenses: isc.reported_expenses || 0,
              // fpn_isc_id: isc.fpn_isc_id,
              total_cost: isc.total_cost || 0,
              partner_type: isc.partner_type || indirectPartnerType || '',
              partner_percentage: isc.partner_percentage || indirectPartnerPercentage || '',
              // shared_cost: shared_cost,
              account: isc.account_number,
              account_description: isc.account_description,
              created_by: createdBy || '',
              last_updated_by: lastUpdatedBy || ''
            }))
          }
        };
      });

      return { items };
    }

    updatePfrData(oldData, newData) {

      console.log("Old Outputs:", oldData);
      console.log("New Outputs:", newData);
      // Step 1: Ensure oldData and newData are valid and have `outputs`
      const oldPfr = oldData[0]?.pfr;
      const newPfr = newData[0]?.pfr;

      // Check if both oldData and newData contain the `pfr` object
      if (!oldPfr || !newPfr) {
        console.error("Error: Missing 'pfr' data in oldData or newData.");
        return oldData;  // Return oldData if 'pfr' is missing
      }

      const oldOutputs = oldPfr.outputs || [];
      const newOutputs = newPfr.outputs || [];

      // Step 2: If no outputs found in either data, log and return oldData unmodified
      if (!oldOutputs.length || !newOutputs.length) {
        console.error("Error: No 'outputs' found in either oldData or newData.");
        return oldData;  // Return oldData unmodified
      }

      console.log("Old Outputs:", oldOutputs);
      console.log("New Outputs:", newOutputs);

      // Step 3: Iterate through oldOutputs and update the corresponding fields based on account_number
      oldOutputs.forEach(oldOutput => {
        const newOutput = newOutputs.find(output => output.outputCode === oldOutput.outputCode);

        if (newOutput) {
          // Step 4: Iterate through locations in both outputs
          oldOutput.locations.forEach(oldLocation => {
            const newLocation = newOutput.locations.find(loc => loc.locationCode === oldLocation.locationCode);

            if (newLocation) {
              // Step 5: Update account information within the location
              oldLocation.accounts.forEach(oldAccount => {
                const newAccount = newLocation.accounts.find(acc => acc.accountCode === oldAccount.accountCode);

                if (newAccount) {
                  // Update the necessary fields for the account
                  oldOutput.expenses_ytd = newOutput.expenses_ytd;
                  oldOutput.remaining_balance = newOutput.remaining_balance;
                  oldOutput.reported_expenses = newOutput.reported_expenses;
                  oldLocation.expenses_ytd = newLocation.expenses_ytd;
                  oldLocation.remaining_balance = newLocation.remaining_balance;
                  oldLocation.reported_expenses = newLocation.reported_expenses;
                  oldAccount.expenses_ytd = newAccount.expenses_ytd;
                  oldAccount.remaining_balance = newAccount.remaining_balance;
                  oldAccount.reported_expenses = newAccount.reported_expenses;

                }
              });
            }
          });
        }
      });

      // Step 6: Now handle updating the `direct_shared` and `indirect_support` fields
      // Update Direct Shared
      oldPfr.direct_shared?.forEach(oldDS => {
        const newDS = newPfr.direct_shared?.find(ds => ds.account_number === oldDS.account_number);

        if (newDS) {
          oldDS.expenses_ytd = newDS.expenses_ytd;
          oldDS.remaining_balance = newDS.remaining_balance;
          oldDS.reported_expenses = newDS.reported_expenses;

        }
      });

      // Update Indirect Support
      oldPfr.indirect_support?.forEach(oldIS => {
        const newIS = newPfr.indirect_support?.find(is => is.account_number === oldIS.account_number);

        if (newIS) {
          oldIS.expenses_ytd = newIS.expenses_ytd;
          oldIS.remaining_balance = newIS.remaining_balance;
          oldIS.reported_expenses = newIS.reported_expenses;

        }
      });

      // Return updated data
      return oldData;
    }


    isButtonDisabled(userRole, fpnStatus, operationName) {
      const role = userRole;
      const status = fpnStatus;
      const operation = (operationName || "").toLowerCase();

      const isPartner = role === "PARTNER_USER";
      const isOfficer =
        role === "SENIOR_PROGRAMME_OFFICER" ||
        role === "JUNIOR_PROGRAMME_OFFICER" ||
        role === "PFM_SUPERUSER";

      const isDraft = operation.includes("draft");
      const isSubmit = operation.includes("submit");

      /* ---------- PROPOSED ---------- */

      if (status === "Scoped") {
        if (isOfficer) return false;
        if (isPartner) return true;
        return true;
      }
      if (status === "Reallocation Request Sent") {
        if (isOfficer) return false;
        if (isPartner) return true;
        return true;
      }
      if (status === "Proposed") {
        if (isDraft && isOfficer) return false;
        if (isSubmit && isPartner) return false;
        return true;
      }

      /* ---------- ENDORSED / REVISED ---------- */
      if (status === "Endorsed" || status === "Revised") {
        if (isDraft && isPartner) return false;
        if (isSubmit && isOfficer) return false;
        return true;
      }

      /* ---------- AGREED ---------- */
      if (status === "Agreed") {
        if (isDraft && isOfficer) return false;
        return true;
      }

      /* ---------- APPROVED / UNDER REVIEW ---------- */
      if (status === "Approved" || status === "Under Review") {
        if (isSubmit && isPartner) return false;
        return true;
      }

      /* ---------- RESCOPED ---------- */
      if (status === "Rescoped") {
        if (isOfficer) return false;
        return true;
      }

      return true;
    }




    updateTreeDataProvider(programmeData) {
      const tree = this.convertArrayIntoTree(programmeData);
      const arrayTreeDP = new ArrayTreeDataProvider(tree, { keyAttributes: 'id' });
      this.dataSource(new FlattenedTreeDataProviderView(arrayTreeDP)); // set observable value
    }
    /**
     *
     * @param {string} arg1
     * @return {string}
     */
    convertArrayIntoTree(programmeData) {
      console.log("programmeData" + JSON.stringify(programmeData));
      const tree = [];
      const uniqueIdPrefix = Date.now(); // Use current time as a unique prefix

      // Guard: check input data
      if (!Array.isArray(programmeData)) {
        return tree;
      }

      programmeData.forEach(item => {
        const pfrCode = item?.pfr?.pfr_code;
        const outputs = Array.isArray(item?.pfr?.outputs) ? item.pfr.outputs : [];

        outputs.forEach(output => {
          if (!output) return;

          // Stable Output ID
          const outputNode = {
            id: `output-${output.outputCode}`,
            type: 'output',
            name: output.outputDescription ?? '',
            outputCode: output.outputCode ?? '',
            outputDescription: output.outputDescription ?? '',
            negotiated_budget: output.negotiated_budget ?? null,
            psc: output.psc ?? null,
            ds: output.ds ?? null,
            value: output.value ?? null,
            expenses_ytd: output.expenses_ytd ?? null,
            remaining_balance: output.remaining_balance ?? null,
            reported_expenses: output.reported_expenses ?? null,
            negotiated_expenses: output.negotiated_expenses ?? null,
            psc_expense: output.psc_expense ?? null,
            ds_expenses: output.ds_expenses ?? null,
            last_baseline: output.last_baseline ?? null,
            total_expenses: output.total_expenses ?? null,
            comments: output.comments ?? '',
            implementation_rate: output.implementation_rate ?? null,
            lineStatus: output.lineStatus
              ? output.lineStatus.charAt(0).toUpperCase() + output.lineStatus.slice(1).toLowerCase()
              : '',
            children: [] // Locations
          };

          const locations = Array.isArray(output.locations) ? output.locations : [];

          locations.forEach(location => {
            if (!location) return;

            // Stable Location ID
            const locationNode = {
              id: `location-${output.outputCode}-${location.locationCode}`,
              pfr_output_id: location.pfr_output_id ?? null,
              pfr_location_id: location.pfr_location_id ?? null,
              type: 'location',
              name: location.locationCode ?? '',
              locationCode: location.locationCode ?? '',
              negotiated_budget: location.negotiated_budget ?? null,
              psc: location.psc ?? null,
              ds: location.ds ?? null,
              value: location.value ?? null,
              expenses_ytd: location.expenses_ytd ?? null,
              remaining_balance: location.remaining_balance ?? null,
              reported_expenses: location.reported_expenses ?? null,
              negotiated_expenses: location.negotiated_expenses ?? null,
              psc_expense: output.psc_expense ?? null,
              ds_expenses: output.ds_expenses ?? null,
              last_baseline: location.last_baseline ?? null,
              total_expenses: location.total_expenses ?? null,
              comments: location.comments ?? '',
              implementation_rate: location.implementation_rate ?? null,
              lineStatus: location.lineStatus
                ? location.lineStatus.charAt(0).toUpperCase() + location.lineStatus.slice(1).toLowerCase()
                : '',
              children: [] // Accounts
            };

            const accounts = Array.isArray(location.accounts) ? location.accounts : [];

            accounts.forEach(account => {
              if (!account) return;
              if (account.account_category !== 'DP') return;
              // Stable Account ID
              const accountNode = {
                id: `account-${output.outputCode}-${location.locationCode}-${account.accountCode}`,
                pfr_account_id: account.id ?? null,
                pfr_location_id: account.pfr_location_id ?? null,
                pfr_output_id: account.pfr_output_id ?? null,
                loc: location.locationCode ?? null,
                pfr_location_code: location.locationCode ?? null,
                pfr_output_code: output.outputCode ?? null,
                pfr_code: pfrCode,
                type: 'account',
                name: account.accountDescription ?? '',
                accountCode: account.accountCode ?? '',
                accountDescription: account.accountDescription ?? '',
                value: account.value ?? null,
                expenses_ytd: account.expenses_ytd ?? null,
                remaining_balance: account.remaining_balance ?? null,
                reported_expenses: account.reported_expenses ?? null,
                last_baseline: account.last_baseline ?? null,
                total_expenses: account.total_expenses ?? null,
                comments: account.comments ?? '',
                implementation_rate: account.implementation_rate ?? null,
                lineStatus: account.lineStatus
              };

              locationNode.children.push(accountNode);
            });

            outputNode.children.push(locationNode);
          });

          tree.push(outputNode);
        });
      });
      console.log("tree" + JSON.stringify(tree));
      return tree;
    }

    getIdFromMessage(message) {


      const match = message.match(/ID\s*(\d+)/);
      let pfrId = match ? Number(match[1]) : null;
      return pfrId;
    }

    /**
     *
     * @param {string} arg1
     * @return {string}
     */
    // updateADP(input2, input1) {
    //   let updatedData = JSON.parse(JSON.stringify(input2));

    //   for (const pfrWrapper of updatedData) {
    //     const pfr = pfrWrapper.pfr;
    //     if (!pfr.outputs) continue;

    //     for (const output of pfr.outputs) {
    //       if (output.pfr_output_id != input1.pfr_output_id) continue;

    //       for (const location of output.locations) {
    //         if (location.pfr_location_id != input1.pfr_location_id) continue;

    //         for (let i = 0; i < location.accounts.length; i++) {
    //           let account = location.accounts[i];

    //           // match by id or accountCode
    //           if (
    //             (account.id && account.id == input1.pfr_account_id) ||
    //             account.accountCode == input1.accountCode
    //           ) {
    //             // update value & comments etc.
    //             location.accounts[i] = {
    //               ...account,
    //               ...input1, // merge new fields
    //             };
    //           }
    //         }
    //       }
    //     }
    //   }

    //   return updatedData;
    // }

    updateADP(data, updatedRow) {
      // Instead of deep cloning the entire dataset, clone only what's needed
      const updatedData = data.map(pfrWrapper => {
        const pfr = pfrWrapper.pfr;

        if (!pfr?.outputs || pfr.pfr_code !== updatedRow.pfr_code) {
          return pfrWrapper;
        }

        const newOutputs = pfr.outputs.map(output => {
          if (output.outputCode !== updatedRow.pfr_output_code) return output;

          const newLocations = (output.locations || []).map(location => {
            if (location.locationCode !== updatedRow.pfr_location_code) return location;

            const newAccounts = location.accounts.map(account => {
              if (String(account.accountCode) === String(updatedRow.accountCode)) {
                return { ...account, ...updatedRow };
              }
              return account;
            });

            return { ...location, accounts: newAccounts };
          });

          return { ...output, locations: newLocations };
        });

        return { ...pfrWrapper, pfr: { ...pfr, outputs: newOutputs } };
      });

      return updatedData;
    }


    /**
     *
     * @param {string} arg1
     * @return {string}
     */
    dsupdateAdpData(adp, currentRowObj) {

      if (!adp || !adp.data || !Array.isArray(adp.data)) {
        // console.error("Invalid ADP object");
        return;
      }

      // Get existing ADP data
      let data = adp.data;

      // Find index of the row with matching account_id
      let index = data.findIndex(row => row.account_number === currentRowObj.account_number);

      if (index !== -1) {
        // Update only that row (merge old row + new values)
        data[index] = {
          ...data[index],
          ...currentRowObj
        };

        // Push updated data back to ADP so VBCS detects change
        adp.data = [...data];
      } else {
        // console.warn("No matching row found for account_id:", currentRowObj.account_id);
      }

      return adp.data;
    }

    separateDppfrCommentIds(fullId) {
      if (typeof fullId !== 'string' || !fullId.includes('-')) {
        return null;
      }
      const parts = fullId.split('-');

      if (parts.length !== 5) {
        return null;
      }

      return {
        outputid: parts[1],
        locationid: parts[2],
        accountid: parts[4], // The account/accountid is now the 5th part (index 4).
      };
    }


    /**
     *
     * @param {string} arg1
     * @return {string}
     */
    selectedOutpuandLocations(adpData, selection) {
      console.log("adpdata" + JSON.stringify(adpData));
      console.log("selection" + JSON.stringify(selection));
      console.time("optimizedSelection");

      const outputs = adpData?.[0]?.pfr?.outputs || [];
      if (!outputs.length || !selection?.length) return [];

      const uniqueSet = new Set();
      const result = [];

      // ✅ Preprocess selections
      const selectedOutputCodes = new Set();
      const selectedLocations = new Set(); // key = outputCode|locationCode
      const selectedAccounts = []; // {outputCode, locationCode}

      for (const sel of selection) {
        if (typeof sel !== "string") continue;

        const parts = sel.split("-");

        if (parts[0] === "output") {
          // output-GMRD00F10S
          selectedOutputCodes.add(parts[1]);

        } else if (parts[0] === "location") {
          // location-GMRD00F10S-MRT-XXX-XXX-LCN-01
          const outputCode = parts[1];
          const locationCode = parts.slice(2).join("-");
          selectedLocations.add(`${outputCode}|${locationCode}`);

        } else if (parts[0] === "account") {
          // account-GMRD00F10S-MRT-XXX-XXX-LCN-01-611101
          const outputCode = parts[1];
          const accountCode = parts.pop(); // last item
          const locationCode = parts.slice(2).join("-");

          selectedAccounts.push({ outputCode, locationCode, accountCode });
        }
      }

      // ✅ Case 1: Output selected → include all locations
      for (const output of outputs) {
        const { outputCode, pfr_output_id, locations = [] } = output;

        if (selectedOutputCodes.has(outputCode)) {
          if (locations.length) {
            for (const loc of locations) {
              const key = `${outputCode}|${loc.locationCode}`;
              if (!uniqueSet.has(key)) {
                uniqueSet.add(key);
                result.push({
                  output: outputCode,
                  location: loc.locationCode,
                  pfr_output_id,
                  pfr_location_id: loc.pfr_location_id
                });
              }
            }
          } else {
            const key = `${outputCode}|`;
            if (!uniqueSet.has(key)) {
              uniqueSet.add(key);
              result.push({
                output: outputCode,
                location: "",
                pfr_output_id,
                pfr_location_id: null
              });
            }
          }
        }
      }

      // ✅ Case 2: Location selected
      for (const output of outputs) {
        for (const loc of output.locations || []) {
          const key = `${output.outputCode}|${loc.locationCode}`;
          if (selectedLocations.has(key) && !uniqueSet.has(key)) {
            uniqueSet.add(key);
            result.push({
              output: output.outputCode,
              location: loc.locationCode,
              pfr_output_id: output.pfr_output_id,
              pfr_location_id: loc.pfr_location_id
            });
          }
        }
      }

      // ✅ Case 3: Account selected
      for (const { outputCode, locationCode } of selectedAccounts) {
        const output = outputs.find(o => o.outputCode === outputCode);
        if (!output) continue;

        const loc = output.locations?.find(l => l.locationCode === locationCode);
        if (!loc) continue;

        const key = `${outputCode}|${locationCode}`;
        if (!uniqueSet.has(key)) {
          uniqueSet.add(key);
          result.push({
            output: outputCode,
            location: locationCode,
            pfr_output_id: output.pfr_output_id,
            pfr_location_id: loc.pfr_location_id
          });
        }
      }

      // ✅ Format (hide duplicate output names)
      const formatted = [];
      let lastOutput = null;

      for (const item of result) {
        if (item.output === lastOutput) {
          formatted.push({ ...item, output: "" });
        } else {
          formatted.push(item);
          lastOutput = item.output;
        }
      }

      console.timeEnd("optimizedSelection");
      return formatted;
    }
    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    updateAccountLineStatus(adpData, selectedData, selectedStatus) {
      // deep clone so caller's data isn't mutated
      const updated = JSON.parse(JSON.stringify(adpData || []));

      selectedData.forEach(sel => {
        updated.forEach(wrapper => {
          const outputs = wrapper?.pfr?.outputs || [];
          outputs.forEach(output => {
            if (output.pfr_output_id === sel.pfr_output_id) {
              (output.locations || []).forEach(location => {
                if (location.pfr_location_id === sel.pfr_location_id) {
                  (location.accounts || []).forEach(account => {
                    // find existing key name (case-insensitive)
                    const existingKey = Object.keys(account).find(k => k.toLowerCase() === 'linestatus');

                    if (existingKey) {
                      // update that exact key (avoids creating a new one)
                      account[existingKey] = selectedStatus;
                    } else {
                      // fallback: create lowercase 'linestatus' if none present
                      account.linestatus = selectedStatus;
                    }
                  });
                }
              });
            }
          });
        });
      });

      return updated;
    }


    // DS -> To get selected rows

    dsgetSelectedRows(accountList, selectedIds) {

      if (!Array.isArray(accountList) || !Array.isArray(selectedIds)) {
        return [];
      }

      return accountList.filter(row => selectedIds.includes(row.account_number));
    }

    // DS -> To update status for selected Rows

    dsUpdateStatus(adp1Data, adp2Data, newStatus) {
      if (!Array.isArray(adp1Data) || !Array.isArray(adp2Data) || typeof newStatus !== "string") {
        return adp2Data;
      }

      // Collect all account_ids from adp1
      const accountIds = adp1Data.map(row => row.account_id);

      // Update only the matching rows in adp2
      return adp2Data.map(row => {
        if (accountIds.includes(row.account_id)) {
          return { ...row, account_line_status: newStatus };
        }
        return row;
      });
    }

    validateFpnData(fpn, pfrComment, pfr_type, directShared, indirectsupport) {

      // --- 🔹 Step 1: Normalize comment (handle null/undefined safely)
      const comment = (pfrComment || '').trim();
      const commentPattern = /^[^<>]{3,250}$/;

      // --- 🔹 Step 2: Validate presence (mandatory field)
      if (!comment) {
        return {
          valid: false,
          message: 'PFR Comment is mandatory and cannot be blank.',
        };
      }
      if (!commentPattern.test(comment)) {
        return {
          valid: false,
          message: 'Please enter plain text only (3–250 characters). Rich text or HTML is not allowed.',
        };
      }
      // --- 🔹 Step 3: Validate character length (max 255)
      if (comment.length > 255) {
        return {
          valid: false,
          message: 'PFR Comment must not exceed 255 characters.',
        };
      }

      // --- 🔹 Step 4: Validate Direct Shared data (if present)
      // for (const ds of directShared || []) {
      //   const val = ds.reported_expenses;
      //   const hasValue = val !== null && val !== undefined && val !== '';
      //   const num = hasValue ? Number(val) : NaN;

      //   // Validate Credit Note: must be present and negative
      //   // if (
      //   //   pfr_type === 'Credit Note' &&
      //   //   (
      //   //     !hasValue ||         // blank / missing is invalid
      //   //     isNaN(num) ||        // non-numeric is invalid
      //   //     num >= 0             // must be negative
      //   //   )
      //   // ) {
      //   //   return {
      //   //     valid: false,
      //   //     message: `For Credit Note, only negative expenses are allowed for account ${ds.account_number} in Direct Shared.`,
      //   //   };
      //   // }

      //   // For 'Periodic' or 'End-PFR', do not allow negative values (if value provided)
      //   // if (
      //   //   (pfr_type === 'Periodic' || pfr_type === 'End-PFR') &&
      //   //   hasValue &&           // only validate if a value was provided
      //   //   !isNaN(num) &&        // and it is numeric
      //   //   num < 0               // negative not allowed
      //   // ) {
      //   //   return {
      //   //     valid: false,
      //   //     message: `For ${pfr_type}, negative expenses are not allowed for account ${ds.account_number} in Direct Shared.`,
      //   //   };
      //   // }

      //   // ... other validations for this ds
      // }

      // --- 🔹 Step 5: Validate Indirect Support data (if present)
      // for (const ids of indirectsupport || []) {
      //   const val = ids.reported_expenses;
      //   const hasValue = val !== null && val !== undefined && val !== '';
      //   const num = hasValue ? Number(val) : NaN;

      //   // 🔹 Validate Credit Note: must be present and negative
      //   if (
      //     pfr_type === 'Credit Note' &&
      //     (
      //       !hasValue ||         // blank / missing is invalid
      //       isNaN(num) ||        // non-numeric is invalid
      //       num >= 0             // must be negative
      //     )
      //   ) {
      //     return {
      //       valid: false,
      //       message: `For Credit Note, only negative expenses are allowed for account ${ids.account_number} in Indirect Support.`,
      //     };
      //   }

      //   // 🔹 For 'Periodic' or 'End-PFR', do not allow negative values
      //   if (
      //     (pfr_type === 'Periodic' || pfr_type === 'End-PFR') &&
      //     hasValue &&           // only validate if a value was provided
      //     !isNaN(num) &&        // and it is numeric
      //     num < 0               // negative not allowed
      //   ) {
      //     return {
      //       valid: false,
      //       message: `For ${pfr_type}, negative expenses are not allowed for account ${ids.account_number} in Indirect Support.`,
      //     };
      //   }

      //   //  (any other validations for this ids)
      // }


      for (const output of fpn.outputs || []) {

        // if (output.lineStatus === 'Revised' && (!output.comments || output.comments.trim() === '')) {
        //   return {
        //     valid: false,
        //     message: `Comments are mandatory for output with code ${output.outputCode} because lineStatus is Revised.`,
        //   };
        // }

        for (const location of output.locations || []) {
          // if (location.lineStatus === 'Revised' && (!location.comments || location.comments.trim() === '')) {
          //   return {
          //     valid: false,
          //     message: `Comments are mandatory for location ${location.locationCode} because lineStatus is Revised.`,
          //   };
          // }

          for (const account of location.accounts || []) {
            if (account.lineStatus === 'Revised' && (!account.comments || account.comments.trim() === '')) {
              return {
                valid: false,
                message: `Comments are mandatory for account ${account.accountDescription} because lineStatus is Revised.`,
              };
            }
            // value must always be present (non-null, non-undefined, non-empty)
            // if (
            //   pfr_type === 'Credit Note' &&
            //   account.reported_expenses !== null &&
            //   account.reported_expenses !== undefined &&
            //   account.reported_expenses !== '' &&
            //   account.reported_expenses >= 0
            // ) {
            //   return {
            //     valid: false,
            //     message: `For Credit Note, only negative expenses are allowed for account ${account.accountDescription} in Direct Programme.`,
            //   };
            // }
            // // 🔹 New condition: For 'Periodic' or 'End-PFR', do not allow negative values
            // if (
            //   (pfr_type === 'Periodic' || pfr_type === 'End-PFR') &&
            //   account.reported_expenses !== null &&
            //   account.reported_expenses !== undefined &&
            //   account.reported_expenses !== '' &&
            //   account.reported_expenses < 0
            // ) {
            //   return {
            //     valid: false,
            //     message: `For ${pfr_type}, negative expenses are not allowed for account ${account.accountDescription} in Direct Programme.`,
            //   };
            // }
          }


        }
      }

      return { valid: true };
    }
    populateDirectsharedRows(sheet, pfrData) {
      if (!Array.isArray(pfrData) || pfrData.length === 0) return;

      for (const ds of pfrData) {
        const row = sheet.addRow([
          ds.account_number || '',
          ds.account_description || '',
          ds.account_line_amount || 0,
          ds.expenses_ytd || 0,
          ds.remaining_balance || 0,
          ds.reported_expenses || 0,
          ds.account_line_comments || ''
          // ds.account_line_status 
        ]);
        this.styleDataRowDs(row);
      }
    }




    /**
     *
     * @param {string} arg1
     * @return {string}
     */
    async importExcelToADP(event) {
      try {
        // 1️⃣ Get the file (supports both oj-file-picker and input type="file")
        let file = null;

        if (event[0]) {
          // Case: oj-file-picker
          file = event[0];
        } else {
          // Case: input type="file"
          const fileInput = document.getElementById('excelFileInput');
          file = fileInput?.files?.[0];
        }

        if (!file) {
          console.error('No Excel file selected');
          return [];
        }

        // 2️⃣ Read Excel file as ArrayBuffer using FileReader
        const data = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = (e) => resolve(e.target.result);
          reader.onerror = (e) => reject(e);
          reader.readAsArrayBuffer(file);
        });

        // 3️⃣ Load ExcelJS workbook
        const workbook = new ExcelJS.Workbook();
        await workbook.xlsx.load(data);

        // 4️⃣ Read first worksheet
        const worksheet = workbook.worksheets[0];
        const importedData = [];
        const headers = [];

        // 5️⃣ Extract header row
        worksheet.getRow(1).eachCell((cell) => headers.push(cell.value));

        // 6️⃣ Define header mapping
        const fieldMapping = {
          "Account": "account_number",
          "Account Description": "account_description",
          "account_id": null,
          "Planned": "account_line_amount",
          "Expenses YTD": "expenses_ytd",
          "Remaining Balance": "remaining_balance",
          "Reported Expenses": "reported_expenses",
          "Comments": "account_line_comments",
          "Status": "account_line_status",
          "pfr_ds_id": null,
          "fpn_ds_id": 349

        };

        // 7️⃣ Read data rows
        worksheet.eachRow((row, rowNumber) => {
          if (rowNumber === 1) return; // Skip header

          const rowData = {};
          let isValid = true;

          row.eachCell((cell, colNumber) => {
            const headerName = headers[colNumber - 1];
            const mappedField = fieldMapping[headerName];
            if (mappedField) {
              let value = cell.value;

              // Validate Account column (should be number)
              if (mappedField === "account_number") {
                if (isNaN(value)) {
                  console.warn(`Invalid Account value (not a number) at row ${rowNumber}:`, value);
                  isValid = false;
                } else {
                  value = Number(value);
                }
              }

              rowData[mappedField] = value;
            }
          });

          if (isValid) importedData.push(rowData);
        });

        // 8️⃣ Assign to ADP variable (optional)
        // $page.variables.myADPArrayData = importedData;

        console.log("✅ Excel imported successfully:", importedData);
        return importedData;

      } catch (error) {
        console.error("❌ Error importing Excel:", error);
        return [];
      }
    }

    parseExcelFile(file) {
      return new Promise((resolve, reject) => {
        const rows = {
          directProgramme: [],
          directShared: [],
          headers: []
        };

        const fileReader = new FileReader();
        fileReader.onload = (e) => {
          try {
            const data = new Uint8Array(e.target.result);
            const workbook = XLSX.read(data, { type: "array" });

            // === Direct Programme sheet ===
            const dpSheet = workbook.Sheets["Direct Programme"];
            if (dpSheet) {
              const jsonDP = XLSX.utils.sheet_to_json(dpSheet, { header: 1 });
              rows.headers = jsonDP[0] || [];
              for (let i = 1; i < jsonDP.length; i++) {
                const row = jsonDP[i];
                if (!row || row.every(cell => cell === undefined || String(cell).trim() === '')) {
                  continue;
                }
                rows.directProgramme.push({
                  pfr_code: String(row[0] || '').trim(),
                  outputCode: String(row[1] || '').trim(),
                  locationCode: String(row[2] || '').trim(),
                  // lineStatus: row[3] || null,
                  accountCode: String(row[3] || '').trim(),
                  accountDescription: String(row[4] || '').trim(),
                  // baseLine: Number(row[5]) || 0,
                  value: Number(row[5]) || 0,
                  expenses_ytd: Number(row[6]) || 0,
                  remaining_balance: Number(row[7]) || 0,
                  reported_expenses: Number(row[8]) || 0,
                  comments: String(row[9] || '').trim()

                });
              }
            }

            // === Direct Shared sheet ===
            const dsSheet = workbook.Sheets["Direct Shared"];
            if (dsSheet) {
              const jsonDS = XLSX.utils.sheet_to_json(dsSheet, { header: 1 });
              for (let i = 1; i < jsonDS.length; i++) {
                const row = jsonDS[i];
                if (!row || row.every(cell => cell === undefined || String(cell).trim() === '')) {
                  continue;
                }
                rows.directShared.push({
                  accountCode: String(row[0] || '').trim(),
                  accountDescription: String(row[1] || '').trim(),
                  account_line_amount: Number(row[2]) || 0,
                  expenses_ytd: Number(row[3]) || 0,
                  remaining_balance: Number(row[4]) || 0,
                  reported_expenses: Number(row[5]) || 0,
                  comments: String(row[6] || '').trim(),
                  // status: String(row[7] || '').trim(),
                });
              }
            }

            resolve(rows);
          } catch (err) {
            reject(err);
          }
        };

        fileReader.readAsArrayBuffer(file);
      });
    }

    validateRowsAgainstTree(rows, existingTree, validAccounts = []) {
      console.log("existingTree" + JSON.stringify(existingTree));
      const validRows = [];
      const invalidRows = [];
      const validAccountNumbers = new Set(
        validAccounts.map(acc => String(acc.account_number).trim())
      );
      const locationAccountMap = new Map();

      rows.forEach(row => {
        const failureReasons = [];

        const pfr_code = String(row.pfr_code || '').trim();
        const outputCode = String(row.outputCode || '').trim();
        const locationCode = String(row.locationCode || '').trim();
        const accountCode = String(row.accountCode || '').trim();

        const locationKey = `${pfr_code}__${outputCode}__${locationCode}`;

        // check for duplicate account codes at location level
        if (!locationAccountMap.has(locationKey)) {
          locationAccountMap.set(locationKey, new Set());
        }
        const seenAccounts = locationAccountMap.get(locationKey);

        if (seenAccounts.has(accountCode)) {
          failureReasons.push(`Duplicate Account Code "${accountCode}" under PFR "${pfr_code}" > Output "${outputCode}" > Location "${locationCode}"`);
        } else {
          seenAccounts.add(accountCode);
        }


        // --- Mandatory Field Checks ---
        if (!pfr_code) {
          failureReasons.push('PFR Code is required');
        }

        if (!outputCode) {
          failureReasons.push('Output code is required');
        }

        if (!locationCode) {
          failureReasons.push('Location code is required');
        }

        // --- Skip deeper checks if base fields are missing ---
        if (failureReasons.length === 0) {
          // --- FPN code exists ---
          const pfr = existingTree.find(p => p.pfr.pfr_code === pfr_code);
          if (!pfr) {
            failureReasons.push(`FPN code "${pfr_code}" does not exist`);
          }

          // --- Output exists ---
          const output = pfr?.pfr.outputs.find(o => o.outputCode === outputCode);
          if (!output) {
            failureReasons.push(`Output code "${outputCode}" does not exist under FPN "${pfr_code}"`);
          }

          // --- Location exists ---
          const location = output?.locations.find(l => l.locationCode === locationCode);
          if (!location) {
            failureReasons.push(`Location code "${locationCode}" does not exist under Output "${outputCode}"`);
          }

          // --- Account validation ---
          const locationAccounts = location?.accounts || [];

          const accountExistsInLocation = locationAccounts.some(
            acc => String(acc.accountCode).trim() === accountCode
          );


          if (!accountCode || !validAccountNumbers.has(accountCode)) {
            failureReasons.push(`Account code "${accountCode}" is not in allowed account list`);
          }

          if (!accountExistsInLocation) {
            failureReasons.push(
              `Account code "${accountCode}" does not exist under existing Location "${locationCode}"  (new accounts not allowed)`
            );
          }

          // --- Value check --- DS data
          if (isNaN(row.value) || row.value < 0) {
            failureReasons.push('Value must be a number and not negative');
          }
        }

        // --- Final Classification ---
        if (failureReasons.length === 0) {
          validRows.push(row);
        } else {
          invalidRows.push({
            ...row,
            failureReason: failureReasons.join('; ')
          });
        }
      });

      return { validRows, invalidRows };
    }

    validateDirectSharedRows(rows, existingDSData, validAccounts = []) {
      console.log("dsData" + JSON.stringify(existingDSData));
      const validRows = [];
      const invalidRows = [];

      const validAccountNumbers = new Set(
        validAccounts.map(acc => String(acc.account_number).trim())
      );
      // console.log('Valid Account Codes:', Array.from(validAccountNumbers));
      // console.log('Checking DS row:', rows);
      const existingAccountNumbers = new Set(
        (existingDSData || []).map(acc => String(acc.account_number).trim())
      );

      rows.forEach((row, index) => {
        const failureReasons = [];
        const accountCode = String(row.accountCode || '').trim();
        const reported_expenses = Number(row.reported_expenses);

        // Validate account code
        if (!accountCode || !validAccountNumbers.has(accountCode)) {
          failureReasons.push(`Account code "${accountCode}" is invalid or not allowed`);
        }
        if (!existingAccountNumbers.has(accountCode)) {
          failureReasons.push(
            `Account code "${accountCode}" does not exist in existing DS data (new accounts not allowed)`
          );
        }

        // Validate reported_expenses
        if (isNaN(reported_expenses)) {
          failureReasons.push(`Reported Expenses must be a number`);
        }

        if (failureReasons.length === 0) {
          validRows.push(row);
        } else {
          invalidRows.push({
            ...row,
            failureReason: failureReasons.join('; ')
          });
        }
      });

      return { validRows, invalidRows };
    }

    importFlatRowsToTree(flatRows, currentTreeData = []) {
      const treeTableADP = JSON.parse(JSON.stringify(currentTreeData));

      flatRows.forEach(row => {
        // --- Find existing FPN ---
        const pfrRow = treeTableADP.find(item => item.pfr.pfr_code === row.pfr_code);
        if (!pfrRow) {
          console.warn(`PFR not found: ${row.pfr_code}. Skipping row.`);
          return;
        }

        // --- Find existing Output ---
        const output = pfrRow.pfr.outputs.find(o => o.outputCode === row.outputCode);
        if (!output) {
          console.warn(`Output not found: ${row.outputCode} under FPN ${row.pfr_code}. Skipping row.`);
          return;
        }

        // --- Find existing Location ---
        const location = output.locations.find(l => l.locationCode === row.locationCode);
        if (!location) {
          console.warn(`Location not found: ${row.locationCode} under Output ${row.outputCode}. Skipping row.`);
          return;
        }


        let account = location.accounts.find(
          a => String(a.accountCode).trim() === String(row.accountCode).trim()
        );
        if (!account) {

          account = {
            id: Date.now() + Math.floor(Math.random() * 10000),
            pfr_location_id: location.fpn_location_id,
            loc: row.locationCode,
            pfr_output_id: output.fpn_output_id,
            outputCode: row.outputCode,
            accountCode: row.accountCode,
            accountDescription: row.accountDescription || "Unknown",
            // baseLine: row.baseLine,
            value: row.value,
            expenses_ytd: row.expenses_ytd,
            remaining_balance: row.remaining_balance,
            reported_expenses: row.reported_expenses,
            comments: row.comments,
            lineStatus: row.lineStatus
          };
          location.accounts.push(account);
        } else {

          if (row.accountDescription !== undefined) account.accountDescription = row.accountDescription;
          if (row.value !== undefined) account.value = row.value;
          if (row.reported_expenses !== undefined) account.reported_expenses = row.reported_expenses;
          if (row.comments !== undefined) account.comments = row.comments;
          if (row.lineStatus !== undefined && row.lineStatus !== null) account.lineStatus = row.lineStatus;
        }
      });

      return treeTableADP;
    }

    generateFailedRowsReport(invalidRows) {
      const worksheet = XLSX.utils.json_to_sheet(invalidRows);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Failed Rows');
      const wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
      const blob = new Blob([wbout], { type: 'application/octet-stream' });
      return URL.createObjectURL(blob);
    }


    downloadReport(url) {
      const a = document.createElement('a');
      a.href = url;
      a.download = 'failed_import_report.xlsx';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }

  }

  return PageModule;
});
