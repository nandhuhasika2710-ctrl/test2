define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ppOperationValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
      if ($application.variables.userRole === 'PARTNER_USER' && $application.variables.loginType === 'Partner') {
        await Actions.resetVariables(context, {
          variables: [
            '$variables.ppPartnerSelectedPersistVar',
          ],
        });
      }
      if ($variables.ppOperationSelectedVar === '' || $variables.ppOperationSelectedVar === null || $variables.ppOperationSelectedVar === undefined) {
        $variables.ppOperationSelectedPersistVar = [];

      } else {

        const setToArray = await $functions.setToArray($variables.ppOperationSelectedVar);

        $variables.ppOperationSelectedPersistVar = setToArray;
      }
      const array = Array.from(value || []);
      let operation = array.length > 0 ? array.join(',') : null;
      let valuesArray;
      let numberOfValues;
      if (operation !== null) {
        valuesArray = operation.split(',');
        numberOfValues = valuesArray.length;

        if (valuesArray.includes('ALL') && (numberOfValues > 1)) {
          // await Actions.fireNotificationEvent(context, {
          //   summary: 'Operation Lov Information',
          //   message: 'Please select SelectAll Option Only',
          //   displayMode: 'persist',
          // });

          await Actions.resetVariables(context, {
            variables: [
              '$variables.ppOperationSelectedVar',
            ],
          });
          operation = null;
        }
        else {
          if (operation === 'ALL' && $application.variables.loginType !== 'Partner') {
            const itemsArray = $application.variables.ppOperationLovADP.data;
            const allValuesArray = itemsArray.map(item => item.operation_code).filter(operation_code => operation_code !== "ALL");
            $variables.ppOperationSelectedVar = new Set(allValuesArray);

          }
          if (operation === 'ALL' && $application.variables.loginType === 'Partner') {
            const itemsArray = $application.variables.ppOperationLovADP.data;            // const allValuesArray = itemsArray.map(item => item.OperationCode).filter(OperationCode => OperationCode !== "ALL");
            const allValuesArray = itemsArray.map(item => item.operation_code).filter(operation_code => operation_code !== "ALL");
            $variables.ppOperationSelectedVar = new Set(allValuesArray);
            const response2 = await Actions.callRest(context, {
              endpoint: 'pfmGateway/getGetpartnerlov',
              uriParams: {
                'p_organizationid': $application.variables.userInfoObj.OrganizationId,
                'p_usertype': 'PARTNER',
              },
            });

            if (!response2.ok) {
              await Actions.fireNotificationEvent(context, {
                summary: 'Partner Lov Data Load Failed',
                displayMode: 'transient',
              });

              return;
            } else {
              let items = response2.body.items;
              items.unshift({
                partner_name: "Select All / Clear All",
                partner_number: 7777
              });
              $variables.ppPartnerLovADP.data = response2.body.items;
              $variables.defaultTypeNumberForPartner = response2.body.items.map(item => item.partner_number).filter(pn => pn !== 7777).join(',');


            }

          }

          if (operation !== 'ALL' && $application.variables.loginType !== 'Partner') {

            const response = await Actions.callRest(context, {
              endpoint: 'pfmGateway/getGetpartnerlov',
              uriParams: {
                poperation: operation,
                'p_usertype': 'UNHCR',
              },
            });

            if (!response.ok) {
              await Actions.fireNotificationEvent(context, {
                summary: 'Partner Lov Data Load Failed',
                message: response.status + ' - ' + response.statusText,
              });

            }
            else {
              let items = response.body.items;
              items.unshift({
                partner_name: "Select All / Clear All",
                partner_number: 7777
              });
              $variables.ppPartnerLovADP.data = response.body.items;
            }
          }
          if (operation !== 'ALL' && $application.variables.loginType === 'Partner') {
            const response3 = await Actions.callRest(context, {
              endpoint: 'pfmGateway/getGetpartnerlov',
              uriParams: {
                'p_organizationid': $application.variables.userInfoObj.OrganizationId,
                'p_usertype': 'PARTNER',
              },
            });

            if (!response3.ok) {
              await Actions.fireNotificationEvent(context, {
                summary: 'Partner Lov Data Load Failed',
                displayMode: 'transient',
              });

              return;
            } else {
              let items = response3.body.items;
              items.unshift({
                partner_name: "Select All / Clear All",
                partner_number: 7777
              });
              $variables.ppPartnerLovADP.data = response3.body.items;
              $variables.defaultTypeNumberForPartner = response3.body.items.map(item => item.partner_number).filter(pn => pn !== 7777).join(',');
            }

          }
        }
      }





      if (operation == null) {
        $variables.ppPartnerLovADP.data = [];
        // $variables.ppContractNumberADP.data = [];
        $variables.ppOperationSelectedVar = '';
        $variables.ppPartnerSelectedPersistVar = [];
        // $variables.ppContractNumberSelectedPersistVar = [];
      }
      if ($variables.ppPartnerSelectedPersistVar === '' || $variables.ppPartnerSelectedPersistVar === null || $variables.ppPartnerSelectedPersistVar === undefined) {
        $variables.ppPartnerSelectedVar = '';
      } else {
        const arrayToSet = await $functions.arrayToSet($variables.ppPartnerSelectedPersistVar);

        $variables.ppPartnerSelectedVar = arrayToSet;
      }
      if ($application.variables.userRole === 'PARTNER_USER' && $application.variables.loginType === 'Partner') {
        const defaultPartner = $application.variables.defaultPartnerNumber;
        if (defaultPartner && defaultPartner.trim() !== '') {
          $variables.ppPartnerSelectedVar = new Set([defaultPartner.trim()]);
        } else {
          $variables.ppPartnerSelectedVar = new Set();
        }
      }
      $variables.ppSearchPayload.operation = operation;


    }
  }

  return ppOperationValueChangeChain;
});
