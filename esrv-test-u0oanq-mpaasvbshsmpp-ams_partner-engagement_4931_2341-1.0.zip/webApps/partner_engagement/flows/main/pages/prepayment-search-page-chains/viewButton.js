define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class viewButton extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     * @param {any} params.key
     * @param {number} params.index
     * @param {any} params.current
     */
    async run(context, { event, originalEvent, key, index, current }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      $variables.prepaymentTab = 'Edit';

          const toPrepaymentAddEdit = await Actions.navigateToPage(context, {
            page: 'prepayment-add-edit',
            params: {
              prepaymentId: current.row.prepayment_request_id,
              paramStatus: current.row.prepayment_request_status,
              ViewEditVar: 'View',
              prepaymentRequestNumber: current.row.prepayment_number,
              prepaymentDocumentNo: current.row.document_number,
              mode: 'Edit',
            },
          });
   
   
    }
  }

  return viewButton;
});
