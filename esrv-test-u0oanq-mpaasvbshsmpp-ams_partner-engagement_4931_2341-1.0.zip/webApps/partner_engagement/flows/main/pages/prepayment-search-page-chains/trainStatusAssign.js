define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class trainStatusAssign extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
       
    await Actions.resetVariables(context, {
        variables: [
    '$variables.selectedStatus',
  ],
      });

      const statusOrder = [
        { id: '0', label: "Draft"},
        { id: '1', label: $application.translations.appBundle.train_label_proposed },
        { id: '2', label: "Verified/Revisied" },
        { id: '3', label: $application.translations.appBundle.train_label_agreed },
        { id: '4', label: "Approved/Rejected"},
        { id: '5', label: "Paid"}
      ];
      
      const statusIndexMap = {
        'Draft': 0,
        'Proposed': 1,
        'Verified/Revisied': 2,
        'Agreed': 3,
        'Approved/Rejected': 4,
        'Paid': 5
      };

      const currentStatus = "Draft";
      const currentIndex = statusIndexMap[currentStatus];

      if (currentIndex === undefined) {
        console.warn('Unknown status:', currentStatus);
        return;
      }

      $variables.steps = statusOrder.map((step, index) => ({
        ...step,
        disabled: true,
        messageType: index < currentIndex ? 'confirmation' : 
                      index === currentIndex ? 'confirmation' : 
                      'none'
      }));
       $variables.selectedStatus = statusOrder[currentIndex].id;
    
    }
  }

  return trainStatusAssign;
});
