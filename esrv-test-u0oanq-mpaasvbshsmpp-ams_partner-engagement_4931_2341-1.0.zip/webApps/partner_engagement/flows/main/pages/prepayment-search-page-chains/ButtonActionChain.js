define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     * @param {any} params.key
     * @param {number} params.index
     * @param {any} params.current
     * @param {any} params.rowData
     */
    async run(context, { event, originalEvent, key, index, current}) {
      const { $page, $flow, $application, $constants, $variables, $event } = context;
      
      let invoicePayload = {
  items: [
    {
      GetInvoice: [
        {
          InvoiceNumber: current.row.prepayment_number,
        },
      ],
    },
  ],
};


      const response = await Actions.callRest(context, {
        endpoint: 'OICService/postPrepayActionGetInvoice',
        body: invoicePayload,
      });

       if (!response.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Invoice Detail Load Failed',
          message: response.status + ' - ' + response.statusText,
        });
        return;
      }
     
     const header = response.body?.items?.[0];
        if (!header) {
          await Actions.fireNotificationEvent(context, {
            summary: 'No Invoice details found for Prepayment',
            type: 'error',
            displayMode: 'transient',
          });
          // return;
        }
        else{
      $variables.invoiceDetailVar = response.body.items[0];
      $variables.invoiceDetailVar.UnpaidAmount=response.body.items[0].InvoiceAmount-response.body.items[0].AmountPaid;
        }
      $variables.showDrawer = true;

      
    }
  }

  return ButtonActionChain;
});
