define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ppPartnerValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
      if ($variables.ppPartnerSelectedVar === '' || $variables.ppPartnerSelectedVar === null || $variables.ppPartnerSelectedVar === undefined) {
        $variables.ppPartnerSelectedPersistVar = [];

      } else {

        const setToArray = await $functions.setToArray($variables.ppPartnerSelectedVar);

        $variables.ppPartnerSelectedPersistVar = setToArray;
      }
      const ppArray = Array.from(value || []);
      let fpPartner = ppArray.length > 0 ? ppArray.join(',') : null;
      //
      const selectedIds = Array.from(value);
      let valuesArray;
      let numberOfValues;
      if (fpPartner !== null) {
        valuesArray = fpPartner.split(',');
        numberOfValues = valuesArray.length;

        if (selectedIds.includes(7777) && (numberOfValues > 1)) {
          await Actions.resetVariables(context, {
            variables: [
              '$variables.ppPartnerSelectedVar',
            ],
          });
          fpPartner = null;
        }
        else {
          const ispartnerid = selectedIds.includes(7777);
          if (ispartnerid) {
            const itemsArray = $page.variables.ppPartnerLovADP.data;
            const allValuesArray = itemsArray.map(item => item.partner_number).filter(partner_number => partner_number !== 7777);
            $variables.ppPartnerSelectedVar = new Set(allValuesArray);

          }

          // if (!ispartnerid) {

          //   const response = await Actions.callRest(context, {
          //     endpoint: 'pfmGateway/getGetcontract_number',
          //     uriParams: {
          //       'p_partner': fpPartner,
          //     },
          //   });
          //   if (!response.ok) {
          //     await Actions.fireNotificationEvent(context, {
          //       summary: 'Contract Lov Data Load Failed',
          //       message: response.status + ' - ' + response.statusText,
          //     });

          //   }
          //   else {
          //     let items = response.body.items;
          //     items.unshift({
          //       contract_number: "Select All / Clear All",
          //       contract_number_id: "ALL"
          //     });

          //     $variables.ppContractNumberADP.data = response.body.items;

          //   }
          // }
        }

      }

      if (fpPartner === null && $application.variables.loginType === 'Partner') {
        $variables.ppSearchPayload.partner = $variables.defaultTypeNumberForPartner;
      }
      else {
        $variables.ppSearchPayload.partner = fpPartner;
      }

      if (fpPartner == null) {
        //  $variables.ppContractNumberADP.data = [];
        //  $variables.ppContractNumberSelectedPersistVar = [];
        $variables.ppPartnerSelectedVar = '';
      }
      if ($variables.ppContractNumberSelectedPersistVar === '' || $variables.ppContractNumberSelectedPersistVar === null || $variables.ppContractNumberSelectedPersistVar === undefined) {
        $variables.ppContractNumberSelectedVar = '';
      } else {
        const arrayToSet = await $functions.arrayToSet($variables.ppContractNumberSelectedPersistVar);

        $variables.ppContractNumberSelectedVar = arrayToSet;
      }

    }
  }

  return ppPartnerValueChangeChain;
});
