define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ppActionGroup extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.selectedValue
     * @param {any} params.menuId
     */
    async run(context, { event, selectedValue, menuId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

   if(selectedValue==='Edit'){
     $variables.prepaymentTab = 'Edit';

      const toPrepaymentAddEdit = await Actions.navigateToPage(context, {
        page: 'prepayment-add-edit',
        params: {
          prepaymentId: $variables.getPrepaymentsVar.prepayment_request_id,
          paramStatus: $variables.getPrepaymentsVar.prepayment_request_status,
          ViewEditVar: 'Edit',
          prepaymentRequestNumber: $variables.getPrepaymentsVar.prepayment_number,
          prepaymentDocumentNo: $variables.getPrepaymentsVar.fpn_number,
          mode: 'Edit',
        },
      });
   }
   if(selectedValue==='View'){
      $variables.prepaymentTab = 'Edit';

          const toPrepaymentAddEdit = await Actions.navigateToPage(context, {
            page: 'prepayment-add-edit',
            params: {
              prepaymentId: $variables.getPrepaymentsVar.prepayment_request_id,
              paramStatus: $variables.getPrepaymentsVar.prepayment_request_status,
              ViewEditVar: 'View',
              prepaymentRequestNumber: $variables.getPrepaymentsVar.prepayment_number,
              prepaymentDocumentNo: $variables.getPrepaymentsVar.document_number,
              mode: 'Edit',
            },
          });
   

   }

    }
  }

  return ppActionGroup;
});
