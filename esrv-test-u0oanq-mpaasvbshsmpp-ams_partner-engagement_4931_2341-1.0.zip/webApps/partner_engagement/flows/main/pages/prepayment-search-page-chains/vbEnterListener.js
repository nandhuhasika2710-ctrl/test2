define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterListener extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const results = await Promise.all([
        async () => {
          const response = await Actions.callRest(context, {
            endpoint: 'pfmGateway/getGetbudgetyearlov',
          });

          if (!response.ok) {
            await Actions.fireNotificationEvent(context, {
              summary: 'BudgetYear Lov Data Load Failed',
              message: response.status + ' - ' + response.statusText,
            });
          }
          else {
            let items = response.body.items;
            items.unshift({
              budget_year: "Select All / Clear All",
              budget_year_id: 7777
            });

            $variables.ppBudgetYearLovADP.data = response.body.items;


          }

        },
        async () => {
          const response = await Actions.callRest(context, {
            endpoint: 'pfmGateway/getGetcontract_number',
          });
          if (!response.ok) {
            await Actions.fireNotificationEvent(context, {
              summary: 'Contract Lov Data Load Failed',
              message: response.status + ' - ' + response.statusText,
            });

          }
          else {
            let items = response.body.items;
            items.unshift({
              contract_number: "Select All / Clear All",
              contract_number_id: "ALL"
            });
            $variables.ppContractNumberADP.data = response.body.items;
          }
        },
      ].map(sequence => sequence()));


      if ($variables.ppBudgetYearSelectedPersistVar === '' || $variables.ppBudgetYearSelectedPersistVar === null || $variables.ppBudgetYearSelectedPersistVar === undefined) {
        $variables.ppBudgetYearSelectedVar = '';
      } else {
        const arrayToSet = await $functions.arrayToSet($variables.ppBudgetYearSelectedPersistVar);

        $variables.ppBudgetYearSelectedVar = arrayToSet;
      }
      if ($variables.ppOperationSelectedPersistVar === '' || $variables.ppOperationSelectedPersistVar === null || $variables.ppOperationSelectedPersistVar === undefined) {
        $variables.ppOperationSelectedVar = '';
      }
      else {
        const arrayToSet = await $functions.arrayToSet($variables.ppOperationSelectedPersistVar);

        $variables.ppOperationSelectedVar = arrayToSet;
      }

      if ($variables.ppPartnerSelectedPersistVar === '' || $variables.ppPartnerSelectedPersistVar === null || $variables.ppPartnerSelectedPersistVar === undefined) {
        $variables.ppPartnerSelectedVar = '';
      }
      else {
        const arrayToSet = await $functions.arrayToSet($variables.ppPartnerSelectedPersistVar);

        $variables.ppPartnerSelectedVar = arrayToSet;
      }

      if ($variables.ppContractNumberSelectedPersistVar === '' || $variables.ppContractNumberSelectedPersistVar === null || $variables.ppContractNumberSelectedPersistVar === undefined) {
        $variables.ppContractNumberSelectedVar = '';
      }
      else {
        const arrayToSet = await $functions.arrayToSet($variables.ppContractNumberSelectedPersistVar);

        $variables.ppContractNumberSelectedVar = arrayToSet;
      }

      const ppBudgetArray = Array.from($variables.ppBudgetYearSelectedVar || []);
      let ppBudgetYear = ppBudgetArray.length > 0 ? ppBudgetArray.join(',') : null;

      const ppOperationArray = Array.from($variables.ppOperationSelectedVar || []);
      let ppOperation = ppOperationArray.length > 0 ? ppOperationArray.join(',') : null;

      const ppPatnerArray = Array.from($variables.ppPartnerSelectedVar || []);
      let ppPatner = ppPatnerArray.length > 0 ? ppPatnerArray.join(',') : null;

      const ppContractArray = Array.from($variables.ppContractNumberSelectedVar || []);
      let ppContract = ppContractArray.length > 0 ? ppContractArray.join(',') : null;
      //default operations//
      if (ppOperation == null) {
        ppOperation = $application.variables.securityOperationCodes;
      }

      if ($application.variables.loginType === 'Partner') {

        $variables.searchBody.pyear = ppBudgetYear;
        $variables.searchBody.poperation = ppOperation;
        $variables.searchBody.ppartner_id = $application.variables.defaultPartnerNumber,
          $variables.searchBody.pcontract_number = ppContract;

        const searchResponse1 = await Actions.callRest(context, {
          endpoint: 'OICService/postPrepayActionGetPrepayBySearch',
          body: $variables.searchBody,
        });

        // const searchResponse1 = await Actions.callRest(context, {
        //   endpoint: 'pfmGateway/getPrepayments',
        //   uriParams: {
        //     'pcontract_number': $variables.searchBody.pcontract_number,
        //     poperation: $variables.searchBody.poperation,
        //     'ppartner_id': $variables.searchBody.ppartner_id,
        //     pyear: $variables.searchBody.pyear,
        //   },
        // });

        if (!searchResponse1.ok) {

          await Actions.fireNotificationEvent(context, {
            summary: 'Search Data Load Failed',
            message: searchResponse1.status + ' - ' + searchResponse1.statusText,
          });
        }
        else {
          if (searchResponse1.body.hasOwnProperty("items")) {
            $variables.prepaymentADP.data = searchResponse1.body.items;

            const createPDP = await $functions.createPDP(searchResponse1.body.items);

            $variables.prepaymentPDP = createPDP;
          }
          else {

            let createPDP = await $functions.createPDP([]);

            $variables.prepaymentPDP = createPDP;
          }


        }
      }
      else {
        $variables.searchBody.pyear = ppBudgetYear;
        $variables.searchBody.poperation = ppOperation;
        $variables.searchBody.ppartner_id = ppPatner;
        $variables.searchBody.pcontract_number = ppContract;

        const searchResponse = await Actions.callRest(context, {
          endpoint: 'OICService/postPrepayActionGetPrepayBySearch',
          body: $variables.searchBody,
        });

        
        // const searchResponse = await Actions.callRest(context, {
        //   endpoint: 'pfmGateway/getPrepayments',
        //   uriParams: {
        //     'pcontract_number': $variables.searchBody.pcontract_number,
        //     poperation: $variables.searchBody.poperation,
        //     'ppartner_id': $variables.searchBody.ppartner_id,
        //     pyear: $variables.searchBody.pyear,
        //   },
        // });

        if (!searchResponse.ok) {

          await Actions.fireNotificationEvent(context, {
            summary: 'Search Data Load Failed',
            message: searchResponse.status + ' - ' + searchResponse.statusText,
          });
        }
        else {
          if (searchResponse.body.hasOwnProperty("items")) {
            $variables.prepaymentADP.data = searchResponse.body.items;

            const createPDP = await $functions.createPDP(searchResponse.body.items);

            $variables.prepaymentPDP = createPDP;
          }
          else {

            let createPDP = await $functions.createPDP([]);

            $variables.prepaymentPDP = createPDP;
          }



        }
      }

    }
  }

  return vbEnterListener;
});
