define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ppEditButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { key, index, current }) {
      const { $page, $flow, $application, $constants, $variables, $current } = context;

      $variables.prepaymentTab = 'Edit';

      const toPrepaymentAddEdit = await Actions.navigateToPage(context, {
        page: 'prepayment-add-edit',
        params: {
          prepaymentId: current.row.prepayment_request_id,
          paramStatus: current.row.prepayment_request_status,
          ViewEditVar: 'Edit',
          prepaymentRequestNumber: current.row.prepayment_number,
          prepaymentDocumentNo: current.row.fpn_number,
          mode: 'Edit',
        },
      });
    }
  }

  return ppEditButtonActionChain;
});
