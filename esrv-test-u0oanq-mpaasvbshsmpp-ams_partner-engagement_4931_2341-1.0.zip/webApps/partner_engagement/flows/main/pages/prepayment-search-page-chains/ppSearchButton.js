define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ppSearchButton extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;



      await Actions.resetVariables(context, {
        variables: [
          '$variables.searchBody',
        ],
      });

      $variables.searchBody.poperation = $variables.ppSearchPayload.operation;
      $variables.searchBody.ppartner_id = $variables.ppSearchPayload.partner;
      $variables.searchBody.pyear = $variables.ppSearchPayload.budgetYear;
      $variables.searchBody.pcontract_number = $variables.ppSearchPayload.contractNumber;
      if ($variables.searchBody.poperation == null && $application.variables.loginType !== 'Partner') {
        $variables.searchBody.poperation = $application.variables.securityOperationCodes;
      }
      if ($variables.searchBody.poperation == null && $application.variables.loginType === 'Partner') {
        $variables.searchBody.poperation = $application.variables.securityOperationCodes;
        $variables.searchBody.ppartner_id = $application.variables.defaultPartnerNumber;

      }
      if ($application.variables.loginType === 'Partner') {
        $variables.searchBody.ppartner_id = $application.variables.defaultPartnerNumber;
      }
      const searchResponse = await Actions.callRest(context, {
        endpoint: 'OICService/postPrepayActionGetPrepayBySearch',
        body: $variables.searchBody,
      });

      //  const searchResponse = await Actions.callRest(context, {
      //     endpoint: 'pfmGateway/getPrepayments',
      //     uriParams: {
      //       'pcontract_number': $variables.searchBody.pcontract_number,
      //       poperation: $variables.searchBody.poperation,
      //       'ppartner_id': $variables.searchBody.ppartner_id,
      //       pyear: $variables.searchBody.pyear,
      //     },
      //   });

      if (!searchResponse.ok) {

        await Actions.fireNotificationEvent(context, {
          summary: 'Search Data Load Failed',
          message: searchResponse.status + ' - ' + searchResponse.statusText,
        });
      }
      else {
        if (searchResponse.body.hasOwnProperty("items")) {
          $variables.prepaymentADP.data = searchResponse.body.items;

          let createPDP = await $functions.createPDP(searchResponse.body.items);

          $variables.prepaymentPDP = createPDP;
        }
        else {

          let createPDP = await $functions.createPDP([]);

          $variables.prepaymentPDP = createPDP;
        }






      }


    }
  }

  return ppSearchButton;
});
