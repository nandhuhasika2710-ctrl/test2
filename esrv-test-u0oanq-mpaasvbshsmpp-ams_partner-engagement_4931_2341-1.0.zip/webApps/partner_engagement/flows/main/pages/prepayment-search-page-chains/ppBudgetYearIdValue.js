define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ppBudgetYearIdValue extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
      if ($variables.ppBudgetYearSelectedVar === '' || $variables.ppBudgetYearSelectedVar === null || $variables.ppBudgetYearSelectedVar === undefined) {
        $variables.ppBudgetYearSelectedPersistVar = [];

      } else {

        const setToArray = await $functions.setToArray($variables.ppBudgetYearSelectedVar);

        $variables.ppBudgetYearSelectedPersistVar = setToArray;
      }
      const ppArray = Array.from(value || []);
      let ppBudgetYear = ppArray.length > 0 ? ppArray.join(',') : null;

      const selectedIds = Array.from(value);

      let valuesArray;
      let numberOfValues;
      if (ppBudgetYear !== null) {
        valuesArray = ppBudgetYear.split(',');
        numberOfValues = valuesArray.length;

        if (selectedIds.includes(7777) && (numberOfValues > 1)) {
          await Actions.resetVariables(context, {
            variables: [
              '$variables.ppBudgetYearSelectedVar',
            ],
          });
          ppBudgetYear = null;
        }
        else {
          const isbudgetid = selectedIds.includes(7777);
          if (isbudgetid) {
            const itemsArray = $page.variables.ppBudgetYearLovADP.data;
            const allValuesArray = itemsArray.map(item => item.budget_year_id).filter(budget_year_id => budget_year_id !== 7777);
            $variables.ppBudgetYearSelectedVar = new Set(allValuesArray);

          }
          if (!isbudgetid) {

            const response = await Actions.callRest(context, {
              endpoint: 'pfmGateway/getGetcontract_number',
              uriParams: {
                pyear: ppBudgetYear,
              },
            });
            if (!response.ok) {
              await Actions.fireNotificationEvent(context, {
                summary: 'Contract Lov Data Load Failed',
                message: response.status + ' - ' + response.statusText,
              });

            }
            else {
              let items = response.body.items;
              items.unshift({
                contract_number: "Select All / Clear All",
                contract_number_id: "ALL"
              });
              $variables.ppContractNumberADP.data = response.body.items;
            }
          }
        }

      }
      $variables.ppSearchPayload.budgetYear = ppBudgetYear;
         if (ppBudgetYear == null) {
        $variables.ppContractNumberADP.data = [];
        $variables.ppContractNumberSelectedPersistVar = [];
        $variables.ppBudgetYearSelectedVar = '';
      }
       if ($variables.ppContractNumberSelectedPersistVar === '' || $variables.ppContractNumberSelectedPersistVar === null || $variables.ppContractNumberSelectedPersistVar === undefined) {
        $variables.ppContractNumberSelectedVar = '';
      } else {
        const arrayToSet = await $functions.arrayToSet($variables.ppContractNumberSelectedPersistVar);

        $variables.ppContractNumberSelectedVar = arrayToSet;
      }

    }
  }

  return ppBudgetYearIdValue;
});
