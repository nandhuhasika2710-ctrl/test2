define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TableColumnsChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.previousValue
     * @param {any} params.value
     * @param {string} params.updatedFrom
     * @param {any[]} params.columns
     */
    async run(context, { event, previousValue, value, updatedFrom, columns }) {
      const { $page, $flow, $application, $constants, $variables } = context;
   
   const callFunctionResult = await this.storageLocalstorage(context,columns);
    }
 
    /**
     * @param {Object} context
     */
    async storageLocalstorage(context,columns) {
      const { $page, $flow, $application, $constants, $variables } = context;
      localStorage.setItem("pptable",JSON.stringify(columns));
   
   
    }
  }

  return TableColumnsChangeChain;
});
