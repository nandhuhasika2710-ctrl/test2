define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterListener extends ActionChain {
    async run(context) {
      const { $variables, $application, $functions } = context;

      console.log("ppLoginType=>" + $application.variables.loginType);
      console.log("ppLoginUnchRole=>" + $application.variables.userRole);

      await Actions.callComponentMethod(context, {
        selector: '#progressbar',
        method: 'open',
      });

      try {

        let pfmResponse;

        /* =================================================
           STEP 1: LOAD PREPAYMENT HEADER (EDIT / CREATE)
        ================================================= */
        if ($variables.mode === 'Edit') {

          // pfmResponse = await Actions.callRest(context, {
          //   endpoint: 'OICService/getPrepayActionGetPrepayReq',
          //   uriParams: {
          //     'prepayment_number': $variables.prepaymentRequestNumber,
          //   },
          // });

          pfmResponse = await Actions.callRest(context, {
            endpoint: 'pfmGateway/getPrepaymentsHeaderdetails',
            uriParams: {
              'prepayment_number': $variables.prepaymentRequestNumber,
            },
          });

        } else {

          pfmResponse = await Actions.callRest(context, {
            endpoint: 'OICService/getPrepayActionGetPrepayReq',
            uriParams: {
              document_number: $variables.prepaymentDocumentNo,
            },
          });

          //  pfmResponse = await Actions.callRest(context, {
          //   endpoint: 'pfmGateway/getPrepaymentsHeaderdetails',
          //   uriParams: {
          //     'document_number': $variables.prepaymentDocumentNo,
          //   },
          // });

        }

        if (!pfmResponse.ok) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Unable to load prepayment details',
            message: `${pfmResponse.status} - ${pfmResponse.statusText}`,
            type: 'error',
            displayMode: 'transient',
          });
          return;
        }

        const header = pfmResponse.body?.items?.[0];
        if (!header) {
          await Actions.fireNotificationEvent(context, {
            summary: 'No prepayment details found',
            type: 'error',
            displayMode: 'transient',
          });
          return;
        }

        const results = await Promise.all([
          async () => {
            /* =================================================
           STEP 2: SET HEADER + CHART DATA
        ================================================= */
            $variables.prepaymentHeaderDetail = header;
            $variables.barChartVar = header.barchart;
            $variables.pieChartVar = header.pie_chart;
            $variables.prepaymentDetailVar = $variables.prepaymentDetailVar || {};

            /* =================================================
               STEP 3: BANK ACCOUNT HANDLING
            ================================================= */
            if (
              header.prepayment_status === 'Agreed' ||
              header.prepayment_status === 'Approved' ||
              header.prepayment_status === 'Rejected' ||
              header.prepayment_status === 'Paid'
            ) {

              $variables.maskedBankAccount = header.bank_account_last4_digits;

            } else {

              $variables.bankAccountBody.SupplierNumber = header.supplier_number;
              $variables.bankAccountBody.SiteName = header.supplier_site_number;
              $variables.bankAccountBody.SourceSystemIdentifier = "";
              $variables.bankAccountBody.SourceSystem = "";
              $variables.bankAccountBody.Currency = "";
              $variables.bankAccountBody.PrimaryFlag = "Y";

              const responseBank = await Actions.callRest(context, {
                endpoint: 'OICService/postPrepayActionGetprimarybankaccount',
                body: $variables.bankAccountBody,
              });

              if (!responseBank.ok) {
                await Actions.fireNotificationEvent(context, {
                  summary: 'Unable to load Bank details',
                  message: `${responseBank.status} - ${responseBank.statusText}`,
                  type: 'error',
                  displayMode: 'transient',
                });
                return;
              }

              const bankHeaderItem = responseBank.body?.SupplierBankAccounts?.[0];
              if (!bankHeaderItem) {
                await Actions.fireNotificationEvent(context, {
                  summary: 'No Bank Details Found',
                  type: 'error',
                  displayMode: 'transient',
                });
                return;
              }

              $variables.maskedBankAccount =
                $functions.maskExceptLast4(bankHeaderItem.BankAccountNumber);
            }

            /* =================================================
               STEP 4: VALIDATION STATE
            ================================================= */
            const getValidationState = await Actions.callRest(context, {
              endpoint: 'pfmGateway/getUpdateValidationstate',
              uriParams: {
                doc_type: 'PREPAYMENT',
                prepayment_number:
                  $variables.prepaymentHeaderDetail.prepayment_request_number,
              },
            });

            const validationItem = getValidationState?.body?.items && getValidationState.body.items.length > 0 ? getValidationState.body.items[0] : null;

            /* Default values */
            $variables.retainRunValidationVar = 'N';
            $variables.ppDraftSubmitStatus = 'DRAFT';

            if (validationItem) {
              $variables.retainRunValidationVar =
                validationItem.validation_state || 'N';

              $variables.ppDraftSubmitStatus =
                validationItem.draft_submission_status || 'DRAFT';
            }

            if ($variables.retainRunValidationVar === 'N') {
              $variables.validationColor = 'runvalidation_orange';
            } else if ($variables.retainRunValidationVar === 'Y') {
              $variables.validationColor = 'runvalidation_green';
            }

            if ($variables.ppDraftSubmitStatus === 'SUBMIT') {
              $variables.disableSubmitButton = true;
            } else {
              $variables.disableSubmitButton = false;
            }

            /* =================================================
               STEP 6: STATUS ASSIGNMENT
            ================================================= */
            if ($variables.ppDraftSubmitStatus === 'SUBMIT') {
              await Actions.callChain(context, {
                chain: 'assignStatus',
                params: {
                  ppStatus: header.prepayment_status,
                },
              });
            }
            if ($variables.ppDraftSubmitStatus === 'DRAFT') {

              await Actions.callChain(context, {
                chain: 'draftAssignStatus',
                params: {
                  ppStatus: header.prepayment_status,
                },
              });

            }

          },
          async () => {

            const response = await Actions.callRest(context, {
              endpoint: 'pfmGateway/getPrepaymentBarchart',
              uriParams: {
                'fpn_code': $variables.prepaymentHeaderDetail.fpn_number,
              },
            });

            const prepareChartData = await $functions.prepareChartData(response.body);
            $variables.chartGroups = prepareChartData.chartGroups;
            $variables.chartSeries = prepareChartData.chartSeries;
            $variables.PiechartData = prepareChartData.pieChartData;

          },
        ].map(sequence => sequence()));


        /* =================================================
           STEP 5: SUCCESS MESSAGE
        ================================================= */
        // await Actions.fireNotificationEvent(context, {
        //   summary: 'Prepayment data loaded successfully',
        //   type: 'confirmation',
        //   displayMode: 'transient',
        // });

      } catch (error) {

        await Actions.fireNotificationEvent(context, {
          summary: 'System Error',
          message: 'An unexpected error occurred while loading prepayment data.',
          type: 'error',
          displayMode: 'transient',
        });

      } finally {

        await Actions.callComponentMethod(context, {
          selector: '#progressbar',
          method: 'close',
        });

      }
    }
  }
  return vbEnterListener;
});
