define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class saveAsDraftButton extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
      const progressbarOpen = await Actions.callComponentMethod(context, {
        selector: '#progressbar',
        method: 'open',
      });

      const commentField = document.getElementById('commentsTextArea');
      if (commentField) {
        const status = await commentField.validate();

        if (status !== 'valid') {
          await Actions.fireNotificationEvent(context, {
            summary: 'Please correct the comment field before saving',
            displayMode: 'transient',
          });

          const progressbarClose = await Actions.callComponentMethod(context, {
            selector: '#progressbar',
            method: 'close',
          });

          return;

        }
      }
      const amountField = document.getElementById('amountInput');
      let header=null;

      if (amountField) {
        const result = await amountField.validate();
        if (result !== 'valid') {
          await Actions.fireNotificationEvent(context, {
            summary: 'Please correct the prepayment amount field before saving.',
            displayMode: 'transient',
          });
          const progressbarClose2 = await Actions.callComponentMethod(context, {
            selector: '#progressbar',
            method: 'close',
          });

          return;

        }
      }
      // const response_precision = await Actions.callRest(context, {
      //   endpoint: 'pfmGateway/getCurrency_precision',
      //   uriParams: {
      //     'p_currency_code': $page.variables.prepaymentHeaderDetail.supplier_site_invoice_currency,
      //   },
      // });

      // if (!response_precision.ok) {
      //   await Actions.fireNotificationEvent(context, {
      //     summary: 'Precision API Failed',
      //     message: response_precision.status + ' - ' + response_precision.statusText,
      //   });

      //   const progressbarClose3 = await Actions.callComponentMethod(context, {
      //     selector: '#progressbar',
      //     method: 'close',
      //   });

      //   return;

      // }
      // else {
      //   let vp = await $functions.validatePrecision($variables.prepaymentHeaderDetail.prepayment_amount, response_precision.body.items[0].precision);
      //   if (!vp) {

      //     await Actions.fireNotificationEvent(context, {
      //       summary: response_precision.body.items[0].precision + ' decimal only allowed for prepayment amount',
      //     });

      //     const progressbarClose4 = await Actions.callComponentMethod(context, {
      //       selector: '#progressbar',
      //       method: 'close',
      //     });
      //     return;
      //   }

      // }
      //end//
      await Actions.resetVariables(context, {
        variables: [
          '$variables.ppSaveVar',
        ],
      });

      console.log("zzmode=" + $variables.mode);
      console.log("zzrqn=" + $variables.prepaymentId);
      console.log("zzdn=" + $variables.prepaymentDocumentNo);
      if ($variables.mode === 'Edit') {

        const pfmResponse = await Actions.callRest(context, {
          endpoint: 'OICService/getPrepayActionGetPrepayReq',
          uriParams: {
            'prepayment_number': $variables.prepaymentRequestNumber,
          },
        });

        // const pfmResponse = await Actions.callRest(context, {
        //   endpoint: 'pfmGateway/getPrepaymentsHeaderdetails',
        //   uriParams: {
        //     'prepayment_number': $variables.prepaymentRequestNumber,
        //   },
        // });

        if (!pfmResponse.ok) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Unable to load prepayment details',
            message: `${pfmResponse.status} - ${pfmResponse.statusText}`,
            type: 'error',
            displayMode: 'transient',
          });

          const progressbarClose5 = await Actions.callComponentMethod(context, {
            selector: '#progressbar',
            method: 'close',
          });
          return;
        }

         header = pfmResponse.body?.items?.[0];
        if (!header) {
          await Actions.fireNotificationEvent(context, {
            summary: 'No prepayment details found for FPN',
            type: 'error',
            displayMode: 'transient',
          });

          const progressbarClose10 = await Actions.callComponentMethod(context, {
            selector: '#progressbar',
            method: 'close',
          });
          return;
        }

        $variables.prepaymentHeaderDetail.prepayment_request_number = header.prepayment_request_number;
        console.log("zzrr=" + $variables.prepaymentHeaderDetail.prepayment_request_number);
      }
      else {

        const pfmResponse = await Actions.callRest(context, {
          endpoint: 'OICService/getPrepayActionGetPrepayReq',
          uriParams: {
            'document_number': $variables.prepaymentDocumentNo,
          },
        });

        // const pfmResponse = await Actions.callRest(context, {
        //   endpoint: 'pfmGateway/getPrepaymentsHeaderdetails',
        //   uriParams: {
        //     'document_number': $variables.prepaymentDocumentNo,
        //   },
        // });

        if (!pfmResponse.ok) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Unable to load prepayment details',
            message: `${pfmResponse.status} - ${pfmResponse.statusText}`,
            type: 'error',
            displayMode: 'transient',
          });
          const progressbarClose9 = await Actions.callComponentMethod(context, {
            selector: '#progressbar',
            method: 'close',
          });

          return;
        }

         header = pfmResponse.body?.items?.[0];
        if (!header) {
          await Actions.fireNotificationEvent(context, {
            summary: 'No prepayment details found for FPN',
            type: 'error',
            displayMode: 'transient',
          });

          const progressbarClose8 = await Actions.callComponentMethod(context, {
            selector: '#progressbar',
            method: 'close',
          });
          return;
        }
        // $variables.prepaymentHeaderDetail = header;
        $variables.prepaymentHeaderDetail.prepayment_request_number = header.prepayment_request_number;
        console.log("zzrr=" + $variables.prepaymentHeaderDetail.prepayment_request_number);

      }
      if ($variables.mode === 'Edit') {
        $variables.ppSaveVar.created_by = $variables.prepaymentHeaderDetail.created_by || '';
      }
      else {
        $variables.ppSaveVar.created_by = $application.variables.userInfoObj.UserID || '';
      }
      // $variables.ppSaveVar.prepayment_request_number = header.prepayment_request_number;
      // $variables.ppSaveVar.prepayment_request_number = 'PP-' + $variables.prepaymentHeaderDetail.fpn_number;
      $variables.ppSaveVar.prepayment_request_number = $variables.prepaymentHeaderDetail.prepayment_request_number;
      $variables.ppSaveVar.prepayment_request_business_unit = $variables.prepaymentHeaderDetail.supplier_site_business_unit;
      $variables.ppSaveVar.prepayment_request_amount = $variables.prepaymentHeaderDetail.prepayment_amount;
      $variables.ppSaveVar.prepayment_request_status = $variables.prepaymentHeaderDetail.prepayment_status;
      $variables.ppSaveVar.comments = $variables.prepaymentHeaderDetail.comments;
      $variables.ppSaveVar.draft_submission_status = 'DRAFT';
      $variables.ppSaveVar.validation_state = $variables.retainRunValidationVar;
      $variables.ppSaveVar.prepayment_partner_submission_date = $variables.prepaymentHeaderDetail.prepayment_partner_submission_date;
      $variables.ppSaveVar.prepayment_request_currency = header.supplier_site_invoice_currency;
      $variables.ppSaveVar.supplier_number = $variables.prepaymentHeaderDetail.supplier_number;
      $variables.ppSaveVar.supplier_site = $variables.prepaymentHeaderDetail.supplier_site_number;
      $variables.ppSaveVar.cost_center = $variables.prepaymentHeaderDetail.cost_center;
      $variables.ppSaveVar.fpn_number = $variables.prepaymentHeaderDetail.fpn_number;
      $variables.ppSaveVar.ppa_number = $variables.prepaymentHeaderDetail.ppa_number;
      // $variables.ppSaveVar.created_by = $application.variables.userInfoObj.UserID;
      $variables.ppSaveVar.last_updated_by = $application.variables.userInfoObj.UserID;
      $variables.ppSaveVar.masked_bank_account = $variables.maskedBankAccount;
      $variables.ppSaveVar.contract_currency = $variables.prepaymentHeaderDetail.contract_currency;
      $variables.ppSaveVar.in_capacity_of = $application.variables.userRole;
      // if($variables.prepaymentHeaderDetail.prepayment_status==='Agreed' || 
      //        $variables.prepaymentHeaderDetail.prepayment_status==='Approved' ||
      //        $variables.prepaymentHeaderDetail.prepayment_status==='Rejected' ||
      //        $variables.prepaymentHeaderDetail.prepayment_status==='Paid')
      //    {
      //  $variables.ppSaveVar.masked_bank_account = $variables.maskedBankAccount;
      //  }
      //  else
      //  {
      //   $variables.ppSaveVar.masked_bank_account=null;
      //  }




      const response = await Actions.callRest(context, {
        endpoint: 'OICService/postPrepayActionProcess',
        body: $variables.ppSaveVar,
      });

      // const response = await Actions.callRest(context, {
      //   endpoint: 'pfmGateway/postPrepaymentsrequest',
      //   body: $variables.ppSaveVar,
      // });

      // if (!response.ok || response.body.status !=='201') {
      if (response.body.status !== 'SUCCESS') {
        await Actions.fireNotificationEvent(context, {
          summary: 'Prepayment Save Failed',
          message: response.status + ' - ' + response.statusText,
        });

        const progressbarClose7 = await Actions.callComponentMethod(context, {
          selector: '#progressbar',
          method: 'close',
        });

        return;

      }
      else {
        if (response.body.status === 'SUCCESS') {
          // if (response.body.status === '201') {
          await Actions.fireNotificationEvent(context, {
            summary: 'Saved Successfully',
            type: 'confirmation',
          });

          const response2 = await Actions.callRest(context, {
            endpoint: 'pfmGateway/putUpdateValidationstate',
            uriParams: {
              'doc_type': 'PREPAYMENT',
              'validation_state': $variables.retainRunValidationVar,
              'prepayment_number': $variables.ppSaveVar.prepayment_request_number,
              'draft_submission_status': 'DRAFT',
            },
          });
          if ($variables.ppSaveVar.draft_submission_status === 'DRAFT') {
            await Actions.callChain(context, {
              chain: 'draftAssignStatus',
              params: {
                ppStatus: $variables.prepaymentHeaderDetail.prepayment_status,
              },
            });
          }
          else if ($variables.ppSaveVar.draft_submission_status === 'SUBMIT') {
            await Actions.callChain(context, {
              chain: 'assignStatus',
              params: {
                ppStatus: $variables.prepaymentHeaderDetail.prepayment_status,
              },
            });
          }
          $variables.disableSubmitButton = true;
          $variables.retainRunValidationVar = 'N';
          $variables.validationColor = 'runvalidation_orange';

          const progressbarClose6 = await Actions.callComponentMethod(context, {
            selector: '#progressbar',
            method: 'close',
          });
        }
        // else {
        //   await Actions.fireNotificationEvent(context, {
        //     summary: response.body.StatusMessage,
        //   });

        // }
      }

      //  }

    }
  }

  return saveAsDraftButton;
});
