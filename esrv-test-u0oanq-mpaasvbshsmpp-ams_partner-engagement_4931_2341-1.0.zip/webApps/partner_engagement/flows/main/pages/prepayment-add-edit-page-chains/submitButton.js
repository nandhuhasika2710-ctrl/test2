define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class submitButton extends ActionChain {
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const progressbarOpen = await Actions.callComponentMethod(context, {
        selector: '#progressbar',
        method: 'open',
      });

      // Validate Comments
      const commentField = document.getElementById('commentsTextArea');
      if (commentField) {
        const status = await commentField.validate();
        if (status !== 'valid') {
          await Actions.fireNotificationEvent(context, {
            summary: 'Please correct the comment field before saving',
            displayMode: 'transient',
          });
          const progressbarClose = await Actions.callComponentMethod(context, {
            selector: '#progressbar',
            method: 'close',
          });

          return;
        }
      }

      // Validate Amount
      const amountField = document.getElementById('amountInput');
      let header=null;
      if (amountField) {
        const result = await amountField.validate();
        if (result !== 'valid') {
          await Actions.fireNotificationEvent(context, {
            summary: 'Please correct the prepayment amount field before saving.',
            displayMode: 'transient',
          });

          const progressbarClose2 = await Actions.callComponentMethod(context, {
            selector: '#progressbar',
            method: 'close',
          }); 
          return;
        }
      }

      // Populate ppSaveVar
      await Actions.resetVariables(context, {
        variables: [
          '$variables.ppSaveVar',
        ],
      });
      if ($variables.mode === 'Edit') {

        const getPrepay = await Actions.callRest(context, {
          endpoint: 'OICService/getPrepayActionGetPrepayReq',
          uriParams: {
            'prepayment_number': $variables.prepaymentRequestNumber,
          },
        });

        // const getPrepay = await Actions.callRest(context, {
        //   endpoint: 'pfmGateway/getPrepaymentsHeaderdetails',
        //   uriParams: {
        //     'prepayment_number': $variables.prepaymentRequestNumber,
        //   },
        // });

        if (!getPrepay.ok ) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Unable to load prepayment details',
            message: `${getPrepay.status} - ${getPrepay.statusText}`,
            type: 'error',
            displayMode: 'transient',
          });

          const progressbarClose12 = await Actions.callComponentMethod(context, {
            selector: '#progressbar',
            method: 'close',
          });
          return;
        }

         header = getPrepay.body?.items?.[0];
        if (!header) {
          await Actions.fireNotificationEvent(context, {
            summary: 'No prepayment details found for FPN',
            type: 'error',
            displayMode: 'transient',
          });

          const progressbarClose13 = await Actions.callComponentMethod(context, {
            selector: '#progressbar',
            method: 'close',
          });
          return;
        }
        $variables.prepaymentHeaderDetail.prepayment_request_number = header.prepayment_request_number;
        console.log("zzsrr=" + $variables.prepaymentHeaderDetail.prepayment_request_number);
      }
      else {

        const getPrepay = await Actions.callRest(context, {
          endpoint: 'OICService/getPrepayActionGetPrepayReq',
          uriParams: {
            'document_number': $variables.prepaymentDocumentNo,
          },
        });

        // const getPrepay = await Actions.callRest(context, {
        //   endpoint: 'pfmGateway/getPrepaymentsHeaderdetails',
        //   uriParams: {
        //     'document_number': $variables.prepaymentDocumentNo,
        //   },
        // });

        if (!getPrepay.ok) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Unable to load prepayment details',
            message: `${getPrepay.status} - ${getPrepay.statusText}`,
            type: 'error',
            displayMode: 'transient',
          });

          const progressbarClose14 = await Actions.callComponentMethod(context, {
            selector: '#progressbar',
            method: 'close',
          });
          return;
        }

         header = getPrepay.body?.items?.[0];
        if (!header) {
          await Actions.fireNotificationEvent(context, {
            summary: 'No prepayment details found for FPN',
            type: 'error',
            displayMode: 'transient',
          });

          const progressbarClose15 = await Actions.callComponentMethod(context, {
            selector: '#progressbar',
            method: 'close',
          });
          return;
        }
        $variables.prepaymentHeaderDetail.prepayment_request_number = header.prepayment_request_number;
        console.log("zzsrr=" + $variables.prepaymentHeaderDetail.prepayment_request_number);

      }


      $variables.ppSaveVar.prepayment_request_number = $variables.prepaymentHeaderDetail.prepayment_request_number;
      $variables.ppSaveVar.prepayment_request_business_unit = $variables.prepaymentHeaderDetail.supplier_site_business_unit;
      $variables.ppSaveVar.prepayment_request_amount = $variables.prepaymentHeaderDetail.prepayment_amount;
      $variables.ppSaveVar.prepayment_request_status = $variables.prepaymentHeaderDetail.prepayment_status;
      $variables.ppSaveVar.comments = $variables.prepaymentHeaderDetail.comments;
      $variables.ppSaveVar.prepayment_request_currency = header.supplier_site_invoice_currency;
      $variables.ppSaveVar.masked_bank_account = $variables.maskedBankAccount;
      $variables.ppSaveVar.draft_submission_status = 'SUBMIT';
      $variables.ppSaveVar.validation_state = $variables.retainRunValidationVar;
      $variables.ppSaveVar.in_capacity_of = $application.variables.userRole;
      if ($application.variables.userRole === 'PARTNER_USER') {
        $variables.ppSaveVar.prepayment_partner_submission_date = $functions.getTodayString();
      }
      else {
        $variables.ppSaveVar.prepayment_partner_submission_date = $variables.prepaymentHeaderDetail.prepayment_partner_submission_date;
      }
      if ($application.variables.userRole !== 'PARTNER_USER' && $variables.prepaymentHeaderDetail.prepayment_status === 'Agreed') {
        $variables.ppSaveVar.prepayment_status_agreed_date = $functions.getTodayString();
      }
      //  else
      //  {
      //   $variables.ppSaveVar.prepayment_status_agreed_date=$variables.prepaymentHeaderDetail.prepayment_status_agreed_date;
      //  }

      //  if($variables.prepaymentHeaderDetail.prepayment_status==='Agreed' || 
      //      $variables.prepaymentHeaderDetail.prepayment_status==='Approved' ||
      //      $variables.prepaymentHeaderDetail.prepayment_status==='Rejected' ||
      //      $variables.prepaymentHeaderDetail.prepayment_status==='Paid')
      //  {
      //      $variables.ppSaveVar.masked_bank_account = $variables.maskedBankAccount;
      //  }
      //  else
      //  {
      //   $variables.ppSaveVar.masked_bank_account=null;
      //  }

      $variables.ppSaveVar.supplier_number = $variables.prepaymentHeaderDetail.supplier_number;
      $variables.ppSaveVar.supplier_site = $variables.prepaymentHeaderDetail.supplier_site_number;
      $variables.ppSaveVar.cost_center = $variables.prepaymentHeaderDetail.cost_center;
      $variables.ppSaveVar.fpn_number = $variables.prepaymentHeaderDetail.fpn_number;
      $variables.ppSaveVar.ppa_number = $variables.prepaymentHeaderDetail.ppa_number;
      $variables.ppSaveVar.contract_currency = $variables.prepaymentHeaderDetail.contract_currency;
      $variables.ppSaveVar.created_by = $application.variables.userInfoObj.UserID;
      $variables.ppSaveVar.last_updated_by = $application.variables.userInfoObj.UserID;


      // Save to PFM first
      const pfmResponse = await Actions.callRest(context, {
        endpoint: 'OICService/postPrepayActionProcess',
        body: $variables.ppSaveVar,
      });

      // const pfmResponse = await Actions.callRest(context, {
      //   endpoint: 'pfmGateway/postPrepaymentsrequest',
      //   body: $variables.ppSaveVar,
      // });

      if (!pfmResponse.ok || pfmResponse.body?.status !== 'SUCCESS') {
        // if (pfmResponse.body.status !== '201') {
        await Actions.fireNotificationEvent(context, {
          summary: 'Prepayment Submission Failed',
          type: 'error',
        });

        const response8 = await Actions.callRest(context, {
          endpoint: 'pfmGateway/putUpdateValidationstate',
          uriParams: {
            'doc_type': 'PREPAYMENT',
            'validation_state': $variables.retainRunValidationVar,
            'prepayment_number': $variables.ppSaveVar.prepayment_request_number,
            'draft_submission_status': 'DRAFT',
          },
        });

        await Actions.callChain(context, {
          chain: 'draftAssignStatus',
          params: {
            ppStatus: $variables.ppSaveVar.prepayment_request_status,
          },
        });

        const progressbarClose5 = await Actions.callComponentMethod(context, {
          selector: '#progressbar',
          method: 'close',
        });
        return;
      }
      if ($application.variables.userRole === 'PARTNER_USER') {
        $variables.prepaymentHeaderDetail.prepayment_partner_submission_date = $functions.getTodayString();
      }
      // -------------------------------
      let taskId = $variables.taskId; // First check if taskId came from URL
      const fullName = $flow.variables?.ovUserInfoglobal?.given_name || "";
      let instanceId = '';
      const addUserOpaPayload = await $application.functions.addUserOpaPayload($application.variables.userInfoObj.FirstName, $application.variables.userInfoObj.LastName, $application.variables.userInfoObj.FirstName + '' + $application.variables.userInfoObj.LastName, $application.variables.userInfoObj.UserID, $application.variables.opaUserGroup);

      const response6 = await Actions.callRest(context, {
        endpoint: 'opaOic/postPlatformUserprovisioning',
        body: addUserOpaPayload,
      });

      if (!response6.ok) {

        await Actions.fireNotificationEvent(context, {
          summary: 'Prepayment Submission Failed',
          type: 'error',
          message: 'User Provisioning Failed',
        });

        const response10 = await Actions.callRest(context, {
          endpoint: 'pfmGateway/putUpdateValidationstate',
          uriParams: {
            'doc_type': 'PREPAYMENT',
            'validation_state': $variables.retainRunValidationVar,
            'prepayment_number': $variables.ppSaveVar.prepayment_request_number,
            'draft_submission_status': 'DRAFT',
          },
        });

        await Actions.callChain(context, {
          chain: 'draftAssignStatus',
          params: {
            ppStatus: $variables.ppSaveVar.prepayment_request_status,
          },
        });

        await Actions.callComponentMethod(context, {
          selector: '#progressbar',
          method: 'close',
        });

        return;
      }

      const opaAccessTokenPayload = await $application.functions.opaAccessTokenPayload($application.variables.userInfoObj.UserID);

      const response7 = await Actions.callRest(context, {
        endpoint: 'opaOic/postPlatformUserassertionmgmt',
        body: opaAccessTokenPayload,
      });
      if (!response7.ok) {

        const errorMsg =
          response7.body?.error_description ||
          response7.body?.error ||
          response7.statusText;

        await Actions.fireNotificationEvent(context, {
          message: 'OPA Token Generation Failed'  || errorMsg,
          type: 'error',
          summary: 'Prepayment Submission Failed',
        });

        const response11 = await Actions.callRest(context, {
          endpoint: 'pfmGateway/putUpdateValidationstate',
          uriParams: {
            'doc_type': 'PREPAYMENT',
            'validation_state': $variables.retainRunValidationVar,
            'prepayment_number': $variables.ppSaveVar.prepayment_request_number,
            'draft_submission_status': 'DRAFT',
          },
        });

        await Actions.callChain(context, {
          chain: 'draftAssignStatus',
          params: {
            ppStatus: $variables.ppSaveVar.prepayment_request_status,
          },
        });

        await Actions.callComponentMethod(context, {
          selector: '#progressbar',
          method: 'close',
        });

        return;
      }


      const formatAsBearerToken = await $application.functions.formatAsBearerToken(response7.body.access_token);

      $variables.opaAccessToken = formatAsBearerToken;

      if (!taskId) {
        try {

          const instanceResponse = await Actions.callRest(context, {
            endpoint: 'OPA/getInstances',
            uriParams: {
              businessKeyLike: $variables.prepaymentRequestNumber,
            },
            headers: {
              Authorization: $variables.opaAccessToken,
            },
          });

          // find only ACTIVE instance
          const activeInstance = instanceResponse.body?.items?.find(
            item => item.state === 'ACTIVE'
          );

          // store rootInstanceId of active instance
          instanceId = activeInstance?.rootInstanceId;
          if (instanceId) {
            // if ($application.variables.userRole === 'PARTNER_USER') {


            //   const buildUpdateFromPartnerPayload = await $functions.buildUpdateFromPartnerPayload(instanceId, $variables.ppSaveVar.prepayment_request_number);
            //   const responseSubmit = await Actions.callRest(context, {
            //     endpoint: 'OPA/postMessages',
            //     body: buildUpdateFromPartnerPayload,
            //     headers: {
            //       Authorization: $variables.opaAccessToken,
            //     },
            //   });

            //   if (responseSubmit.status === 202) {
            //     await Actions.fireNotificationEvent(context, {
            //       summary: 'Submitted Successfully',
            //       message: 'Prepayment has been submitted successfully.',
            //       type: 'confirmation',
            //     });
            //     const response2 = await Actions.callRest(context, {
            //       endpoint: 'pfmGateway/putUpdateValidationstate',
            //       uriParams: {
            //         'doc_type': 'PREPAYMENT',
            //         'validation_state': $variables.retainRunValidationVar,
            //         'prepayment_number': $variables.ppSaveVar.prepayment_request_number,
            //         'draft_submission_status': 'SUBMIT',
            //       },
            //     });
            //     if($variables.ppSaveVar.draft_submission_status = 'SUBMIT'){

            //       await Actions.callChain(context, {
            //         chain: 'assignStatus',
            //         params: {
            //           ppStatus: $variables.ppSaveVar.prepayment_request_status,
            //         },
            //       });

            //     }
            //     if($variables.ppSaveVar.draft_submission_status = 'DRAFT'){

            //       await Actions.callChain(context, {
            //         chain: 'draftAssignStatus',
            //         params: {
            //           ppStatus: $variables.ppSaveVar.prepayment_request_status,
            //         },
            //       });

            //     }

            //     const progressbarClose6 = await Actions.callComponentMethod(context, {
            //       selector: '#progressbar',
            //       method: 'close',
            //     });

            //     const toPrepaymentSearch = await Actions.navigateToPage(context, {
            //       page: 'prepayment-search',
            //     });


            //   }
            // }
            // else {
            const activitiesResponse = await Actions.callRest(context, {
              endpoint: 'OPA/getInstancesInstanceIdActivities',
              uriParams: {
                instanceId: instanceId,
              },
              headers: {
                Authorization: $variables.opaAccessToken,
              },
            });

            const activityInstanceId = activitiesResponse.body?.activities?.[0]?.activityInstanceId;
            if (activityInstanceId) {
              const auditResponse = await Actions.callRest(context, {
                endpoint: 'OPA/getAuditInstancesInstanceIdActivitiesActivityInstanceId',
                uriParams: {
                  instanceId: instanceId,
                  activityInstanceId: activityInstanceId,
                },
                headers: {
                  Authorization: $variables.opaAccessToken,
                },
              });

              taskId = auditResponse.body?.taskId || null;
            }
          }
          // }
          else {
            if ($application.variables.userRole === 'PARTNER_USER' && $variables.ppSaveVar.prepayment_request_status === 'Proposed') {
              // No taskId → post new instance
              const postPayload = await $functions.buildOPAPostInstancesPayload($variables.ppSaveVar);

              const postResponse = await Actions.callRest(context, {
                endpoint: 'OPA/postInstances',
                body: postPayload,
                headers: {
                  Authorization: $variables.opaAccessToken,
                },
              });

              if (postResponse.ok) {
                await Actions.fireNotificationEvent(context, {
                  summary: 'Prepayment Submitted Successfully',
                  type: 'confirmation',
                  message: 'Prepayment has been submitted successfully',
                });

                const response = await Actions.callRest(context, {
                  endpoint: 'pfmGateway/putUpdateValidationstate',
                  uriParams: {
                    'doc_type': 'PREPAYMENT',
                    'validation_state': $variables.retainRunValidationVar,
                    'prepayment_number': $variables.ppSaveVar.prepayment_request_number,
                    'draft_submission_status': 'SUBMIT',
                  },
                });

                const progressbarClose7 = await Actions.callComponentMethod(context, {
                  selector: '#progressbar',
                  method: 'close',
                });

                const toPrepaymentSearch2 = await Actions.navigateToPage(context, {
                  page: 'prepayment-search',
                });


              } else {
                await Actions.fireNotificationEvent(context, {
                  message: 'Failed to create OPA instance',
                  type: 'error',
                  summary: 'Prepayment Submission Failed',
                });

                const response3 = await Actions.callRest(context, {
                  endpoint: 'pfmGateway/putUpdateValidationstate',
                  uriParams: {
                    'doc_type': 'PREPAYMENT',
                    'validation_state': $variables.retainRunValidationVar,
                    'prepayment_number': $variables.ppSaveVar.prepayment_request_number,
                    'draft_submission_status': 'DRAFT',
                  },
                });

                await Actions.callChain(context, {
                  chain: 'draftAssignStatus',
                  params: {
                    ppStatus: $variables.ppSaveVar.prepayment_request_status,
                  },
                });

                const progressbarClose8 = await Actions.callComponentMethod(context, {
                  selector: '#progressbar',
                  method: 'close',
                });

                return;
              }
            } else {
              // Submit Failed
              await Actions.fireNotificationEvent(context, {
                type: 'error',
                message: 'Please Check Status,Partner has to submit with Proposed Status',
                summary: 'Prepayment Submission Failed',
              });

              const response9 = await Actions.callRest(context, {
                endpoint: 'pfmGateway/putUpdateValidationstate',
                uriParams: {
                  'doc_type': 'PREPAYMENT',
                  'validation_state': $variables.retainRunValidationVar,
                  'prepayment_number': $variables.ppSaveVar.prepayment_request_number,
                  'draft_submission_status': 'DRAFT',
                },
              });

              await Actions.callChain(context, {
                chain: 'draftAssignStatus',
                params: {
                  ppStatus: $variables.ppSaveVar.prepayment_request_status,
                },
              });

              const progressbarClose9 = await Actions.callComponentMethod(context, {
                selector: '#progressbar',
                method: 'close',
              });

              return;
            }
          }
        } catch (error) {

          console.warn('Failed to fetch taskId from OPA:', error.message);

          const progressbarClose17 = await Actions.callComponentMethod(context, {
            selector: '#progressbar',
            method: 'close',
          });

          return;
        }
      }
      // -------------------------------
      if (taskId) {


        const updatePayload = $functions.buildOPAUpdateTaskPayload($variables.ppSaveVar);

        const claimResponse = await Actions.callRest(context, {
          endpoint: 'OPA/postTasksIdClaim',
          uriParams: {
            id: taskId,
          },
          body: {
            comment: 'Claiming task for submission',
          },
          headers: {
            Authorization: $variables.opaAccessToken,
          },
        });

        const patchResponse = await Actions.callRest(context, {
          endpoint: 'OPA/putTasksIdPayload',
          uriParams: {
            id: taskId,
          },
          body: updatePayload,

          headers: {
            Authorization: $variables.opaAccessToken,
          },
        });

        if (patchResponse.ok) {

          const completeResponse = await Actions.callRest(context, {
            endpoint: 'OPA/completeatask',
            uriParams: {
              id: taskId,
            },
            body: {
              comment: 'Comment for task completion',
              outcome: ($variables.ppSaveVar.prepayment_request_status || '').toUpperCase(),
            },
            headers: {
              Authorization: $variables.opaAccessToken,
            },
          });

          if (completeResponse.body.status === 403) {
            await Actions.fireNotificationEvent(context, {
              summary: 'Prepayment Submission Failed',
              type: 'error',
              message: completeResponse.body.message,
            });
            const response15 = await Actions.callRest(context, {
              endpoint: 'pfmGateway/putUpdateValidationstate',
              uriParams: {
                'doc_type': 'PREPAYMENT',
                'validation_state': $variables.retainRunValidationVar,
                'prepayment_number': $variables.ppSaveVar.prepayment_request_number,
                'draft_submission_status': 'DRAFT',
              },
            });

            await Actions.callChain(context, {
              chain: 'draftAssignStatus',
              params: {
                ppStatus: $variables.ppSaveVar.prepayment_request_status,
              },
            });

            const progressbarClose16 = await Actions.callComponentMethod(context, {
              selector: '#progressbar',
              method: 'close',
            });

            return;
          }
          else {
            await Actions.fireNotificationEvent(context, {
              summary: 'Prepayment Submitted Successfully',
              type: 'confirmation',
              message: 'Prepayment has been submitted successfully',
            });
            const response4 = await Actions.callRest(context, {
              endpoint: 'pfmGateway/putUpdateValidationstate',
              uriParams: {
                'doc_type': 'PREPAYMENT',
                'validation_state': $variables.retainRunValidationVar,
                'prepayment_number': $variables.ppSaveVar.prepayment_request_number,
                'draft_submission_status': 'SUBMIT',
              },
            });

            const progressbarClose10 = await Actions.callComponentMethod(context, {
              selector: '#progressbar',
              method: 'close',
            });

            const toPrepaymentSearch3 = await Actions.navigateToPage(context, {
              page: 'prepayment-search',
            });

          }
        } else {
          await Actions.fireNotificationEvent(context, {
            summary: 'Prepayment Submission Failed',
            message: patchResponse.status + '-' + patchResponse.statusText,
            type: 'error',
          });

          const response5 = await Actions.callRest(context, {
            endpoint: 'pfmGateway/putUpdateValidationstate',
            uriParams: {
              'doc_type': 'PREPAYMENT',
              'validation_state': $variables.retainRunValidationVar,
              'prepayment_number': $variables.ppSaveVar.prepayment_request_number,
              'draft_submission_status': 'DRAFT',
            },
          });

          await Actions.callChain(context, {
            chain: 'draftAssignStatus',
            params: {
              ppStatus: $variables.ppSaveVar.prepayment_request_status,
            },
          });

          const progressbarClose11 = await Actions.callComponentMethod(context, {
            selector: '#progressbar',
            method: 'close',
          });

          return;
        }


      }



    }
  }

  return submitButton;
});
