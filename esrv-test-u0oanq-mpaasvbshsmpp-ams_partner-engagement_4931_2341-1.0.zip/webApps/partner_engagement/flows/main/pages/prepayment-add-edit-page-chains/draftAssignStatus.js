define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class draftAssignStatus extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.ppStatus
     */
    async run(context, { ppStatus }) {
      const { $page, $flow, $application, $constants, $variables } = context;




      const statusOrder = [
        { id: '0', label: $application.translations.appBundle.train_pp_draft, },
        { id: '1', label: $application.translations.appBundle.train_label_proposed },
        { id: '2', label: $application.translations.appBundle.train_pp_revised },
        { id: '3', label: $application.translations.appBundle.train_label_agreed },
        { id: '4', label: $application.translations.appBundle.train_pp_approve_reject }
      ];

      const statusIndexMap = {
        'Draft': 0,
        'Proposed': 1,
        'Revised': 2,
        'Verified': 2,
        'Agreed': 3,
        'Approved': 4,
        'Rejected': 4,
        'Canceled': 4
      };

      const currentStatus = ppStatus;
      const currentIndex = statusIndexMap[currentStatus];

      if (currentIndex === undefined) {
        console.warn('Unknown status:', currentStatus);
        return;
      }

      $variables.steps = statusOrder.map((step, index) => {

        let messageType = 'none';
        let visited = false;

        if (index < currentIndex) {
          messageType = 'confirmation'; // Previous → tick
          visited = true;
        }
        else if (index === currentIndex) {
          messageType = 'info'; // Current → circle
          visited = true;
        }

        return {
          ...step,
          disabled: true,
          visited,
          messageType
        };
      });

      // $variables.selectedStatus = statusOrder[currentIndex].id;
    }
  }

  return draftAssignStatus;
});
