define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class runvalidationActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;


      const progressbarOpen = await Actions.callComponentMethod(context, {
        selector: '#progressbar',
        method: 'open',
      });

      $variables.ppSaveVar.prepayment_request_number = $variables.prepaymentHeaderDetail.prepayment_request_number;
      $variables.ppSaveVar.prepayment_request_business_unit = $variables.prepaymentHeaderDetail.supplier_site_business_unit;
      $variables.ppSaveVar.prepayment_request_amount = $variables.prepaymentHeaderDetail.prepayment_amount;
      $variables.ppSaveVar.prepayment_request_status = $variables.prepaymentHeaderDetail.prepayment_status;
      $variables.ppSaveVar.comments = $variables.prepaymentHeaderDetail.comments;
      $variables.ppSaveVar.draft_submission_status = 'DRAFT';
      $variables.ppSaveVar.validation_state = $variables.retainRunValidationVar;
      $variables.ppSaveVar.prepayment_partner_submission_date = $variables.prepaymentHeaderDetail.prepayment_partner_submission_date;
      $variables.ppSaveVar.prepayment_request_currency = $variables.prepaymentHeaderDetail.supplier_site_invoice_currency;
      $variables.ppSaveVar.supplier_number = $variables.prepaymentHeaderDetail.supplier_number;
      $variables.ppSaveVar.supplier_site = $variables.prepaymentHeaderDetail.supplier_site_number;
      $variables.ppSaveVar.cost_center = $variables.prepaymentHeaderDetail.cost_center;
      $variables.ppSaveVar.fpn_number = $variables.prepaymentHeaderDetail.fpn_number;
      $variables.ppSaveVar.ppa_number = $variables.prepaymentHeaderDetail.ppa_number;
      $variables.ppSaveVar.last_updated_by = $application.variables.userInfoObj.UserID;
      $variables.ppSaveVar.masked_bank_account = $variables.maskedBankAccount;
      $variables.ppSaveVar.contract_currency = $variables.prepaymentHeaderDetail.contract_currency;
      $variables.ppSaveVar.in_capacity_of = $application.variables.userRole;
      if ($application.variables.userRole === 'PARTNER_USER') {
        $variables.ppSaveVar.prepayment_partner_submission_date = $functions.getTodayString();
      }
      else {
        $variables.ppSaveVar.prepayment_partner_submission_date = $variables.prepaymentHeaderDetail.prepayment_partner_submission_date;
      }
      if ($application.variables.userRole !== 'PARTNER_USER' && $variables.prepaymentHeaderDetail.prepayment_status === 'Agreed') {
        $variables.ppSaveVar.prepayment_status_agreed_date = $functions.getTodayString();
      }
      else {
        $variables.ppSaveVar.prepayment_status_agreed_date = $variables.prepaymentHeaderDetail.prepayment_status_agreed_date;
      }
      $variables.ppSaveVar.created_by = $variables.prepaymentHeaderDetail.created_by || '';
      const response1 = await Actions.callRest(context, {
        endpoint: 'OICService/postPrepayActionProcess',
        body: $variables.ppSaveVar,
      });
   if (response1.body.status !== 'SUCCESS') {
        await Actions.fireNotificationEvent(context, {
          summary: 'Prepayment Save Failed',
          message: 'response1.body.response',
        });

        const progressbarClose2 = await Actions.callComponentMethod(context, {
          selector: '#progressbar',
          method: 'close',
        });
        return;

      }
      const response = await Actions.callRest(context, {
        endpoint: 'OICService/postPrepayActionValidate',
        body: $variables.ppSaveVar,
      });

      if (!response.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Prepayment run validation Failed',
          message: response.status + ' - ' + response.statusText,
          type: 'error',
        });
        const progressbarClose = await Actions.callComponentMethod(context, {
          selector: '#progressbar',
          method: 'close',
        });

        return;

      }

      $variables.runValidationVar = response.body.rules_results;
      const results = $variables.runValidationVar;

      let flag = 'Y';

      if (Array.isArray(results)) {
        const allOk = results.every(rec => rec.result && rec.result.toUpperCase() === 'SUCCESS' || rec.result === 'Rule Yet To Be Implemented');
        if (!allOk) {
          flag = 'N';
          $variables.retainRunValidationVar = 'N';
        }
      } else {
        flag = 'N';
        $variables.retainRunValidationVar = 'N';
      }

      if (flag === 'Y') {
        $variables.validationColor = 'runvalidation_green';
        $variables.retainRunValidationVar = 'Y';
        $variables.disableSubmitButton = false;
      } else {
        $variables.validationColor = 'runvalidation_red';
        $variables.retainRunValidationVar = 'N';
        $variables.disableSubmitButton = true;
      }

      const progressbarClose3 = await Actions.callComponentMethod(context, {
        selector: '#progressbar',
        method: 'close',
      });

      const ojDialogRunvalidationOpen = await Actions.callComponentMethod(context, {
        selector: '#oj-dialog-runvalidation',
        method: 'open',
      });


    }
  }

  return runvalidationActionChain;
});
