define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class statusSelectValue extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.value
     * @param {object} params.itemContext
     * @param {any} params.previousValue
     */
    async run(context, { event, value, itemContext, previousValue }) {
      const { $page, $flow, $application, $constants, $variables } = context;


      $variables.changedStatusValue = $variables.prepaymentHeaderDetail.prepayment_status;

      $variables.paramStatus = value;

      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $variables.prepaymentStatusADP,
      });


      $variables.retainRunValidationVar = 'N';
      $variables.validationColor = 'runvalidation_orange';
      $variables.ppDraftSubmitStatus = 'DRAFT';
    }
  }

  return statusSelectValue;
});
