define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class getPrepaymentsStatuslovFetch extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{hookHandler:'vb/RestHookHandler'}} params.configuration
     */
    async run(context, { configuration }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if (configuration.hookHandler.context.fetchOptions.filterCriterion) {
        if (configuration.hookHandler.context.fetchOptions.filterCriterion.text.length >= 1) {
          const response = await Actions.callRest(context, {
            endpoint: 'pfmGateway/getPrepaymentsStatuslov',
            uriParams: {
              'p_partner_type': $application.variables.userRole,
            },
          });

          if (!response.ok) {
            await Actions.fireNotificationEvent(context, {
              summary: 'Fetching Error',
              displayMode: 'transient',
            });
          } else {
            return response;
          }
        }
      }
      else {
        const callRestEndpoint1 = await Actions.callRest(context, {
          endpoint: 'pfmGateway/getPrepaymentsStatuslov',
          uriParams: {
            'p_partner_type': $application.variables.userRole,
          },
          responseType: 'getPrepaymentsStatuslovResponse',
          hookHandler: configuration.hookHandler,
          requestType: 'json',
        });
        const currentStatus = $variables.paramStatus;
        let lovList = callRestEndpoint1.body?.items || [];
        lovList = lovList.filter(item => item.lookup_values !== currentStatus);

        lovList.unshift({ lookup_values: currentStatus });

        callRestEndpoint1.body.items = lovList;

        return callRestEndpoint1;
      }
    }
  }

  return getPrepaymentsStatuslovFetch;
});
