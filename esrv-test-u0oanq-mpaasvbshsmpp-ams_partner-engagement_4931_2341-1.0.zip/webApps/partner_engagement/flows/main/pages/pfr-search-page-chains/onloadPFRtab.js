define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class onloadPFRtab extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      if ($application.variables.loginType === 'Partner') {
        const searchPayload = await $functions.searchPayload($application.variables.securityOperationCodes, undefined, $application.variables.defaultPartnerNumber, undefined);

        // const response1 = await Actions.callRest(context, {
        //   endpoint: 'pfmGateway/getPfrSearchdetails',
        //   uriParams: {
        //     pyear: $variables.pfrSearchPayload.budgetYear,
        //     'pcontract_number': $variables.pfrSearchPayload.contractNumber,
        //     poperation: $variables.pfrSearchPayload.operation,
        //     'ppartner_id': $variables.pfrSearchPayload.partner,
        //   },
        // });
        const response1 = await Actions.callRest(context, {
          endpoint: 'OICService/getPfrDetails',
          body: searchPayload,
        });

        if (response1.status === 500 || response1.statusCode === 500) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Internal Server Error (500). Please try again later.',
            displayMode: 'transient',
          });

          // 
          let pfrCreatePDP = await $functions.pfrCreatePDP([]);
          $variables.pfrPDP = pfrCreatePDP;

          return; // stop further execution
        }

        if (response1.body.status.toUpperCase() !== 'SUCCESS') {
          // if (!response1.ok) {
          await Actions.fireNotificationEvent(context, {
            summary: response1.body.StatusMessage,
            displayMode: 'transient',
          });

        }
        else
          if (response1.body.hasOwnProperty("items")) {

            const searchPFR = await $functions.searchPFR(response1.body.items);

            $variables.pfrtableADP.data = searchPFR;

            let pfrCreatePDP = await $functions.pfrCreatePDP($variables.pfrtableADP.data);

            $variables.pfrPDP = pfrCreatePDP;
          }

          else {

            let pfrCreatePDP = await $functions.pfrCreatePDP([]);

            $variables.pfrPDP = pfrCreatePDP;
          }
      }

      else {
        const searchPayload = await $functions.searchPayload($application.variables.securityOperationCodes, undefined, undefined, undefined);

        // const response = await Actions.callRest(context, {
        //   endpoint: 'pfmGateway/getPfrSearchdetails',
        //   uriParams: {
        //     pyear: $variables.pfrSearchPayload.budgetYear,
        //     'pcontract_number': $variables.pfrSearchPayload.contractNumber,
        //     poperation: $variables.pfrSearchPayload.operation,
        //     'ppartner_id': $variables.pfrSearchPayload.partner,
        //   },
        // });
        const response = await Actions.callRest(context, {
          endpoint: 'OICService/getPfrDetails',
          body: searchPayload,
        });

        if (response.status === 500 || response.statusCode === 500) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Internal Server Error (500). Please try again later.',
            displayMode: 'transient',
          });

          // 
          let pfrCreatePDP = await $functions.pfrCreatePDP([]);
          $variables.pfrPDP = pfrCreatePDP;

          return; // stop further execution
        }
        if (response.body.status.toUpperCase() !== 'SUCCESS') {
          // if (!response.ok) {
          await Actions.fireNotificationEvent(context, {
            summary: response.body.StatusMessage,
            displayMode: 'transient',
          });

        }
        else
          if (response.body.hasOwnProperty("items")) {

            const searchPFR = await $functions.searchPFR(response.body.items);

            $variables.pfrtableADP.data = searchPFR;

            let pfrCreatePDP = await $functions.pfrCreatePDP($variables.pfrtableADP.data);

            $variables.pfrPDP = pfrCreatePDP;
          }

          else {

            let pfrCreatePDP = await $functions.pfrCreatePDP([]);

            $variables.pfrPDP = pfrCreatePDP;
          }
      }


    }
  }

  return onloadPFRtab;
});
