define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class unlockpfrActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key
     * @param {number} params.index
     * @param {any} params.current
     */
    async run(context, { key, index, current }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      /* ===============================
         OPEN PROGRESS BAR
      ================================ */
      await Actions.callComponentMethod(context, {
        selector: '#progressbar',
        method: 'open',
      });

      try {

       
        const response = await Actions.callRest(context, {
          endpoint: 'pfmGateway/getClaimpfr',
          uriParams: {
            'p_pfr_code': current.item.data.pfr_code,
          },
        });

        if (!response.ok || !response.body.items || response.body.items.length === 0) {
          throw {
            summary: 'PFR Lock Details Load Failed',
            message: response.status + ' - ' + response.statusText,
          };
        }

         const isSuperUser = $application.variables.userRole === 'PFM_SUPERUSER';
        const isLockOwner =
          $application.variables.userInfoObj.UserID === response.body.items[0].locked_by;
        let lockedUserName = response.body.items[0].locked_by;

        if (!isSuperUser && !isLockOwner) {
          throw {
            summary: 'Access Denied to Unlock PFR',
            message: `This PFR is locked by ${lockedUserName}.`,
            type: 'warning',
          };
        }

        
        /* ===============================
           UPDATE DB (UNLOCK)
        ================================ */
        $variables.pfrunclockDetails.activity_instance_id = '';
        $variables.pfrunclockDetails.instance_id = '';
        $variables.pfrunclockDetails.is_locked = 'N';
        $variables.pfrunclockDetails.locked_by =response.body.items[0].locked_by;
        $variables.pfrunclockDetails.task_id = '';
        $variables.pfrunclockDetails.unlocked_by = $application.variables.userInfoObj.UserID;

        const claimTaskPayload = await $functions.claimTaskPayload($variables.pfrunclockDetails, current.item.data.pfr_id, current.item.data.pfr_code);

        const response3 = await Actions.callRest(context, {
          endpoint: 'pfmGateway/postClaimpfr',
          body: claimTaskPayload,
        });

        if (!response3.ok) {
          throw {
            summary: 'Unlock FPN Failed',
            message: response3.status + ' - ' + response3.statusText,
          };
        }

        /* ===============================
           UI REFRESH + SUCCESS MESSAGE
        ================================ */


        await Actions.fireNotificationEvent(context, {
          summary: 'PFR Unlocked Successfully',
          type: 'confirmation',
          displayMode: 'transient',
        });

        await Actions.callChain(context, {
          chain: 'onloadPFRtab',
        });

      } catch (err) {

        /* ===============================
           CENTRAL ERROR HANDLING
        ================================ */
        await Actions.fireNotificationEvent(context, {
          summary: err.summary || 'Unlock Operation Failed',
          message: err.message || 'An unexpected error occurred',
          type: err.type || 'error',
          displayMode: 'transient',
        });

      } finally {

        /* ===============================
           CLOSE PROGRESS BAR (ALWAYS)
        ================================ */
        await Actions.callComponentMethod(context, {
          selector: '#progressbar',
          method: 'close',
        });
      }
    }
  }

  return unlockpfrActionChain;
});
