define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class fppfrContractValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables,$functions } = context;
      if ($variables.pfrContractNumberSelectedVar === '' || $variables.pfrContractNumberSelectedVar === null || $variables.pfrContractNumberSelectedVar === undefined) {
        $variables.pfrContractNumberSelectedPersistVar = [];
        
      } else {

         const setToArray = await $functions.setToArray($variables.pfrContractNumberSelectedVar);

        $variables.pfrContractNumberSelectedPersistVar = setToArray;
      }
     const fpArray = Array.from(value || []);
     let fpContract = fpArray.length > 0 ? fpArray.join(',') : null;
     let valuesArray;
      let numberOfValues;
      if (fpContract !== null) {
        valuesArray = fpContract.split(',');
        numberOfValues = valuesArray.length;

        if (valuesArray.includes('ALL') && (numberOfValues > 1)) {
         
          await Actions.resetVariables(context, {
            variables: [
              '$variables.pfrContractNumberSelectedVar',
            ],
          });
          fpContract = null;
        }
        else {
          if (fpContract === 'ALL') {
            const itemsArray = $page.variables.pfrContractNumberADP.data;
            const allValuesArray = itemsArray.map(item => item.contract_number_id).filter(contract_number_id => contract_number_id !== "ALL");
            $variables.pfrContractNumberSelectedVar=new Set(allValuesArray);
          
          }
        }
      }
      $variables.pfrSearchPayload.contractNumber = fpContract;
    
    }
  }

  return fppfrContractValueChangeChain;
});
