define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class invStatusActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     * @param {any} params.key
     * @param {number} params.index
     * @param {any} params.current
     */
    async run(context, { event, originalEvent, key, index, current }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      
            let invoicePayload = {
  items: [
    {
      GetInvoice: [
        {
          InvoiceNumber: current.row.invoice_number,
        },
      ],
    },
  ],
};


      const response = await Actions.callRest(context, {
        endpoint: 'OICService/postPrepayActionGetInvoice',
        body: invoicePayload,
      });

       if (!response.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Invoice Detail Load Failed',
          message: response.status + ' - ' + response.statusText,
        });
        return;
      }
      
       const header = response.body?.items?.[0];
        if (!header) {
          await Actions.fireNotificationEvent(context, {
            summary: 'No Invoice details found for PFR',
            type: 'error',
            displayMode: 'transient',
          });
          return;
        }


      $variables.erpInvoiceStatusVar = response.body.items[0].ValidationStatus;
      $variables.erpInvoiceDateVar = response.body.items[0].InvoiceDate;
      $variables.erpInvoiceCurrencyVar = response.body.items[0].InvoiceCurrency;

      const ojDialogInvoiceStatusOpen = await Actions.callComponentMethod(context, {
        selector: '#oj-dialog-invoice-status',
        method: 'open',
      });
      
      // await Actions.fireNotificationEvent(context, {
      //   message: response.body.items[0].ValidationStatus,
      //   summary: 'Invoice Status',
      //   type: 'info',
      // });
    
    
    }
  }

  return invStatusActionChain;
});
