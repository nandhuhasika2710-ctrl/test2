define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class actionGroupMenuMenuActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.selectedValue
     * @param {any} params.menuId
     */
    async run(context, { event, selectedValue, menuId }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await Actions.fireNotificationEvent(context, {
        summary: JSON.stringify($variables.inputParameter.current.pfr_code),
      });

      if (selectedValue === 'Edit') {
              const toMainPfrEdit = await Actions.navigateToPage(context, {
                page: 'main-pfr-edit',
                params: {
                  mode: 'EDIT',
                  'p_pfr_Id': $variables.inputParameter.key,
                  'pfr_Status': $variables.inputParameter.current.pfr_status,
                  'pfr_code': $variables.inputParameter.current.pfr_code,
                },
              });
       
      }

      if (selectedValue === 'View') {
             const toMainPfrEdit = await Actions.navigateToPage(context, {
               page: 'main-pfr-edit',
               params: {
                 mode: 'EDIT',
                 'p_pfr_Id': $variables.inputParameter.key,
                 'pfr_Status': $variables.inputParameter.current.pfr_status,
                 'pfr_code': $variables.inputParameter.current.pfr_code,
                 viewMode: 'VIEW',
               },
             });
      }

      if (selectedValue === 'lockunlock') {
             const fullName = $flow.variables.ovUserInfoglobal.given_name;
      const [firstname, lastname] = fullName.split(" ");

      const addUserOpaPayload = await $functions.addUserOpaPayload(firstname, lastname, fullName, $application.user.username);

      const response6 = await Actions.callRest(context, {
        endpoint: 'opaOic/postPlatformUserprovisioning',
        body: addUserOpaPayload,
      });

      const opaAccessTokenPayload = await $functions.opaAccessTokenPayload($application.user.username);

      const response7 = await Actions.callRest(context, {
        endpoint: 'opaOic/postPlatformUserassertionmgmt',
        body: opaAccessTokenPayload,
      });

      const formatAsBearerToken = await $functions.formatAsBearerToken(response7.body.access_token);

      $variables.opaAccessToken = formatAsBearerToken;

      const response = await Actions.callRest(context, {
        endpoint: 'OPA/getInstances',
        uriParams: {
          businessKeyLike: $variables.inputParameter.current.pfr_code,
        },
        headers: {
          Authorization: $variables.opaAccessToken,
        },
      });

      if (response.status === 200 && response.body.count > 0) {
       const response2 = await Actions.callRest(context, {
         endpoint: 'OPA/getInstancesInstanceIdActivities',
         uriParams: {
           instanceId: response.body.items[0].rootInstanceId,
         },
         headers: {
           Authorization: $variables.opaAccessToken,
         },
       });

        if (response2.status === 200) {
          const response3 = await Actions.callRest(context, {
            endpoint: 'OPA/getAuditInstancesInstanceIdActivitiesActivityInstanceId',
            uriParams: {
              activityInstanceId: response2.body.activities[0].activityInstanceId,
              instanceId: response.body.items[0].rootInstanceId,
            },
            headers: {
              Authorization: $variables.opaAccessToken,
            },
          });

          if (response3.status === 200) {
            const response4 = await Actions.callRest(context, {
              endpoint: 'OPA/postTasksIdClaim',
              uriParams: {
                id: response3.body.taskId,
              },
              body: {
                comment: 'Comment for claiming a task',
              },
              headers: {
                Authorization: $variables.opaAccessToken,
              },
            });

            if (response4.status === 200) {

              $variables.pfrclaimDetails.instance_id = response.body.items[0].rootInstanceId;
              $variables.pfrclaimDetails.activity_instance_id = response2.body.activities[0].activityInstanceId;
              $variables.pfrclaimDetails.task_id = response3.body.taskId;
              $variables.pfrclaimDetails.is_locked = 'Y';
              $variables.pfrclaimDetails.locked_by = $application.user.username;

              const claimTaskPayload = await $functions.claimTaskPayload($variables.pfrclaimDetails, $variables.inputParameter.current.pfr_id, $variables.inputParameter.current.pfr_code);

              const response5 = await Actions.callRest(context, {
                endpoint: 'pfmGateway/postClaimpfr',
                body: claimTaskPayload,
              });

              if (!response5.ok) {
                await Actions.fireNotificationEvent(context, {
                  summary: 'Lock FPN failed',
                  message: response5.status + ' - ' + response5.statusText,
                });
              } else {

                await Actions.fireNotificationEvent(context, {
                  summary: 'Task locked',
                });
              }
            } else {
              await Actions.fireNotificationEvent(context, {
                summary: 'OPA Call Failed. An unexpected error occurred',
              });
            }
          } else {
            await Actions.fireNotificationEvent(context, {
              summary: 'OPA Call Failed. An unexpected error occurred',
            });
          }
        } else {
          await Actions.fireNotificationEvent(context, {
            summary: 'OPA Call Failed. An unexpected error occurred',
          });
        }
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'OPA Call Failed. An unexpected error occurred',
        });
      }
      }
    }
  }

  return actionGroupMenuMenuActionChain;
});
