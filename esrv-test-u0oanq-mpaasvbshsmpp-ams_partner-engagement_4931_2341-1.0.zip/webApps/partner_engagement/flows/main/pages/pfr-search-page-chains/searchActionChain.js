define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class fpSearchButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await Actions.resetVariables(context, {
        variables: [
    '$variables.oicOperationsearchPayload',
  ],
      });

      $variables.oicOperationsearchPayload.Operation_Code = $variables.pfrSearchPayload.operation;
      $variables.oicOperationsearchPayload.Budget_Year = $variables.pfrSearchPayload.budgetYear;
      $variables.oicOperationsearchPayload.Partner_Number = $variables.pfrSearchPayload.partner;
      $variables.oicOperationsearchPayload.Contract_Number = $variables.pfrSearchPayload.contractNumber;
      if ($variables.pfrSearchPayload.operation == null && $application.variables.loginType !== 'Partner') {
        $variables.oicOperationsearchPayload.Operation_Code = $application.variables.securityOperationCodes;
      }

      if ($variables.pfrSearchPayload.operation == null && $application.variables.loginType === 'Partner') {
        $variables.oicOperationsearchPayload.Operation_Code = $application.variables.securityOperationCodes;

        $variables.oicOperationsearchPayload.Partner_Number = $application.variables.defaultPartnerNumber;
      }

          if ( $application.variables.loginType === 'Partner') {
        $variables.oicOperationsearchPayload.Partner_Number = $application.variables.defaultPartnerNumber;
      }

      const response2 = await Actions.callRest(context, {
        endpoint: 'OICService/getPfrDetails',
        body: $variables.oicOperationsearchPayload,
      });
      if (response2.body.status.toUpperCase() !== 'SUCCESS') {

        await Actions.fireNotificationEvent(context, {
          summary: response2.body.StatusMessage,
          displayMode: 'transient',
        });

      }
      else
        if (response2.body.hasOwnProperty("items")) {

          const searchPFR = await $functions.searchPFR(response2.body.items);

          $variables.pfrtableADP.data = searchPFR;

          let pfrCreatePDP = await $functions.pfrCreatePDP($variables.pfrtableADP.data);

          $variables.pfrPDP = pfrCreatePDP;
        }

        else {
          $variables.pfrtableADP.data = [];

          let pfrCreatePDP = await $functions.pfrCreatePDP([]);

          $variables.pfrPDP = pfrCreatePDP;
        }
    }
  }


  return fpSearchButtonActionChain;
});
