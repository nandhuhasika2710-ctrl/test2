define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class viewButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     * @param {any} params.key
     * @param {number} params.index
     * @param {any} params.current
     */
    async run(context, { event, originalEvent, key, index, current }) {
      const { $page, $flow, $application, $constants, $variables } = context;

            const toMainPfrEdit = await Actions.navigateToPage(context, {
              page: 'main-pfr-edit',
              params: {
                'pfr_Status': current.row.pfr_status,
                mode: 'EDIT',
                viewMode: 'VIEW',
                'pfr_code': current.row.pfr_code,
              },
            });
    }
  }

  return viewButtonActionChain;
});
