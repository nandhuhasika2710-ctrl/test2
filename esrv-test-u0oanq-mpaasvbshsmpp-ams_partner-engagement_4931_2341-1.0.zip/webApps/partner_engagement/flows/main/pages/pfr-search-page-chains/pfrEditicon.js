define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
  'ojs/ojarraytreedataprovider',           
  'ojs/ojflattenedtreedataproviderview',  
], (
  ActionChain,
  Actions,
  ActionUtils,
  ArrayTreeDataProvider,          
  FlattenedTreeDataProviderView   
) => {
  'use strict';

  class pfrEditicon extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     * @param {any} params.key
     * @param {number} params.index
     * @param {any} params.current
     */
    async run(context, { event, originalEvent, key, index, current }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const toMainPfrEdit = await Actions.navigateToPage(context, {
        page: 'main-pfr-edit',
        params: {
          'p_pfr_Id': key,
          'pfr_Status': current.row.pfr_status,
          mode: 'EDIT',
          'pfr_code': current.row.pfr_code,
        },
      });

    
      }
  }
  return pfrEditicon;
});
