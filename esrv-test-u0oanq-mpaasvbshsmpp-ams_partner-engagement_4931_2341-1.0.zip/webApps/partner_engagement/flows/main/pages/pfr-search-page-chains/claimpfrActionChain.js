define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class claimpfrActionChain extends ActionChain {

    async run(context, { key, index, current }) {
      const { $application, $variables, $functions } = context;

      /* =================================================
         UI VALIDATION – APPLICATION LAYER
      ================================================= */
      if (current.row.pfr_status === 'Approved') {
        await Actions.fireNotificationEvent(context, {
          summary: 'Action Not Allowed',
          message:
            'This PFR is already approved. Locking is not permitted.',
          type: 'error',
          displayMode: 'transient',
        });
        return;
      }

      const progressbarOpen = await Actions.callComponentMethod(context, {
        selector: '#progressbar',
        method: 'open',
      });

      try {
     
        $variables.pfrclaimDetails.instance_id = '';
        $variables.pfrclaimDetails.activity_instance_id='';
        $variables.pfrclaimDetails.task_id = '';
        $variables.pfrclaimDetails.is_locked = 'Y';
        $variables.pfrclaimDetails.locked_by =$application.variables.userInfoObj.UserID;
              const claimTaskPayload = await $functions.claimTaskPayload($variables.pfrclaimDetails, current.item.data.pfr_id, current.item.data.pfr_code);

        const dbResp = await Actions.callRest(context, {
                endpoint: 'pfmGateway/postClaimpfr',
                body: claimTaskPayload,
              });

        if (!dbResp.ok) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Database Error',
            message: 'Failed to lock,please try again',
            type: 'error',
            displayMode: 'transient',
          });
          return;
        }

        /* =================================================
           STEP 8: UI REFRESH + SUCCESS
        ================================================= */

        await Actions.fireNotificationEvent(context, {
          summary: 'PFR Locked',
          message:
            'The PFR has been successfully locked and assigned to you.',
          type: 'confirmation',
          displayMode: 'transient',
        });

        await Actions.callChain(context, {
          chain: 'onloadPFRtab',
        });

      } catch (e) {

        await Actions.fireNotificationEvent(context, {
          summary: 'System Error',
          message:
            'An unexpected error occurred while processing the lock request.',
          type: 'error',
          displayMode: 'transient',
        });

      } finally {

        await Actions.callComponentMethod(context, {
          selector: '#progressbar',
          method: 'close',
        });
      }
    }
  }

  return claimpfrActionChain;
});
