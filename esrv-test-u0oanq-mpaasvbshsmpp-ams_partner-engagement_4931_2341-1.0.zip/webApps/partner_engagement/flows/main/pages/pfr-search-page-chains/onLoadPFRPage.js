define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class onLoadPFRPage extends ActionChain {

    async run(context) {
      const { $variables, $functions } = context;

      // ---------------------------
      // Budget Year LOV
      // ---------------------------
      try {
        const response = await Actions.callRest(context, {
          endpoint: 'pfmGateway/getGetbudgetyearlov',
        });

        if (!response.ok) {
          await this.handleError(context, response.status);
          return;
        }

        const items = response.body.items || [];

        $variables.pfrBudgetYearLovADP.data = [
          {
            budget_year: 'Select All / Clear All',
            budget_year_id: 7777,
          },
          ...items,
        ];

      } catch (error) {
        await this.handleUnexpectedError(context, error);
        return;
      }

      // ---------------------------
      // Operation LOV
      // ---------------------------
      // try {
      //   const response = await Actions.callRest(context, {
      //     endpoint: 'pfmGateway/getGetoperationslov',
      //   });

      //   if (!response.ok) {
      //     await this.handleError(context, response.status);
      //     return;
      //   }

      //   const items = response.body.items || [];

      //   items.unshift({
      //     operation_name: "Select All / Clear All",
      //     operation_code: "ALL"
      //   });

      //   $variables.pfrOperationLovADP.data = items;

      // } catch (error) {
      //   await this.handleUnexpectedError(context, error);
      //   return;
      // }

      // ---------------------------
      // Restore Persisted Values
      // ---------------------------
      await this.restorePersistedSelections(context);
    }

    // ---------------------------
    // Common Error Handler
    // ---------------------------
    async handleError(context, status) {
      let errorMessage = 'An unexpected error occurred. Please try again later.';

      switch (status) {
        case 400:
          errorMessage = 'Bad Request: Please check input parameters.';
          break;
        case 401:
          errorMessage = 'Unauthorized: Please check login credentials.';
          break;
        case 403:
          errorMessage = 'Forbidden: You do not have permission.';
          break;
        case 404:
          errorMessage = 'Not Found: Resource could not be found.';
          break;
        case 500:
          errorMessage = 'Internal Server Error.';
          break;
        case 503:
          errorMessage = 'Service Unavailable.';
          break;
        default:
          errorMessage = `Unexpected Error (Status Code: ${status})`;
      }

      await Actions.fireNotificationEvent(context, {
        summary: 'Error occurred while fetching data',
        type: 'error',
        displayMode: 'transient',
        message: errorMessage,
      });
    }

    async handleUnexpectedError(context, error) {
      await Actions.fireNotificationEvent(context, {
        summary: 'Unexpected error occurred',
        type: 'error',
        displayMode: 'transient',
        message: error.message || 'Unknown error occurred.',
      });
    }

    async restorePersistedSelections(context) {
      const { $variables, $functions } = context;

      if ($variables.pfrBudgetYearSelectedPersistVar) {
        $variables.pfrBudgetYearSelectedVar =
          await $functions.arrayToSet($variables.pfrBudgetYearSelectedPersistVar);
      } else {
        $variables.pfrBudgetYearSelectedVar = '';
      }

      if ($variables.pfrOperationSelectedPersistVar) {
        $variables.pfrOperationSelectedVar =
          await $functions.arrayToSet($variables.pfrOperationSelectedPersistVar);
      } else {
        $variables.pfrOperationSelectedVar = '';
      }
    }
  }

  return onLoadPFRPage;
});
