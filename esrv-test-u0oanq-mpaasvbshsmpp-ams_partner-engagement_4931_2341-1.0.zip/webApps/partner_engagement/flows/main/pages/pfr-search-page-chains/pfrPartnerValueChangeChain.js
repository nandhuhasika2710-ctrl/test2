define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class fpPartnerValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
      if ($variables.pfrPartnerSelectedVar === '' || $variables.pfrPartnerSelectedVar === null || $variables.pfrPartnerSelectedVar === undefined) {
        $variables.pfrPartnerSelectedPersistVar = [];

      } else {

        const setToArray = await $functions.setToArray($variables.pfrPartnerSelectedVar);

        $variables.pfrPartnerSelectedPersistVar = setToArray;
      }
      const fpArray = Array.from(value || []);
      let fpPartner = fpArray.length > 0 ? fpArray.join(',') : null;
      //
      const selectedIds = Array.from(value);
      let valuesArray;
      let numberOfValues;
      if (fpPartner !== null) {
        valuesArray = fpPartner.split(',');
        numberOfValues = valuesArray.length;

        if (selectedIds.includes(7777) && (numberOfValues > 1)) {
          await Actions.resetVariables(context, {
            variables: [
              '$variables.pfrPartnerSelectedVar',
            ],
          });
          fpPartner = null;
        }
        else {
          const ispartnerid = selectedIds.includes(7777);
          if (ispartnerid) {
            const itemsArray = $page.variables.pfrPartnerLovADP.data;
            const allValuesArray = itemsArray.map(item => item.partner_number).filter(partner_number => partner_number !== 7777);
            $variables.pfrPartnerSelectedVar = new Set(allValuesArray);

          }

          // if (!ispartnerid) {

          //   const response = await Actions.callRest(context, {
          //     endpoint: 'pfmGateway/getGetcontract_number',
          //     uriParams: {
          //       'p_partner': fpPartner,
          //     },
          //   });
          //   if (!response.ok) {
          //     await Actions.fireNotificationEvent(context, {
          //       summary: 'Contract Lov Data Load Failed',
          //       message: response.status + ' - ' + response.statusText,
          //     });

          //   }
          //   else {
          //     let items = response.body.items;
          //     items.unshift({
          //       contract_number: "Select All / Clear All",
          //       contract_number_id: "ALL"
          //     });
          //     $variables.pfrContractNumberADP.data = response.body.items;
          //   }
          // }
        }

      }

      if (fpPartner === null && $application.variables.loginType === 'Partner') {
        $variables.pfrSearchPayload.partner = $variables.defaultTypeNumberForPartner;
      }
      else {
        $variables.pfrSearchPayload.partner = fpPartner;
      }

      if (fpPartner == null) {
        // $variables.pfrContractNumberADP.data = [];
        // $variables.pfrContractNumberSelectedPersistVar = [];
        $variables.pfrPartnerSelectedVar = '';
      }
      if ($variables.pfrContractNumberSelectedPersistVar === '' || $variables.pfrContractNumberSelectedPersistVar === null || $variables.pfrContractNumberSelectedPersistVar === undefined) {
        $variables.pfrContractNumberSelectedVar = '';
      } else {
        const arrayToSet = await $functions.arrayToSet($variables.pfrContractNumberSelectedPersistVar);

        $variables.pfrContractNumberSelectedVar = arrayToSet;
      }

    }
  }

  return fpPartnerValueChangeChain;
});
