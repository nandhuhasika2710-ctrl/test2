define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class statusAssign extends ActionChain {
    async run(context) {
      const { $application, $variables, $flow } = context;

      await Actions.resetVariables(context, {
        variables: [
    '$flow.variables.selectedStatus',
  ],
      });

      const statusOrder = [
        { id: '0', label: $application.translations.appBundle.train_pfrlabel_draft, },
        { id: '1', label: $application.translations.appBundle.train_label_proposed},
        { id: '2', label: $application.translations.appBundle.train_pfrlabel_verifiedrevised },
        { id: '3', label: $application.translations.appBundle.train_pfrlabel_agreed },
        { id: '4', label: $application.translations.appBundle.train_pfrlabel_approved},
       
      ];

      const statusIndexMap = {
        'Draft': 0,
        'Proposed': 1,
        'Verified Revised': 2,
        'Agreed': 3,
        'Approved': 4
      };

      const currentStatus = $variables.pfr_Status;
      const currentIndex = statusIndexMap[currentStatus];

      if (currentIndex === undefined) {
        console.warn('Unknown status:', currentStatus);
        return;
      }

      $flow.variables.steps = statusOrder.map((step, index) => ({
        ...step,
        disabled: true,
        messageType: index < currentIndex ? 'confirmation' : 
                      index === currentIndex ? 'confirmation' : 
                      'none'
      }));

      $flow.variables.selectedStatus = statusOrder[currentIndex].id;

      await Actions.fireNotificationEvent(context, {
        summary: JSON.stringify($flow.variables.selectedStatus),
      });
    }
  }

  return statusAssign;
});
