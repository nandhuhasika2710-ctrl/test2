define(['ojs/ojpagingdataproviderview', 'ojs/ojarraydataprovider'], (PagingDataProviderView, ArrayDataProvider) => {
  'use strict';

  class PageModule {


    createPDP(ppArray) {
      return new PagingDataProviderView(new ArrayDataProvider(ppArray, { idAttribute: 'prepayment_request_number' }));
    }

    // isButtonDisabled(userRole, ppStatus, draftSubmissionStatus) {
    //   const role = userRole;
    //   const status = ppStatus;
    //   const submissionStatus = (draftSubmissionStatus || "").toUpperCase();
    //   const isSuperUser = role === "PFM_SUPERUSER";
    //   if (status === "Canceled" || status === "Rejected") {
    //     return true;
    //   }
    //   if (isSuperUser) {
    //     return false;
    //   }

    //   const isPartner = role === "PARTNER_USER";
    //   const isOfficer =
    //     role === "SENIOR_PROGRAMME_OFFICER" ||
    //     role === "JUNIOR_PROGRAMME_OFFICER";
    //   const isController =
    //     role === "SENIOR_PROJECT_CONTROL" ||
    //     role === "JUNIOR_PROJECT_CONTROL";


    //   const isDraft = submissionStatus === "DRAFT";
    //   const isSubmit = submissionStatus === "SUBMIT";

    //   /* ---------- PROPOSED ---------- */

    //   if (status === "Draft") {
    //     if (isPartner) return false;
    //     return true;
    //   }

    //   if (status === "Proposed") {
    //     if (isDraft && isPartner) return false;
    //     if (isSubmit && isOfficer) return false;
    //     return true;
    //   }

    //   /* ---------- ENDORSED / REVISED ---------- */
    //   if (status === "Verified") {
    //     if (isDraft && isOfficer) return false;
    //     if (isSubmit && isController) return false;
    //     return true;
    //   }

    //   if (status === "Agreed") {
    //     if (isDraft && isController) return false;
    //     return true;
    //   }

    //   if (status === "Revised") {
    //     if (isDraft && isOfficer) return false;
    //     if (isDraft && isController) return false;
    //     if (isSubmit && isPartner) return false;
    //     return true;
    //   }



    //   return true;
    // }
    // isButtonDisabled(userRole, ppStatus, draftSubmissionStatus, buttonType) {
    //   const role = userRole;
    //   const status = ppStatus;
    //   const submissionStatus = (draftSubmissionStatus || "").toUpperCase();

    //   const isSuperUser = role === "PFM_SUPERUSER";
    //   let result = true;

    //   if (status === "Canceled" || status === "Rejected") {
    //     result = true;
    //   }

    //   if (isSuperUser) {
    //     result = false;
    //   }

    //   const isPartner = role === "PARTNER_USER";
    //   const isOfficer =
    //     role === "SENIOR_PROGRAMME_OFFICER" ||
    //     role === "JUNIOR_PROGRAMME_OFFICER";
    //   const isController =
    //     role === "SENIOR_PROJECT_CONTROL" ||
    //     role === "JUNIOR_PROJECT_CONTROL";

    //   const isDraft = submissionStatus === "DRAFT";
    //   const isSubmit = submissionStatus === "SUBMIT";


    //   if (status === "Draft") {
    //     if (isPartner) result = false;
    //     else result = true;
    //   }

    //   else if (status === "Proposed") {
    //     if (isDraft && isPartner) result = false;
    //     else if (isSubmit && isOfficer) result = false;
    //     else result = true;
    //   }

    //   else if (status === "Verified") {
    //     if (isDraft && isOfficer) result = false;
    //     else if (isSubmit && isController) result = false;
    //     else result = true;
    //   }

    //   else if (status === "Agreed") {
    //     if (isDraft && isController) result = false;
    //     else result = true;
    //   }

    //   else if (status === "Revised") {
    //     if (isDraft && isOfficer) result = false;
    //     else if (isDraft && isController) result = false;
    //     else if (isSubmit && isPartner) result = false;
    //     else result = true;
    //   }

    //   if (!buttonType || buttonType === "edit") {
    //     return result;
    //   }

    //   if (buttonType === "lock" || buttonType === "unlock") {
    //     if (isPartner || status === "Agreed") {
    //       return true;
    //     }
    //     return result;
    //   }

    //   return result;
    // } raw data
    isButtonDisabled(userRole, ppStatus, draftSubmissionStatus, buttonType) {
      const role = userRole;
      const status = ppStatus;
      const submissionStatus = (draftSubmissionStatus || "").toUpperCase();

      const isSuperUser = role === "PFM_SUPERUSER";
      const isPartner = role === "PARTNER_USER";
      const isOfficer =
        role === "SENIOR_PROGRAMME_OFFICER" ||
        role === "JUNIOR_PROGRAMME_OFFICER";
      const isController =
        role === "SENIOR_PROJECT_CONTROL" ||
        role === "JUNIOR_PROJECT_CONTROL";

      const isDraft = submissionStatus === "DRAFT";
      const isSubmit = submissionStatus === "SUBMIT";
      let result = true;

      if (status === "Canceled" || status === "Rejected") {
        result = true;
      }

      if (
        isSuperUser &&
        (status === "Agreed" || status === "Approved") &&
        isSubmit
      ) {
        return true; 
      }

      if (isSuperUser) {
        result = false;
      }




      if (status === "Draft") {
        if (isPartner) result = false;
        else result = true;
      }

      else if (status === "Proposed") {
        if (isDraft && isPartner) result = false;
        else if (isSubmit && isOfficer) result = false;
        else result = true;
      }

      else if (status === "Verified") {
        if (isDraft && isOfficer) result = false;
        else if (isSubmit && isController) result = false;
        else result = true;
      }

      else if (status === "Agreed") {
        if (isDraft && isController) result = false;
        else result = true;
      }

      else if (status === "Revised") {
        if (isDraft && isOfficer) result = false;
        else if (isDraft && isController) result = false;
        else if (isSubmit && isPartner) result = false;
        else result = true;
      }

      if (!buttonType || buttonType === "edit") {
        return result;
      }

      if (buttonType === "lock" || buttonType === "unlock") {
        if (isPartner || status === "Agreed") {
          return true;
        }
        return result;
      }

      return result;
    }


    prepaymentTable(action, partner_name, invoice_number, invoice_amount_lcy, creation_date, prepayment_request_amount, prepayment_request_status, invoice_date, document_number, columns, sub_status) {


      const translationMap = {
        "action": action,
        "partner_name": partner_name,
        "invoice_number": invoice_number,
        "invoice_amount_lcy": invoice_amount_lcy,
        "creation_date": creation_date,
        "prepayment_request_amount": prepayment_request_amount,
        "prepayment_request_status": prepayment_request_status,
        "invoice_date": invoice_date,
        "document_number": document_number,
        "sub_status": sub_status
      };

      const defaultColumns = columns || [];
      const storedColumns = JSON.parse(localStorage.getItem("pptable")) || [];

      // Only keep columns that are currently in the view
      const activeFields = defaultColumns.map(col => col.field);
      let finalColumns = storedColumns.filter(col => activeFields.includes(col.field));
      // Add any new columns that are missing
      defaultColumns.forEach(defaultCol => {
        const exists = finalColumns.some(col => col.field === defaultCol.field);
        if (!exists) {
          finalColumns.push(defaultCol);
        }
      });


      finalColumns.forEach(column => {

        if (translationMap[column.field]) {
          column.headerText = translationMap[column.field];
        }


        column.resizable = "enabled";


        if (!column.sortable) {
          column.sortable = "enabled";
        }

        if (["modified_date", "creation_date"].includes(column.field)) {
          column.template = "date"; // date template
        }
        if (column.field === "prepayment_request_status") {
          column.template = "rowColorTemplate";
        }

        // if (column.field === "fpn_status") {
        //   column.width = 100;
        // }

        // if (column.field === "last_updated_by"||column.field === "partner_name"||column.field === "fpn_code") {
        //   column.width = 200;
        // }
      });
      console.log("finalcolumn" + JSON.stringify(finalColumns));
      return finalColumns;
    }

    getRowColor(status) {
      console.log("entering coloring part" + status);
      if (!status) return 'transparent';

      status = status.toLowerCase().trim();

      if (status === 'approved') return '#0000FF';


      return 'transparent';
    }

    setToArray(inputSet) {

      if (inputSet === null || typeof inputSet === 'undefined') {
        console.error("Input is null or undefined. Returning an empty array.");
        return [];
      }
      if (typeof inputSet[Symbol.iterator] !== 'function') {

        console.warn(`Input of type '${typeof inputSet}' is not iterable. Returning an empty array.`);
        return [];
      }
      return Array.from(inputSet);
    }

    arrayToSet(inputArray) {
      if (Array.isArray(inputArray)) {
        return new Set(inputArray);
      }
      return new Set();
    }




  }
  return PageModule;
});
