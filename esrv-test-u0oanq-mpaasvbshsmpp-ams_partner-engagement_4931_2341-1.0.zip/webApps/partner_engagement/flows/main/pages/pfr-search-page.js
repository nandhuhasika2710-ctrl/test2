define(['ojs/ojpagingdataproviderview', 'ojs/ojarraydataprovider', 'knockout', 'ojs/ojarraytreedataprovider', 'ojs/ojflattenedtreedataproviderview', 'ojs/ojknockouttemplateutils'], function (PagingDataProviderView, ArrayDataProvider, ko, ArrayTreeDataProvider, FlattenedTreeDataProviderView, KnockoutTemplateUtils) {
  'use strict';

  class PageModule {

    /**
     *
     * @param {string} arg1
     * @return {string}
     */
    searchPFR(data) {
      let results = [];

      for (let i = 0; i < data.length; i++) {
        let record = data[i];

        // You can process or filter the record here if needed
        results.push({
          // pfr_id: record.pfr_id,
          pfr_code: record.pfr_code,
          pfr_status: record.pfr_status,
          invoice_number: record.invoice_number,
          invoice_status: record.invoice_status,
          invoice_submission_date: record.invoice_submission_date,
          invoice_currency: record.invoice_currency,
          fpn_code: record.fpn_code,
          contract_number: record.contract_number,
          partner_name: record.partner_name,
          total_fpn_budget: record.total_fpn_budget,
          supplier_site_number: record.supplier_site_number,
          total_pfr_expenses: record.total_pfr_expenses,
          last_updated_by: record.last_updated_by,
          last_updated_date: record.last_updated_date,
          pfr_type: record.pfr_type,
          is_locked: record.is_locked,
          locked_by: record.locked_by
        });
      }

      return results;

    }



    // isButtonDisabled(userRole, pfrStatus, draftSubmissonStatus, isLocked, lockedBy, currentUser) {
    //   const role = userRole;
    //   const status = pfrStatus;
    //   let operation = "";
    //   let lockFlag = "N";
    //   let lockUser = null;

    //   if (typeof draftSubmissonStatus === "string") {
    //     const parts = draftSubmissonStatus.split("-");

    //     operation = (parts[0] || "").toLowerCase(); // draft / submit
    //     lockFlag = parts[1] || "N";                 // Y / N
    //     lockUser = parts.slice(2).join("-") || null; // email
    //   }
    //   if (status === "Canceled" || status === "Rejected") {
    //     return true;
    //   }
    //   const isSuperUser = role === "PFM_SUPERUSER";
    //   if (isSuperUser) {
    //     return false;
    //   }
    //   if (
    //     lockFlag === "Y" && lockUser && currentUser && lockUser.toLowerCase() !== currentUser.toLowerCase()
    //   ) {
    //     return true;
    //   }
    //   const isPartner = role === "PARTNER_USER";
    //   const isOfficer =
    //     role === "SENIOR_PROGRAMME_OFFICER" ||
    //     role === "JUNIOR_PROGRAMME_OFFICER";
    //   const isJuniorController = role === "JUNIOR_PROJECT_CONTROL";
    //   const isSeniorController = role === "SENIOR_PROJECT_CONTROL";

    //   const isDraft = operation === "draft";
    //   const isSubmit = operation === "submit";

    //   /* ---------- PROPOSED ---------- */

    //   if (status === "Draft") {
    //     if (isPartner) return false;
    //     return true;
    //   }

    //   if (status === "Proposed") {
    //     if (isDraft && isPartner) return false;
    //     if (isSubmit && isJuniorController) return false;

    //     return true;
    //   }

    //   /* ---------- ENDORSED / REVISED ---------- */
    //   if (status === "Verified") {
    //     if (isDraft && isJuniorController) return false;
    //     if (isSubmit && isSeniorController) return false;
    //     return true;
    //   }

    //   if (status === "Agreed") {
    //     if (isDraft && isSeniorController) return false;
    //     return true;
    //   }

    //   if (status === "Revised") {
    //     if (isDraft && isJuniorController) return false;
    //     if (isDraft && isSeniorController) return false;
    //     if (isSubmit && isPartner) return false;
    //     return true;
    //   }

    //   return true;
    // }
    isButtonDisabled(userRole, pfrStatus, draftSubmissonStatus, isLocked, lockedBy, currentUser, buttonType) {
      const role = userRole;
      const status = pfrStatus;

      let operation = "";
      let lockFlag = "N";
      let lockUser = null;

      if (typeof draftSubmissonStatus === "string") {
        const parts = draftSubmissonStatus.split("-");
        operation = (parts[0] || "").toLowerCase();
        lockFlag = parts[1] || "N";
        lockUser = parts.slice(2).join("-") || null;
      }

      const isSuperUser = role === "PFM_SUPERUSER";
      const isPartner = role === "PARTNER_USER";
      const isOfficer =
        role === "SENIOR_PROGRAMME_OFFICER" ||
        role === "JUNIOR_PROGRAMME_OFFICER";

      const isJuniorController = role === "JUNIOR_PROJECT_CONTROL";
      const isSeniorController = role === "SENIOR_PROJECT_CONTROL";

      const isDraft = operation === "draft";
      const isSubmit = operation === "submit";

      let result = true;

      if (status === "Canceled" || status === "Rejected") {
        result = true;
      }

      else if (
        isSuperUser &&
        (status === "Agreed" || status === "Approved") &&
        isSubmit
      ) {
        return true; 
      }

      else if (isSuperUser) {
        result = false;
      }
      else if (
        lockFlag === "Y" &&
        lockUser &&
        currentUser &&
        lockUser.toLowerCase() !== currentUser.toLowerCase()
      ) {
        result = true;
      }
      else if (status === "Draft") {
        if (isPartner) result = false;
        else result = true;
      }
      else if (status === "Proposed") {
        if (isDraft && isPartner) result = false;
        else if (isSubmit && isJuniorController) result = false;
        else result = true;
      }
      else if (status === "Verified") {
        if (isDraft && isJuniorController) result = false;
        else if (isSubmit && isSeniorController) result = false;
        else result = true;
      }
      else if (status === "Agreed") {
        if (isDraft && isSeniorController) result = false;
        else result = true;
      }
      else if (status === "Revised") {
        if (isDraft && isJuniorController) result = false;
        else if (isDraft && isSeniorController) result = false;
        else if (isSubmit && isPartner) result = false;
        else result = true;
      }



      if (buttonType === 'edit') {
        return result;
      }

      if (buttonType === 'lock' || buttonType === 'unlock') {
        if (isPartner || (status === "Agreed" && isSubmit)) {
          return true;
        }
        return result;
      }

      return result;
    }

    downloadFile(data, mimeType, filename) {
      const blob = new Blob([data], {
        type: mimeType
      });
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveOrOpenBlob(blob);
        return;
      }
      let link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = filename;
      link.click();
      // Firefox: delay revoking the ObjectURL
      setTimeout(function () {
        URL.revokeObjectURL(blob);
      }, 100);
    }

    searchPayload(operation, budgetYear, partnerNumber, contractNumber) {
      return {
        Operation_Code: operation,
        Budget_Year: budgetYear,
        Partner_Number: partnerNumber,
        Contract_Number: contractNumber
      };
    }

    toBase64(data, mimeType) {
      return new Promise((resolve, reject) => {
        const blob = new Blob([data], { type: mimeType });
        const reader = new FileReader();

        reader.onloadend = () => {
          const result = reader.result;

          // Remove "data:<mimeType>;base64," prefix
          const base64 = result.split(',')[1];

          resolve(base64);
        };

        reader.onerror = reject;
        reader.readAsDataURL(blob);
      });
    }

    createDocumentRegisterPayload(documentNumber, title, documentStatus, documentType, author, revisionDate, hasFile, autoNumber, agreementNumber, supplierName, supplierNumber, poNumber, documentName, projectId, content) {
      const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD

      return {
        DocumentRegister: [
          {
            DocumentNumber: documentNumber || null,
            Revision: null,
            Title: title || null,
            DocumentStatus: documentStatus || null,
            DocumentType: documentType || null,
            Author: null,
            RevisionDate: null,
            HasFile: hasFile || null,
            AutoNumber: autoNumber || null,
            AgreementNumber: agreementNumber || null,
            Implementer: supplierName || null,
            ImplementerNumber: supplierNumber || null,
            PurchaseOrderNumber: null,
            ProjectFinancialReportNumber: null,
            DocumentName: documentName || null,
            ProjectId: projectId || null,
            Content: content || null, // Base64 string
            IntegrationName: null,
            InitiatedFrom: null
          }
        ]
      };
    }



    pfrCreatePDP(data) {
      // Ensure data is always an array
      const safeData = Array.isArray(data) ? data : [];

      // Add fallback for is_locked and locked_by
      const processedData = safeData.map(row => ({
        ...row,
        is_locked: row.is_locked || 'N',
        locked_by: row.locked_by || null
      }));

      // Return PagingDataProviderView with processed data
      return new PagingDataProviderView(
        new ArrayDataProvider(processedData, { idAttribute: 'pfr_code' })
      );
    }

    fpnActiontableColumns(action,
      pfr_code,
      pfr_status,
      invoice_number,
      invoice_status,
      // invoice_submission_date,
      // fpn_code,
      // contract_number,
      partner_name,
      // total_fpn_budget,
      supplier_site_number,
      total_pfr_expenses,
      last_updated_by,
      last_updated_date,
      pfr_type,
      columns
    ) {
      const translationMap = {
        "action2": action,
        "pfr_code": pfr_code,
        "pfr_status": pfr_status,
        "invoice_number": invoice_number,
        "invoice_status": invoice_status,
        // "invoice_submission_date": invoice_submission_date,
        // "fpn_code":fpn_code,
        // "contract_number":contract_number,
        "partner_name": partner_name,
        // "total_fpn_budget":total_fpn_budget,
        "supplier_site_number": supplier_site_number,
        "total_pfr_expenses": total_pfr_expenses,
        "last_updated_by": last_updated_by,
        "last_updated_date": last_updated_date,
        "pfr_type": pfr_type
      };

      console.log("columns...." + JSON.stringify(columns));

      const defaultColumns = columns || [];
      const storedColumns = JSON.parse(localStorage.getItem("pfrtable")) || [];

      // Only keep columns that are currently in the view
      const activeFields = defaultColumns.map(col => col.field);
      let finalColumns = storedColumns.filter(col => activeFields.includes(col.field));

      // Add any new columns that are missing
      defaultColumns.forEach(defaultCol => {
        const exists = finalColumns.some(col => col.field === defaultCol.field);
        if (!exists) {
          finalColumns.push(defaultCol);
        }
      });


      finalColumns.forEach(column => {

        if (translationMap[column.field]) {
          column.headerText = translationMap[column.field];
        }


        column.resizable = "enabled";


        if (!column.sortable) {
          column.sortable = "enabled";
        }


        if (column.field === "invoice_status") {
          column.width = 100;
        }

        if (["last_updated_date"].includes(column.field)) {
          column.template = "date"; // date template
        }
        if (column.field === "total_pfr_expenses") {
          column.style = "text-align:right;";
        }

        if (column.field === "last_updated_by" || column.field === "partner_name" || column.field === "pfr_code") {
          column.width = 200;
        }
      });
      console.log("finalcolumn" + JSON.stringify(finalColumns));
      return finalColumns;
    }

    /**
     *
     * @param {string} arg1
     * @return {string}
     */
    testCode(input) {
      // console.log("input: " + JSON.stringify(input));

      const renameRules = [
        { key: "pfr_status", rename: "pfr_status" },
        { key: "output_code", rename: "outputCode" },
        { key: "output_description", rename: "outputDescription" },
        { key: "output_total_budget", rename: "baseLine" },
        { key: "output_line_comments", rename: "comments" },
        { key: "output_line_status", rename: "lineStatus" },
        { key: "output_direct_programme_cost", rename: "value" },
        { key: "output_expenses_ytd", rename: "expenses_ytd" },
        { key: "output_remaining_balance", rename: "remaining_balance" },
        { key: "output_reported_expenses", rename: "reported_expenses" },
        { key: "output_direct_shared_cost", rename: "ds" },
        { key: "output_indirect_support_cost", rename: "psc" },
        // { key: "fpn_location_code", parentMatches: ["accounts"], rename: "loc" },
        { key: "location_code", parentMatches: ["locations"], rename: "locationCode" },
        { key: "location_original_budget", rename: "baseLine" },
        { key: "output_location_direct_programme_cost", rename: "value" },
        { key: "location_direct_programme_cost", rename: "ds" },
        { key: "location_indirect_support_cost", rename: "psc" },
        { key: "location_line_status", rename: "lineStatus" },
        { key: "location_expenses_ytd", rename: "expenses_ytd" },
        { key: "location_remaining_balance", rename: "remaining_balance" },
        { key: "location_reported_expenses", rename: "reported_expenses" },
        { key: "location_line_comments", rename: "comments" },
        // { key: "negotiated_amount", parentMatches: ["direct_shared"], rename: "account_negotiated_amount" },
        { key: "pfr_account_id", parentMatches: ["accounts"], rename: "id" },
        { key: "account_line_amount", parentMatches: ["accounts"], rename: "value" },
        { key: "account", parentMatches: ["accounts"], rename: "accountCode" },
        { key: "account_description", parentMatches: ["accounts"], rename: "accountDescription" },
        { key: "account_line_comments", parentMatches: ["accounts"], rename: "comments" },
        { key: "account_expenses_ytd", rename: "expenses_ytd" },
        { key: "account_remaining_balance", rename: "remaining_balance" },
        { key: "account_reported_expenses", rename: "reported_expenses" },
        { key: "account_line_status", parentMatches: ["direct_shared"], rename: "account_status_code" },

        { key: "account_expenses_ytd", parentMatches: ["direct_shared"], rename: "expenses_ytd" },
        { key: "account_remaining_balance", parentMatches: ["direct_shared"], rename: "remaining_balance" },
        { key: "account_reported_expenses", parentMatches: ["direct_shared"], rename: "reported_expenses" },
        { key: "account_line_status", parentMatches: ["accounts"], rename: "lineStatus" },
        { key: "account", parentMatches: ["direct_shared", "indirect_support"], rename: "account_number" },
        { key: "total_cost", parentMatches: ["indirect_support"], rename: "total_cost" },

        // 
        { key: "account_line_comments", parentMatches: ["direct_shared"], rename: "account_line_comments" }
      ];

      // Recursive rename function
      const deepRename = function (obj, parentKey = null, ancestors = []) {
        const getRename = (key, parentKey, ancestors) => {
          for (const r of renameRules) {
            if (r.key === key) {
              if (r.parentMatches) {
                // Check if any ancestor matches the parentMatches condition
                if (ancestors && ancestors.some(a => r.parentMatches.includes(a))) return r.rename;
                if (parentKey && r.parentMatches.includes(parentKey)) return r.rename;
              } else {
                return r.rename;
              }
            }
          }
          return key; // return the original key if no match
        };

        if (Array.isArray(obj)) {
          return obj.map(item => deepRename(item, parentKey, ancestors)); // Recursively handle arrays
        }

        if (obj && typeof obj === "object") {
          const out = {};
          const newAncestors = parentKey ? [parentKey, ...ancestors] : ancestors;
          for (const [k, v] of Object.entries(obj)) {
            const newKey = getRename(k, parentKey, ancestors); // Get the renamed key
            out[newKey] = deepRename(v, k, newAncestors); // Recursively process nested objects
          }
          return out;
        }

        return obj; // Return primitive values as they are
      };

      // Process the input based on whether it's an array or object
      let finalArray;
      if (Array.isArray(input)) {
        finalArray = deepRename(input); // Process as array
      } else if (input && typeof input === "object" && Array.isArray(input.items)) {
        finalArray = deepRename(input.items, "items"); // Handle special case for items
      } else {
        finalArray = [deepRename(input)]; // Process as a single object
      }
      // console.log("finalarray" + JSON.stringify(finalArray));
      return finalArray;  // Return the final array
    }

    updateTreeDataProvider(programmeData) {
      const tree = this.convertArrayIntoTree(programmeData);
      const arrayTreeDP = new ArrayTreeDataProvider(tree, { keyAttributes: 'id' });
      this.dataSource(new FlattenedTreeDataProviderView(arrayTreeDP)); // set observable value
    }

    mapToPfrTemplate(items) {
      if (!items?.length) {
        throw new Error("No data found");
      }

      const pfr = items[0].pfr;

      const totals = (pfr.outputs || []).reduce(
        (acc, output) => {
          acc.t_ytd += output.output_expenses_ytd || 0;
          acc.t_exp += output.output_reported_expenses || 0;
          acc.t_bal += output.output_remaining_balance || 0;
          return acc;
        },
        { t_ytd: 0, t_exp: 0, t_bal: 0 }
      );

      return {
        // --- HEADER ---
        pfr_code: pfr.pfr_code || "",
        pfr_status: pfr.pfr_status || "",
        last_updated_date: pfr.last_updated_date || "",

        // --- REPORTING PERIOD ---
        start_date: pfr.reporting_period?.[0]?.reporting_period_start_date || "",
        end_date: pfr.reporting_period?.[0]?.reporting_period_end_date || "",
        pfr_type: pfr.reporting_period?.[0]?.pfr_type || "",

        // --- GENERAL INFO ---
        operation: pfr.operation_name || "",
        budget_year: pfr.budget_year || "",
        partner_name: pfr.partner_name || "",
        partner_site: pfr.partner_site_code || "",
        contract_currency: pfr.contract_currency_code || "",
        contract_number: pfr.contract_number || "",

        // --- SUMMARY ---
        scoped_budget: pfr.total_original_budget || 0,
        neg_budget: pfr.total_negotiated_budget || 0,
        budget_after_amen: pfr.budget_after_amendment || 0,
        total_expenses: pfr.total_pfr_expenses || 0,
        balance_after_expen: pfr.remaining_balance_after_expenses || 0,

        imple_rate: pfr.implementation_rate || 0,
        total_pfr_exp: pfr.total_pfr_expenses || 0,

        dp: pfr.total_direct_programme_cost || 0,
        ds: pfr.total_direct_shared_cost || 0,
        pisc: pfr.total_indirect_support_cost || 0,

        pisc_per:
          (pfr.indirect_support?.[0]?.partner_percentage || 0) + "%",
        ess_con: pfr.essential_controls || "",

        // --- INDIRECT SUPPORT TABLE ---
        indirect: (pfr.indirect_support || []).map(item => ({
          accounts: `${item.account} : ${item.account_description}`,
          value: item.planned_budget || 0,
          ytd: item.expenses_ytd || 0,
          bal: item.remaining_balance || 0,
          exp: item.reported_expenses || 0
        })),

        // --- DIRECT SHARED TABLE ---
        direct: (pfr.direct_shared || []).map(item => ({
          accounts: `${item.account} : ${item.account_description}`,
          value: item.account_line_amount || 0,
          ytd: item.expenses_ytd || 0,
          bal: item.remaining_balance || 0,
          exp: item.reported_expenses || 0
        })),

        // --- OUTPUTS (3 LEVEL: OUTPUT → LOCATION → ACCOUNTS) ---
        outputs: (pfr.outputs || []).map(output => ({
          output_label: `${output.output_code}: ${output.output_description}`,

          locations: (output.locations || []).map(loc => ({
            location: loc.location_code,

            pisc: loc.location_indirect_support_budget || 0,
            ds: loc.location_direct_shared_budget || 0,
            dp: loc.location_direct_programme_budget || 0,

            ytd: loc.location_expenses_ytd || 0,
            bal: loc.location_remaining_balance || 0,
            exp: loc.location_reported_expenses || 0,

            accounts: (loc.accounts || []).map(acc => ({
              accounts: `${acc.account} : ${acc.account_description}`,
              value: acc.account_line_amount || 0,
              ytd: acc.expenses_ytd || 0,
              bal: acc.remaining_balance || 0,
              exp: acc.reported_expenses || 0
            }))
          }))
        })),

        // --- TOTALS ---
        t_pisc: pfr.total_indirect_support_cost || 0,
        t_ds: pfr.total_direct_shared_cost || 0,
        t_dp: pfr.total_direct_programme_cost || 0,

        // (Not directly available → keep 0 or calculate if needed)
        t_ytd: totals.t_ytd,
        t_exp: totals.t_exp,
        t_bal: totals.t_bal
      };
    }

    docGeneratorPFRPayload(filename, pfrCode, bucketName, nameSpace, prefix, jsonObjectfolderName, templateFolderName, outputFolderName) {
      const filePath = prefix + "/" + jsonObjectfolderName + "/" + filename;
      const outputFilePath = prefix + "/" + outputFolderName + "/" + pfrCode + ".pdf";
      // const outputFilePath = prefix+"/"+subfolder+"/" + fpnCode + ".docx";
      const docPayload = {
        "requestType": "SINGLE",
        "tagSyntax": "DOCGEN_1_0",
        "data": {
          "source": "OBJECT_STORAGE",
          "namespace": nameSpace,
          "bucketName": bucketName,
          "objectName": filePath

        },
        "template": {
          "source": "OBJECT_STORAGE",
          "namespace": nameSpace,
          "bucketName": bucketName,
          "objectName": "PartnerFinancialManagement/Templates/PFR_Template.docx"
          // "objectName": "AssetManagement/Auction_Catalogue_Template1.docx"
        },
        "output": {
          "target": "OBJECT_STORAGE",
          "namespace": nameSpace,
          "bucketName": bucketName,
          "objectName": outputFilePath,
          "contentType": "application/pdf"
          // "contentType": "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        }

      };
      return docPayload;
    }

    updateTreeDataProviderForRecalculate(programmeData) {
      // console.log("programmeData" + JSON.stringify(programmeData));
      const tree = this.convertArrayIntoTreeForRecalculate(programmeData);
      const arrayTreeDP = new ArrayTreeDataProvider(tree, { keyAttributes: 'id' });
      this.dataSource(new FlattenedTreeDataProviderView(arrayTreeDP)); // set observable value
    }

    /**
     *
     * @param {string} arg1
     * @return {string}
     */
    convertArrayIntoTree(programmeData) {
      // console.log("programmeData" + JSON.stringify(programmeData));
      const tree = [];
      const uniqueIdPrefix = Date.now(); // Use current time as a unique prefix

      // Guard: check input data
      if (!Array.isArray(programmeData)) {
        return tree;
      }

      programmeData.forEach(item => {
        const outputs = Array.isArray(item?.pfr?.outputs) ? item.pfr.outputs : [];

        outputs.forEach(output => {
          if (!output) return;

          // Stable Output ID
          const outputNode = {
            id: `output-${output.pfr_output_id}`,
            type: 'output',
            name: output.outputDescription ?? '',
            outputCode: output.outputCode ?? '',
            outputDescription: output.outputDescription ?? '',
            baseLine: output.baseLine ?? null,
            psc: output.psc ?? null,
            ds: output.ds ?? null,
            value: output.value ?? null,
            expenses_ytd: output.expenses_ytd ?? null,
            remaining_balance: output.remaining_balance ?? null,
            reported_expenses: output.reported_expenses ?? null,
            last_baseline: output.last_baseline ?? null,
            total_expenses: output.total_expenses ?? null,
            comments: output.comments ?? '',
            lineStatus: output.lineStatus
              ? output.lineStatus.charAt(0).toUpperCase() + output.lineStatus.slice(1).toLowerCase()
              : '',
            children: [] // Locations
          };

          const locations = Array.isArray(output.locations) ? output.locations : [];

          locations.forEach(location => {
            if (!location) return;

            // Stable Location ID
            const locationNode = {
              id: `location-${location.pfr_location_id}`,
              pfr_output_id: location.pfr_output_id ?? null,
              pfr_location_id: location.pfr_location_id ?? null,
              type: 'location',
              name: location.locationCode ?? '',
              locationCode: location.locationCode ?? '',
              baseLine: location.baseLine ?? null,
              psc: location.psc ?? null,
              ds: location.ds ?? null,
              value: location.value ?? null,
              expenses_ytd: location.expenses_ytd ?? null,
              remaining_balance: location.remaining_balance ?? null,
              reported_expenses: location.reported_expenses ?? null,
              last_baseline: location.last_baseline ?? null,
              total_expenses: location.total_expenses ?? null,
              comments: location.comments ?? '',
              lineStatus: location.lineStatus
                ? location.lineStatus.charAt(0).toUpperCase() + location.lineStatus.slice(1).toLowerCase()
                : '',
              children: [] // Accounts
            };

            const accounts = Array.isArray(location.accounts) ? location.accounts : [];

            accounts.forEach(account => {
              if (!account) return;

              // Stable Account ID
              const accountNode = {
                id: `account-${account.pfr_output_id}-${account.id}-${account.accountCode}`,
                pfr_account_id: account.id ?? null,
                pfr_location_id: account.pfr_location_id ?? null,
                pfr_output_id: account.pfr_output_id ?? null,
                loc: account.loc ?? null,
                type: 'account',
                name: account.accountDescription ?? '',
                accountCode: account.accountCode ?? '',
                accountDescription: account.accountDescription ?? '',
                value: account.value ?? null,
                expenses_ytd: account.expenses_ytd ?? null,
                remaining_balance: account.remaining_balance ?? null,
                reported_expenses: account.reported_expenses ?? null,
                last_baseline: account.last_baseline ?? null,
                total_expenses: account.total_expenses ?? null,
                comments: account.comments ?? '',
                lineStatus: account.lineStatus
                  ? account.lineStatus.charAt(0).toUpperCase() + account.lineStatus.slice(1).toLowerCase()
                  : ''
              };

              locationNode.children.push(accountNode);
            });

            outputNode.children.push(locationNode);
          });

          tree.push(outputNode);
        });
      });
      // console.log("tree" + JSON.stringify(tree));
      return tree;
    }

    // claim pfr opa paylaod

    claimTaskPayload(pfrclaimDetails, pfr_id, pfr_code) {
      let items = [];
      let payload = {
        "items": items
      };
      let obj = {};
      obj.pfr_id = pfr_id;
      obj.pfr_code = pfr_code;
      obj.instance_id = pfrclaimDetails.instance_id || '';
      obj.task_id = pfrclaimDetails.task_id || '';
      obj.activity_instance_id = pfrclaimDetails.activity_instance_id || '';
      obj.locked_by = pfrclaimDetails.locked_by;
      obj.unlocked_by = pfrclaimDetails.unlocked_by;
      obj.is_locked = pfrclaimDetails.is_locked;

      items.push(obj);
      // console.log(payload);
      return payload;
    }
    // To add user for opa

    addUserOpaPayload(firstName, lastName, displayName, email, groupName) {
      const userObject = {
        "first_name": firstName,
        "last_name": lastName,
        "display_name": displayName,
        "group_name": groupName,
        "email": email,
        // The 'operation' is static for this use case
        "operation": "add"
      };

      const payload = {
        "Users": [userObject]
      };

      return payload;
    }

    // opa access token payload

    opaAccessTokenPayload(email) {
      const payload = {
        "integrationName": "Vbcs_Access_Token",
        "invokedBy": email,
        "scope": "OpaScope"
      };

      return payload;
    }

    // format token for opa

    formatAsBearerToken(token) {
      if (!token) {
        return "";
      }
      return `Bearer ${token}`;
    }
    setToArray(inputSet) {
      // 1. Check for null or undefined
      if (inputSet === null || typeof inputSet === 'undefined') {
        console.error("Input is null or undefined. Returning an empty array.");
        return []; // Return an empty array or throw an error, depending on desired behavior.
      }

      // 2. Check if the input is an iterable object
      // A common way to check for iterability is looking for the Symbol.iterator method.
      // Note: Strings (like '') are iterable and will pass this check.
      if (typeof inputSet[Symbol.iterator] !== 'function') {
        // If it's not a function (i.e., not iterable), log a warning and return an empty array.
        console.warn(`Input of type '${typeof inputSet}' is not iterable. Returning an empty array.`);
        return [];
      }

      // If the input passes the checks (or is a valid iterable like a Set or a String),
      // then Array.from() can safely be called.
      return Array.from(inputSet);
    }

    arrayToSet(inputArray) {
      // Check if the input is valid before creating the Set
      if (Array.isArray(inputArray)) {
        return new Set(inputArray);
      }
      // Return a new empty Set if the persisted value was null/undefined
      return new Set();
    }
  }

  return PageModule;
});
