define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TrainSelectChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $application, $variables } = context;

      const statusOrder = [
        { id: '0', label: $application.translations.appBundle.train_label_scoped },
        { id: '1', label: $application.translations.appBundle.train_label_proposed },
        { id: '2', label: $application.translations.appBundle.train_label_endorsedrevised },
        { id: '3', label: $application.translations.appBundle.train_label_agreed },
        { id: '4', label: $application.translations.appBundle.train_label_approved },
        { id: '5', label: $application.translations.appBundle.train_label_closed }
      ];

      const statusIndexMap = {
        'Scoped': 0,
        'Proposed': 1,
        'EndorsedRevised': 2,
        'Agreed': 3,
        'Approved': 4,
        'Closed': 5
      };

      const status = $variables.financialPlanStatus;
      const currentIndex = statusIndexMap[status];

      if (currentIndex === undefined) {
        console.warn('Unknown financialPlanStatus:', status);
        return;
      }

      $variables.steps = statusOrder.map((step, index) => ({
        ...step,
        disabled: index !== currentIndex,
        messageType: index === currentIndex ? 'confirmation' : 'none'
      }));

      $variables.selectedStatus = statusOrder[currentIndex].id;
    }



  }

  return TrainSelectChain;
});
