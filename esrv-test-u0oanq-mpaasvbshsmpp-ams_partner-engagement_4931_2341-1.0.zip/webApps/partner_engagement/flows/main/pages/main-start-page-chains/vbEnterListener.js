define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterListener extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
      if ($application.variables.sepratedPfrCode != null &&
        $application.variables.sepratedPfrCode !== '' &&
        $application.variables.sepratedPfrCode !== 'undefined') {

        const response3 = await Actions.callRest(context, {
          endpoint: 'pfmGateway/getPfrid',
          uriParams: {
            'pfr_code': $application.variables.sepratedPfrCode,
          },
        });

        const toShell2 = await Actions.navigateToPage(context, {
          page: '/shell/main/main-pfr-edit',
          params: {
            'p_pfr_Id': response3.body.items[0].pfr_id,
            'pfr_code': $application.variables.sepratedPfrCode,
            mode: 'EDIT',
            fpnCode: response3.body.items[0].fpn_code,
            'pfr_Status': response3.body.items[0].pfr_status,
          },
        });




      }
      if ($application.variables.sepratedPpCode != null &&
        $application.variables.sepratedPpCode !== '' &&
        $application.variables.sepratedPpCode !== 'undefined') {

        const response7 = await Actions.callRest(context, {
          endpoint: 'pfmGateway/getPrepaymentid',
          uriParams: {
            'prepayment_number': $application.variables.sepratedPpCode,
          },
        });

        const toShell = await Actions.navigateToPage(context, {
          page: '/shell/main/prepayment-add-edit',
          params: {
            ViewEditVar: 'Edit',
            mode: 'Edit',
            prepaymentDocumentNo: response7.body.items[0].fpn_code,
            prepaymentId: response7.body.items[0].prepayment_request_id,
            paramStatus: response7.body.items[0].prepayment_request_status,
            prepaymentRequestNumber: $application.variables.sepratedPpCode,
          },
        });




      }

      $variables.CurrentUserRole = $application.variables.userInfoObj.SelectedRoleName;

      if ($application.variables.isMultiRole === true) {

        $variables.overviewOperationSelectedPersistVar = [];
        $variables.overviewOperationSelectedVar = new Set();
        $variables.fpOperationSelectedPersistVar = [];
        $variables.fpOperationSelectedVar = new Set();

      }
      if ($application.variables.sepratedFPNCode != null &&
        $application.variables.sepratedFPNCode !== '' &&
        $application.variables.sepratedFPNCode !== 'undefined') {
        $application.variables.mainPageTabSelect = 'oj-tab-bar-2058186034-1-tab-2';
        $variables.financialplanTab = 'Edit';

        await Actions.callChain(context, {
          chain: 'fpnDataRedirectURL',
        });
      }

      $variables.formattedBUCode = $application.variables.userInfoObj.BUCode || '';

      const results2 = await Promise.all([
        async () => {
          const response = await Actions.callRest(context, {
            endpoint: 'pfmGateway/getGetcontract_number',
          });
          if (!response.ok) {
            await Actions.fireNotificationEvent(context, {
              summary: 'Contract Lov Data Load Failed',
              message: response.status + ' - ' + response.statusText,
            });

          }
          else {
            let items = response.body.items;
            items.unshift({
              contract_number: "Select All / Clear All",
              contract_number_id: "ALL"
            });
            $variables.fpContractNumberADP.data = response.body.items;
          }
        },
        async () => {
          const response2 = await Actions.callRest(context, {
            endpoint: 'pfmGateway/getGetbudgetyearlov',
          });

          if (!response2.ok) {
            await Actions.fireNotificationEvent(context, {
              summary: 'BudgetYear Lov Data Load Failed',
              message: response2.status + ' - ' + response2.statusText,
            });

          }
          else {
            let items = response2.body.items;
            items.unshift({
              budget_year: "Select All / Clear All",
              budget_year_id: 7777
            });

            $variables.ovBudgetYearLovADP.data = response2.body.items;
            $variables.fpBudgetYearLovADP.data = response2.body.items;
          }
        },
      ].map(sequence => sequence()));


      const tabTwoId = 'oj-tab-bar-2058186034-1-tab-2';
      const tabThreeId = 'oj-tab-bar-2058186034-1-tab-3';
      const tabFourId = 'oj-tab-bar-2058186034-1-tab-4';
      const currentSelection = $flow.variables.selectedTab;
      if (currentSelection === tabThreeId || currentSelection === tabFourId) {
        $flow.variables.selectedTab = tabTwoId;
      }

      if ($flow.variables.selectedTab === tabTwoId) {
        $variables.menuValue = [];
        $variables.menuValue = [...$variables.defaultViewColumns];
      }
      //  $variables.oicOperationsearchPayload.operation_code = $variables.securityOperationCodes; 
      // $variables.oicOperationsearchPayload.budget_year = null;  
      // $variables.oicOperationsearchPayload.partner_number = null;
      // $variables.oicOperationsearchPayload.contract_number = null;
      // const response = await Actions.callRest(context, {
      //   endpoint: 'OICService/postRetrieveBySearch',
      //   body: $variables.oicOperationsearchPayload,
      // });

      // $variables.fpsearchResultADP.data = response.body.items;

      //overview page//
      if ($variables.overviewOperationSelectedPersistVar === '' || $variables.overviewOperationSelectedPersistVar === null || $variables.overviewOperationSelectedPersistVar === undefined) {
        $variables.overviewOperationSelectedVar = '';
      }
      else {
        const arrayToSet = await $functions.arrayToSet($variables.overviewOperationSelectedPersistVar);

        $variables.overviewOperationSelectedVar = arrayToSet;
      }
      if ($variables.overviewBudgetYearSelectedPersistVar === '' || $variables.overviewBudgetYearSelectedPersistVar === null || $variables.overviewBudgetYearSelectedPersistVar === undefined) {
        $variables.overviewBudgetYearSelectedVar = '';
      } else {
        const arrayToSet = await $functions.arrayToSet($variables.overviewBudgetYearSelectedPersistVar);

        $variables.overviewBudgetYearSelectedVar = arrayToSet;
      }

      if ($variables.overviewPartnerSelectedPersistVar === '' || $variables.overviewPartnerSelectedPersistVar === null || $variables.overviewPartnerSelectedPersistVar === undefined) {
        $variables.overviewPartnerSelectedVar = '';
      } else {
        const arrayToSet = await $functions.arrayToSet($variables.overviewPartnerSelectedPersistVar);

        $variables.overviewPartnerSelectedVar = arrayToSet;
      }

      const ovBudgetArray = Array.from($variables.overviewBudgetYearSelectedVar || []);
      let ovBudgetYear = ovBudgetArray.length > 0 ? ovBudgetArray.join(',') : null;

      const ovOperationArray = Array.from($variables.overviewOperationSelectedVar || []);
      let ovOperation = ovOperationArray.length > 0 ? ovOperationArray.join(',') : null;

      const ovPatnerArray = Array.from($variables.overviewPartnerSelectedVar || []);
      let ovPatner = ovPatnerArray.length > 0 ? ovPatnerArray.join(',') : null;

      if (ovOperation == null) {
        ovOperation = $application.variables.securityOperationCodes;

      }

      //fpn page//
      if ($variables.fpBudgetYearSelectedPersistVar === '' || $variables.fpBudgetYearSelectedPersistVar === null || $variables.fpBudgetYearSelectedPersistVar === undefined) {
        $variables.fpBudgetYearSelectedVar = '';
      } else {
        const arrayToSet = await $functions.arrayToSet($variables.fpBudgetYearSelectedPersistVar);

        $variables.fpBudgetYearSelectedVar = arrayToSet;
      }
      if ($variables.fpOperationSelectedPersistVar === '' || $variables.fpOperationSelectedPersistVar === null || $variables.fpOperationSelectedPersistVar === undefined) {
        $variables.fpOperationSelectedVar = '';
      } else {
        const arrayToSet = await $functions.arrayToSet($variables.fpOperationSelectedPersistVar);

        $variables.fpOperationSelectedVar = arrayToSet;
      }

      if ($variables.fpPartnerSelectedPersistVar === '' || $variables.fpPartnerSelectedPersistVar === null || $variables.fpPartnerSelectedPersistVar === undefined) {
        $variables.fpPartnerSelectedVar = '';
      } else {
        const arrayToSet = await $functions.arrayToSet($variables.fpPartnerSelectedPersistVar);

        $variables.fpPartnerSelectedVar = arrayToSet;
      }

      if ($variables.fpContractNumberSelectedPersistVar === '' || $variables.fpContractNumberSelectedPersistVar === null || $variables.fpContractNumberSelectedPersistVar === undefined) {
        $variables.fpContractNumberSelectedVar = '';
      } else {
        const arrayToSet = await $functions.arrayToSet($variables.fpContractNumberSelectedPersistVar);

        $variables.fpContractNumberSelectedVar = arrayToSet;
      }
      const fpBudgetArray = Array.from($variables.fpBudgetYearSelectedVar || []);
      let fpBudget = fpBudgetArray.length > 0 ? fpBudgetArray.join(',') : null;

      const fpOperationArray = Array.from($variables.fpOperationSelectedVar || []);
      let fpOperation = fpOperationArray.length > 0 ? fpOperationArray.join(',') : null;

      const fpPatnerArray = Array.from($variables.fpPartnerSelectedVar || []);
      let fpPatner = fpPatnerArray.length > 0 ? fpPatnerArray.join(',') : null;

      const fpContractArray = Array.from($variables.fpContractNumberSelectedVar || []);
      let fpContract = fpContractArray.length > 0 ? fpContractArray.join(',') : null;

      if (fpOperation == null) {
        fpOperation = $application.variables.securityOperationCodes;
      }
      //overview page
      const results = await Promise.all([
        async () => {
          // $variables.searchPayloadButton.operation = $application.variables.securityOperationCodes;
          $variables.searchPayloadButton.operation = ovOperation;
          $variables.searchPayloadButton.partner = $application.variables.defaultPartnerNumber;

          if ($application.variables.loginType === 'Partner') {
            const response = await Actions.callRest(context, {
              endpoint: 'pfmGateway/getSearchoverview',
              uriParams: {
                'p_operation': ovOperation,
                'p_partner_id': $application.variables.defaultPartnerNumber,
                'p_year': ovBudgetYear,
              },
            });

            const overViewTablePagination = await $functions.overViewTablePagination(response.body.items);

            $variables.overviewTable = overViewTablePagination;
          }
          else {
            const response = await Actions.callRest(context, {
              endpoint: 'pfmGateway/getSearchoverview',
              uriParams: {
                'p_operation': ovOperation,
                'p_partner_id': ovPatner,
                'p_year': ovBudgetYear,
              },
            });

            const overViewTablePagination = await $functions.overViewTablePagination(response.body.items);

            $variables.overviewTable = overViewTablePagination;
          }
          if ($application.variables.loginType === 'Partner') {
            const response4 = await Actions.callRest(context, {
              endpoint: 'pfmORDS/getGetfpnstatus',
              uriParams: {
                'poperation_code': $variables.searchPayloadButton.operation,
                'p_partner_id': $application.variables.defaultPartnerNumber,
              },
            });
          }
          else {
            const response10 = await Actions.callRest(context, {
              endpoint: 'pfmORDS/getGetfpnstatus',
              uriParams: {
                'poperation_code': $variables.searchPayloadButton.operation,
              },
            });
          }
          if ($application.variables.loginType === 'Partner') {
            const response5 = await Actions.callRest(context, {
              endpoint: 'pfmORDS/getGetfpnvalues',
              uriParams: {
                'p_operation': $variables.searchPayloadButton.operation,
                'p_partner_id': $application.variables.defaultPartnerNumber,
              },
            });
          }
          else {
            const response11 = await Actions.callRest(context, {
              endpoint: 'pfmORDS/getGetfpnvalues',
              uriParams: {
                'p_operation': $variables.searchPayloadButton.operation,
              },
            });
          }

          if ($variables.searchPayload.operation == null) {

            $variables.searchPayloadButton.operation = $application.variables.ovUserInfo.security_context_code;
          }
        },
        //fpn page//
        async () => {
          // $variables.oicOperationsearchPayload.Operation_Code = $application.variables.securityOperationCodes;
          if ($application.variables.loginType === 'Partner') {
            $variables.oicOperationsearchPayload.Operation_Code = fpOperation;
            $variables.oicOperationsearchPayload.Budget_Year = fpBudget;
            $variables.oicOperationsearchPayload.Partner_Number = $application.variables.defaultPartnerNumber;
            $variables.oicOperationsearchPayload.Contract_Number = fpContract;
          }
          else {
            $variables.oicOperationsearchPayload.Operation_Code = fpOperation;
            $variables.oicOperationsearchPayload.Budget_Year = fpBudget;
            $variables.oicOperationsearchPayload.Partner_Number = fpPatner;
            $variables.oicOperationsearchPayload.Contract_Number = fpContract;
          }

          const response = await Actions.callRest(context, {
            endpoint: 'OICService/postRetrieveBySearch',
            body: $variables.oicOperationsearchPayload,
          });

          // const response = await Actions.callRest(context, {
          //   endpoint: 'pfmGateway/getGetfpn_details',
          // });

          
          if (response.body.hasOwnProperty("items")) {
            $variables.fpsearchResultADP.data = response.body.items;

            const searchTablePagination2 = await $functions.searchTablePagination(response.body.items);
            $variables.financialSearchPageTable = searchTablePagination2;


            if ($variables.fpSearchPayload.operation == null) {
              $variables.oicOperationsearchPayload.operation_code = $variables.securityOperationCodes;

              const response2 = await Actions.callRest(context, {
                endpoint: 'OICService/postRetrieveBySearch',
                body: $variables.oicOperationsearchPayload,
              });
              $variables.fpsearchResultADP.data = response2.body.items;
              const searchTablePagination3 = await $functions.searchTablePagination(response2.body.items);
              $variables.financialSearchPageTable = searchTablePagination3;
            }

          }
          else {
            $variables.fpsearchResultADP.data = [];

            const searchTablePagination2 = await $functions.searchTablePagination([]);
            $variables.financialSearchPageTable = searchTablePagination2;

          }

        },
      ].map(sequence => sequence()));



    }
  }

  return vbEnterListener;
});
