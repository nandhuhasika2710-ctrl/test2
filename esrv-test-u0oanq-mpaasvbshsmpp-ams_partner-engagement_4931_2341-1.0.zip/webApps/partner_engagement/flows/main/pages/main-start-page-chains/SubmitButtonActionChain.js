define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
  'ojs/ojarraytreedataprovider',
  'ojs/ojflattenedtreedataproviderview',
  'ojs/ojkeyset'
], (
  ActionChain,
  Actions,
  ActionUtils,
  ArrayTreeDataProvider,
  FlattenedTreeDataProviderView,
  keySet
) => {
  'use strict';

  class SubmitButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const progressbarOpen = await Actions.callComponentMethod(context, {
        selector: '#progressbar',
        method: 'open',
      });

      const tempData = $variables.temptableADP?.data || [];
      const fpnData = tempData[0]?.fpn || {};
      const directShared = fpnData.direct_shared?.[0];
      const indirectSupport = fpnData.indirect_support?.[0];

      const fpn_ds_id = directShared?.fpn_ds_id || '';
      const fpn_isc_id = indirectSupport?.fpn_isc_id || '';

      if ($variables.EssentialcontrolValidation !== 'valid') {
        await Actions.fireNotificationEvent(context, {
          summary: 'The Essential Control Field is mandatory.',
          displayMode: 'transient',
          type: 'error',
        });
        const progressbarClose12 = await Actions.callComponentMethod(context, {
          selector: '#progressbar',
          method: 'close',
        });

        return;
      }

      // Step 2: Build FPN Payload
      const buildFpnPayload = await $functions.buildFpnPayload(tempData, $variables.directSharedTableADP?.data || [], $variables.indirectSharedADP?.data || [], $variables.sharedCostTypeId || '', $variables.fpnComment || '', $variables.riskRatingLovValue || '', $application.variables.userInfoObj.UserID, $application.variables.userInfoObj.UserID, fpn_ds_id, fpn_isc_id, $variables.riskRatingTypeId, 'SUBMIT', $variables.retainRunValidationVar, $variables.indirectPartnerType, $variables.indirectPartnerPercentage, $application.variables.userRole);
      const validateFpnData = await $functions.validateFpnData(buildFpnPayload);
      if (!validateFpnData.valid) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Validation Failed',
          message: validateFpnData.message,
          displayMode: 'transient',
          type: 'error',
        });
        const progressbarClose = await Actions.callComponentMethod(context, {
          selector: '#progressbar',
          method: 'close',
        });

        return;
      }
      // Step 3: Recalculate FPN
      const responseRecalculate = await Actions.callRest(context, {
        endpoint: 'OICService/postRecalcuateFpn',
        body: buildFpnPayload,
      });

      // const responseRecalculate = await Actions.callRest(context, {
      //   endpoint: 'pfmGateway/postRecalculatefpn',
      //   body: buildFpnPayload,
      // });

      if (!responseRecalculate || !responseRecalculate.body || !responseRecalculate.body.status || responseRecalculate.body.status.toUpperCase() !== 'SUCCESS') {
        //  if (!response){
        await Actions.fireNotificationEvent(context, {
          summary: 'FPN Submission Failed',
          message: responseRecalculate.body.error_message || 'An unexpected error occurred during recalculate.',
          displayMode: 'transient',
        });

        await Actions.callChain(context, {
          chain: 'StatusRefreshIfSubmitFailed',
          params: {
            status: $variables.temptableADP.data[0].fpn.fpn_status,
          },
        });

        const progressbarClose2 = await Actions.callComponentMethod(context, {
          selector: '#progressbar',
          method: 'close',
        });
        return;
      }

      // Step 4: Save the FPN
      const responseSave = await Actions.callRest(context, {
        endpoint: 'OICService/postUpdate',
        uriParams: {
          'p_draft_status': 'SUBMIT',
        },
        body: responseRecalculate.body.data,
      });

      // const responseSave = await Actions.callRest(context, {
      //   endpoint: 'pfmGateway/putFpnrequest',
      //   uriParams: {
      //     'draft_status': 'SUBMIT',
      //   },
      //   body: responseRecalculate.body,
      // });

      if (!responseSave || !responseSave.body || !responseSave.body.Status || responseSave.body.Status.toUpperCase() === 'ERROR') {
        // if (responseSave?.body?.response !== 'SUCCESS') {
        await Actions.fireNotificationEvent(context, {
          summary: 'FPN Submission Failed',
          message: responseSave.body.StatusMessage || 'An unexpected error occurred during save.',
          displayMode: 'transient',
        });

        const response4 = await Actions.callRest(context, {
          endpoint: 'pfmGateway/putUpdateValidationstate',
          uriParams: {
            'doc_type': 'FPN',
            'draft_submission_status': 'DRAFT',
            'fpn_code': $variables.temptableADP.data[0].fpn.fpn_code,
            'validation_state': $variables.retainRunValidationVar,
          },
        });

        await Actions.callChain(context, {
          chain: 'StatusRefreshIfSubmitFailed',
          params: {
            status: $variables.temptableADP.data[0].fpn.fpn_status,
          },
        });

        const progressbarClose3 = await Actions.callComponentMethod(context, {
          selector: '#progressbar',
          method: 'close',
        });
        return;
      }


      const results = await Promise.all([
        async () => {
          // Step 5: Add User to OPA and Get Access Token
          const addUserOpaPayload = await $functions.addUserOpaPayload(
            $application.variables.userInfoObj.FirstName,
            $application.variables.userInfoObj.LastName,
            `${$application.variables.userInfoObj.FirstName}${$application.variables.userInfoObj.LastName}`,
            $application.variables.userInfoObj.UserID,
            $application.variables.opaUserGroup
          );
          if ($application.variables.userRole === 'PARTNER_USER' && $application.variables.loginType === 'Partner') {
            const responseOpaUserProvisioning = await Actions.callRest(context, {
              endpoint: 'opaOic/postPlatformUserprovisioning',
              body: addUserOpaPayload,
            });
            if (!responseOpaUserProvisioning.ok) {

              await Actions.fireNotificationEvent(context, {
                type: 'error',
                message: 'User Provisioning Service Failed',
                summary: 'FPN Submission Failed',
              });

              const response41 = await Actions.callRest(context, {
                endpoint: 'pfmGateway/putUpdateValidationstate',
                uriParams: {
                  'doc_type': 'FPN',
                  'draft_submission_status': 'DRAFT',
                  'fpn_code': $variables.temptableADP.data[0].fpn.fpn_code,
                  'validation_state': $variables.retainRunValidationVar,
                },
              });

              await Actions.callChain(context, {
                chain: 'StatusRefreshIfSubmitFailed',
                params: {
                  status: $variables.temptableADP.data[0].fpn.fpn_status,
                },
              });

              const progressbarClose13 = await Actions.callComponentMethod(context, {
                selector: '#progressbar',
                method: 'close',
              });

              return;
            }
          }
          const opaAccessTokenPayload = await $functions.opaAccessTokenPayload($application.variables.userInfoObj.UserID);

          const responseOpaAccessToken = await Actions.callRest(context, {
            endpoint: 'opaOic/postPlatformUserassertionmgmt',
            body: opaAccessTokenPayload,
          });

          if (!responseOpaAccessToken.ok) {

            const errorMsg =
              responseOpaAccessToken.body?.error_description ||
              responseOpaAccessToken.body?.error ||
              responseOpaAccessToken.statusText;

            await Actions.fireNotificationEvent(context, {
              summary: 'FPN Submission Failed',
              message: errorMsg,
              type: 'error',
            });
            const response42 = await Actions.callRest(context, {
              endpoint: 'pfmGateway/putUpdateValidationstate',
              uriParams: {
                'doc_type': 'FPN',
                'draft_submission_status': 'DRAFT',
                'fpn_code': $variables.temptableADP.data[0].fpn.fpn_code,
                'validation_state': $variables.retainRunValidationVar,
              },
            });
            await Actions.callChain(context, {
              chain: 'StatusRefreshIfSubmitFailed',
              params: {
                status: $variables.temptableADP.data[0].fpn.fpn_status,
              },
            });
            const progressbarClose14 = await Actions.callComponentMethod(context, {
              selector: '#progressbar',
              method: 'close',
            });
            return;
          }

          const formatAsBearerToken = await $functions.formatAsBearerToken(responseOpaAccessToken.body.access_token);
          $variables.opaAccessToken = formatAsBearerToken;
          const response2 = await Actions.callRest(context, {
            endpoint: 'pfmGateway/getUpdateValidationstate',
            uriParams: {
              'doc_type': 'FPN',
              'fpn_code': $variables.temptableADP.data[0].fpn.fpn_code,
            },
          });
          // Step 6: Retrieve OPA Instance
          const isPartner = $application.variables.userRole === 'PARTNER_USER';
          const isSuperUser = $application.variables.userRole === 'PFM_SUPERUSER';
          const responseInstances = await Actions.callRest(context, {
            endpoint: 'OPA/getInstances',
            uriParams: { businessKeyLike: $variables.temptableADP.data[0].fpn.fpn_code },
            headers: { Authorization: $variables.opaAccessToken },
          });

          const items = responseInstances.body.items || [];
          const activeInstances = items.filter(
            inst => inst.state === 'ACTIVE'
          );
           const activeInstance = responseInstances.body?.items?.find(i => i.state === 'ACTIVE');
          let instanceId = activeInstance?.rootInstanceId;
          const activeCount = activeInstances.length;
          
          if (activeCount > 0) {
            if (response2.body.items[0].reallocation_required === 'Y' && $variables.headerStatusValue.toUpperCase() === 'PROPOSED') {

              await Actions.fireNotificationEvent(context, {
                summary: 'Reallocation Submission Failed',
                message: 'Active Instance Found',
              });
              const response12 = await Actions.callRest(context, {
                endpoint: 'pfmGateway/putUpdateValidationstate',
                uriParams: {
                  'doc_type': 'FPN',
                  'draft_submission_status': 'DRAFT',
                  'fpn_code': $variables.temptableADP.data[0].fpn.fpn_code,
                  'validation_state': $variables.retainRunValidationVar,
                },
              });
              await Actions.callChain(context, {
                chain: 'StatusRefreshIfSubmitFailed',
                params: {
                  status: $variables.temptableADP.data[0].fpn.fpn_status,
                },
              });

              const progressbarClose15 = await Actions.callComponentMethod(context, {
                selector: '#progressbar',
                method: 'close',
              });

              return;

            }
            const responseActivities = await Actions.callRest(context, {
              endpoint: 'OPA/getInstancesInstanceIdActivities',
              uriParams: { instanceId: instanceId },
              headers: { Authorization: $variables.opaAccessToken },
            });

            const activities = responseActivities?.body?.activities || [];
            const hasActivities = activities.length > 0;


            // Step 7: Handle OPA instance for PARTNER_USER
            if (isPartner || (isSuperUser && !hasActivities)) {
              const opaSubmitPayload = await $functions.opaSubmitPayload(
                $variables.temptableADP.data[0].fpn.fpn_code,
                instanceId
              );

              const responseSubmit = await Actions.callRest(context, {
                endpoint: 'OPA/postMessages',
                body: opaSubmitPayload,
                headers: { Authorization: $variables.opaAccessToken },
              });

              if (responseSubmit.status === 202) {
                await Actions.fireNotificationEvent(context, {
                  summary: 'FPN Submitted Successfully',
                  message: 'FPN has been submitted successfully.',
                  type: 'confirmation',
                });

                const progressbarClose4 = await Actions.callComponentMethod(context, {
                  selector: '#progressbar',
                  method: 'close',
                });

                const results3 = await Promise.all([
                  async () => {
                    await Actions.callChain(context, {
                      chain: 'fpSearchButtonActionChain',
                    });
                  },
                  async () => {
                    await Actions.callChain(context, {
                      chain: 'cancelButtonActionChain',
                    });
                  },
                ].map(sequence => sequence()));
              } else {
                await Actions.fireNotificationEvent(context, {
                  summary: 'FPN Submission Failed',
                  message: 'OPA Call Failed. An unexpected error occurred.',
                });

                const response = await Actions.callRest(context, {
                  endpoint: 'pfmGateway/putUpdateValidationstate',
                  uriParams: {
                    'doc_type': 'FPN',
                    'draft_submission_status': 'DRAFT',
                    'fpn_code': $variables.temptableADP.data[0].fpn.fpn_code,
                    'validation_state': $variables.retainRunValidationVar,
                  },
                });
                await Actions.callChain(context, {
                  chain: 'StatusRefreshIfSubmitFailed',
                  params: {
                    status: $variables.temptableADP.data[0].fpn.fpn_status,
                  },
                });

                const progressbarClose5 = await Actions.callComponentMethod(context, {
                  selector: '#progressbar',
                  method: 'close',
                });

                return;
              }
            }
            else {
              if (!hasActivities) {
                await Actions.fireNotificationEvent(context, {
                  summary: 'FPN Submission Failed',
                  message: 'No active task available for this request.',
                  type: 'warning',
                  displayMode: 'transient',
                });

                // Optional: revert FPN to Draft
                await Actions.callRest(context, {
                  endpoint: 'pfmGateway/putUpdateValidationstate',
                  uriParams: {
                    doc_type: 'FPN',
                    draft_submission_status: 'DRAFT',
                    fpn_code: $variables.temptableADP.data[0].fpn.fpn_code,
                    validation_state: $variables.retainRunValidationVar,
                  },
                });
                await Actions.callChain(context, {
                  chain: 'StatusRefreshIfSubmitFailed',
                  params: {
                    status: $variables.temptableADP.data[0].fpn.fpn_status,
                  },
                });

                await Actions.callComponentMethod(context, {
                  selector: '#progressbar',
                  method: 'close',
                });

                return;
              }
              else {
                const responseActivityDetails = await Actions.callRest(context, {
                  endpoint: 'OPA/getAuditInstancesInstanceIdActivitiesActivityInstanceId',
                  uriParams: {
                    instanceId: instanceId,
                    activityInstanceId: responseActivities.body.activities[0].activityInstanceId,
                  },
                  headers: { Authorization: $variables.opaAccessToken },
                });

                if (!responseActivityDetails.body?.taskId) {
                  await Actions.fireNotificationEvent(context, {
                    summary: 'FPN Submission Failed',
                    message: 'The user task has not been created in OPA yet.',
                    type: 'warning',
                    displayMode: 'transient',
                  });
                  await Actions.callRest(context, {
                    endpoint: 'pfmGateway/putUpdateValidationstate',
                    uriParams: {
                      doc_type: 'FPN',
                      draft_submission_status: 'DRAFT',
                      fpn_code: $variables.temptableADP.data[0].fpn.fpn_code,
                      validation_state: $variables.retainRunValidationVar,
                    },
                  });
                  await Actions.callChain(context, {
                    chain: 'StatusRefreshIfSubmitFailed',
                    params: {
                      status: $variables.temptableADP.data[0].fpn.fpn_status,
                    },
                  });

                  await Actions.callComponentMethod(context, {
                    selector: '#progressbar',
                    method: 'close',
                  });
                  return;
                }


                const buildFpnOpaPayload = await $functions.buildFpnOpaPayload(tempData, $variables.directSharedTableADP?.data || [], $variables.indirectSharedADP?.data || [], $variables.sharedCostTypeId || '', $variables.fpnComment || '', $variables.riskRatingLovValue || '', $application.variables.userInfoObj.UserID, $application.variables.userInfoObj.UserID, fpn_ds_id, fpn_isc_id, $variables.riskRatingTypeId, 'SUBMIT', $variables.retainRunValidationVar, $variables.indirectPartnerType, $variables.indirectPartnerPercentage, $application.variables.userRole);

                const outcomeValue = $variables.headerStatusValue.toUpperCase();
                const commentValue = "Comment for task completion";

                const responseTaskUpdate = await Actions.callRest(context, {
                  endpoint: 'OPA/putTasksIdPayload',
                  uriParams: { id: responseActivityDetails.body.taskId },
                  body: buildFpnOpaPayload,
                  headers: { Authorization: $variables.opaAccessToken },
                });
                if (responseTaskUpdate.status !== 200) {
                  await Actions.fireNotificationEvent(context, {
                    summary: 'FPN Submission Failed',
                    message: responseTaskUpdate.body.message,
                  });
                  await Actions.callRest(context, {
                    endpoint: 'pfmGateway/putUpdateValidationstate',
                    uriParams: {
                      'doc_type': 'FPN',
                      'draft_submission_status': 'DRAFT',
                      'fpn_code': $variables.temptableADP.data[0].fpn.fpn_code,
                      'validation_state': $variables.retainRunValidationVar,
                    },
                  });
                  await Actions.callChain(context, {
                    chain: 'StatusRefreshIfSubmitFailed',
                    params: {
                      status: $variables.temptableADP.data[0].fpn.fpn_status,
                    },
                  });
                  const progressbarClose9 = await Actions.callComponentMethod(context, {
                    selector: '#progressbar',
                    method: 'close',
                  });

                  return;
                }

                const responseCompleteTask = await Actions.callRest(context, {
                  endpoint: 'OPA/completeatask',
                  uriParams: { id: responseActivityDetails.body.taskId },
                  body: { comment: commentValue, outcome: outcomeValue },
                  headers: { Authorization: $variables.opaAccessToken },
                });
                const opaError =
                  responseCompleteTask.body &&
                  (
                    responseCompleteTask.body.errorCode ||
                    (responseCompleteTask.body.status && responseCompleteTask.body.status >= 400)
                  );

                if (opaError) {
                  await Actions.fireNotificationEvent(context, {
                    summary: 'FPN Submission Failed',
                    message: responseCompleteTask.body.message ||
                      'OPA workflow rejected the action.',
                    type: 'error',
                    displayMode: 'transient',
                  });
                  await Actions.callRest(context, {
                    endpoint: 'pfmGateway/putUpdateValidationstate',
                    uriParams: {
                      doc_type: 'FPN',
                      draft_submission_status: 'DRAFT',
                      fpn_code: $variables.temptableADP.data[0].fpn.fpn_code,
                      validation_state: $variables.retainRunValidationVar,
                    },
                  });
                  await Actions.callChain(context, {
                    chain: 'StatusRefreshIfSubmitFailed',
                    params: {
                      status: $variables.temptableADP.data[0].fpn.fpn_status,
                    },
                  });


                  const progressbarClose10 = await Actions.callComponentMethod(context, {
                    selector: '#progressbar',
                    method: 'close',
                  });
                  return;
                }
                else {
                  await Actions.fireNotificationEvent(context, {
                    summary: 'FPN Submitted Successfully',
                    message: 'FPN has been submitted successfully.',
                    type: 'confirmation',
                  });

                  const progressbarClose6 = await Actions.callComponentMethod(context, {
                    selector: '#progressbar',
                    method: 'close',
                  });

                  const results2 = await Promise.all([
                    async () => {
                      await Actions.callChain(context, {
                        chain: 'fpSearchButtonActionChain',
                      });
                    },
                    async () => {
                      await Actions.callChain(context, {
                        chain: 'cancelButtonActionChain',
                      });
                    },
                    async () => {

                      if ($variables.temptableADP.data[0].fpn.fpn_status === 'Agreed') {
                        await Actions.callChain(context, {
                          chain: 'PrintActionChain',
                          params: {
                            mode: 'SUBMIT',
                            fpnCode: $variables.temptableADP.data.fpn.fpn_code,
                            status: $variables.temptableADP.data[0].fpn.fpn_status,
                          },
                        });
                      }
                    },
                  ].map(sequence => sequence()));

                }

              }
            }
          }
          else {

            // const response2 = await Actions.callRest(context, {
            //   endpoint: 'pfmGateway/getUpdateValidationstate',
            //   uriParams: {
            //     'doc_type': 'FPN',
            //     'fpn_code': $variables.temptableADP.data[0].fpn.fpn_code,
            //   },
            // });

            if (response2.body.items[0].reallocation_required === 'Y' && $variables.headerStatusValue.toUpperCase() === 'PROPOSED') {

              const reallocationPayload = await $functions.buildreallocationPayload(tempData, $variables.directSharedTableADP?.data || [], $variables.indirectSharedADP?.data || [], $variables.sharedCostTypeId || '', $variables.fpnComment || '', $variables.riskRatingLovValue || '', $application.variables.userInfoObj.UserID, $application.variables.userInfoObj.UserID, fpn_ds_id, fpn_isc_id, $variables.riskRatingTypeId, 'SUBMIT', $variables.retainRunValidationVar, $variables.indirectPartnerType, $variables.indirectPartnerPercentage, $application.variables.userRole);
              const response3 = await Actions.callRest(context, {
                endpoint: 'OPA/postInstances',
                headers: {
                  Authorization: $variables.opaAccessToken,
                },
                body: reallocationPayload,
              });

              if (!response3.ok) {
                await Actions.fireNotificationEvent(context, {
                  summary: 'FPN Submission Failed',
                });
                const response43 = await Actions.callRest(context, {
                  endpoint: 'pfmGateway/putUpdateValidationstate',
                  uriParams: {
                    'doc_type': 'FPN',
                    'draft_submission_status': 'DRAFT',
                    'fpn_code': $variables.temptableADP.data[0].fpn.fpn_code,
                    'validation_state': $variables.retainRunValidationVar,
                  },
                });
                await Actions.callChain(context, {
                  chain: 'StatusRefreshIfSubmitFailed',
                  params: {
                    status: $variables.temptableADP.data[0].fpn.fpn_status,
                  },
                });

                const progressbarClose3 = await Actions.callComponentMethod(context, {
                  selector: '#progressbar',
                  method: 'close',
                });

                return;
              } else {
                await Actions.fireNotificationEvent(context, {
                  summary: 'FPN Submitted Successfully',
                  displayMode: 'transient',
                  type: 'confirmation',
                });



                const progressbarClose8 = await Actions.callComponentMethod(context, {
                  selector: '#progressbar',
                  method: 'close',
                });
                const results45 = await Promise.all([
                  async () => {
                    await Actions.callChain(context, {
                      chain: 'fpSearchButtonActionChain',
                    });
                  },
                  async () => {
                    await Actions.callChain(context, {
                      chain: 'cancelButtonActionChain',
                    });
                  },
                ].map(sequence => sequence()));




              }
            }
            else {
              await Actions.fireNotificationEvent(context, {
                summary: 'FPN Submission Failed',
                message: 'No OPA instance found.',
              });
              const response44 = await Actions.callRest(context, {
                endpoint: 'pfmGateway/putUpdateValidationstate',
                uriParams: {
                  'doc_type': 'FPN',
                  'draft_submission_status': 'DRAFT',
                  'fpn_code': $variables.temptableADP.data[0].fpn.fpn_code,
                  'validation_state': $variables.retainRunValidationVar,
                },
              });
              await Actions.callChain(context, {
                chain: 'StatusRefreshIfSubmitFailed',
                params: {
                  status: $variables.temptableADP.data[0].fpn.fpn_status,
                },
              });
              const progressbarClose7 = await Actions.callComponentMethod(context, {
                selector: '#progressbar',
                method: 'close',
              });

              return;
            }
          }

        },
        async () => {
          await Actions.fireDataProviderEvent(context, {
            target: $variables.commentsSDP,
            refresh: null,
          });

          const responseRetrieve = await Actions.callRest(context, {
            endpoint: 'OICService/getRetrieve',
            uriParams: { fpnCode: $variables.currentFpnCode },
          });

          // Handle any potential errors during data retrieval
          if (!responseRetrieve.ok) {
            await Actions.fireNotificationEvent(context, {
              summary: 'Data Retrieval Failed',
              message: 'Failed to retrieve the latest data after saving the draft.',
              displayMode: 'transient',
            });
            const progressbarClose11 = await Actions.callComponentMethod(context, {
              selector: '#progressbar',
              method: 'close',
            });

            return;
          }

          const testcode = await $functions.testcode(responseRetrieve.body.items);
          $variables.testVariable = testcode;
          $variables.temptableADP.data = testcode;

          // Convert the data into a tree structure
          const tree = $functions.convertArrayIntoTree($variables.temptableADP.data);
          const arrayTreeDP = new ArrayTreeDataProvider(tree, { keyAttributes: 'id' });
          $variables.arrayTreeDP = arrayTreeDP;
          $variables.dataSource = new FlattenedTreeDataProviderView($variables.arrayTreeDP);

          // Refresh the tree table data provider
          await Actions.fireDataProviderEvent(context, {
            refresh: null,
            target: $variables.treeTableADP,
          });

          // Update financial plan status and trigger other related chains
          $variables.financialPlanStatus = $variables.testVariable[0].fpn.fpn_status || '';
          $variables.fpnDraftSubmitStatus = responseRetrieve.body.items[0].fpn.draft_submission_status;

          await Actions.callChain(context, { chain: 'statusAssign' });
          await Actions.callChain(context, {
            chain: 'fpnUpdatePageAccessControl',
            params: { 'fpn_status': $variables.financialPlanStatus },
          });

          // Update direct shared and indirect shared data
          $variables.tempdirectSharedArray = $variables.testVariable[0].fpn.direct_shared || [];
          $variables.directSharedTableADP.data = $variables.tempdirectSharedArray;
          $variables.indirectSharedArray = $variables.testVariable[0].fpn.indirect_support || [];
          $variables.indirectSharedADP.data = $variables.indirectSharedArray;
          $variables.fpnComment = $variables.testVariable[0].fpn.fpn_comments || '';
          $variables.riskRatingLovValue = $variables.testVariable[0].fpn.essential_controls === '0%' ? '' : $variables.testVariable[0].fpn.essential_controls || '';
          $variables.headerStatusValue = $variables.testVariable[0].fpn.fpn_status || '';

          // Retrieve and update changelog information
          const responseChangelog = await Actions.callRest(context, {
            endpoint: 'pfmGateway/getFpnChangelog',
            uriParams: {
              'p_fpn_code': $variables.currentFpnCode,
            },
          });
          $variables.changeLogExportADP.data = responseChangelog.body.items;

          // Update general information
          $variables.genralInfo.operation = responseRetrieve.body.items[0].fpn.operation_name;
          $variables.genralInfo.budgetYear = responseRetrieve.body.items[0].fpn.budget_year;
          $variables.genralInfo.contractCurrency = responseRetrieve.body.items[0].fpn.contract_currency_code;
          $variables.genralInfo.toataloriginalbudget = responseRetrieve.body.items[0].fpn.total_original_budget;
          $variables.genralInfo.partnerName = responseRetrieve.body.items[0].fpn.partner_name;
          $variables.genralInfo.partnerERPSite = responseRetrieve.body.items[0].fpn.partner_site_code;
          $variables.genralInfo.contractNumber = responseRetrieve.body.items[0].fpn.contract_number;
          $variables.genralInfo.totalDirectProgramme = responseRetrieve.body.items[0].fpn.total_direct_programme_cost;
          $variables.genralInfo.totalNegotiatedBudget = responseRetrieve.body.items[0].fpn.total_negotiated_budget;
          $variables.genralInfo.totalDirectShared = responseRetrieve.body.items[0].fpn.total_direct_shared_cost;
          $variables.genralInfo.totalIndirectSupportCost = responseRetrieve.body.items[0].fpn.total_indirect_support_cost;
          $variables.genralInfo.totalPFRExpenses = responseRetrieve.body.items[0].fpn.total_expenses;
          $variables.sharedCostTypeId = responseRetrieve?.body?.items?.[0]?.fpn?.indirect_support?.[0]?.lookup_type_id || '';
          $variables.sharedCostLovValue = responseRetrieve?.body?.items?.[0]?.fpn?.indirect_support?.[0]?.shared_cost || '';
          $variables.retainRunValidationVar = responseRetrieve.body.items[0].fpn.validation_state;

          $variables.fpnDraftSubmitStatus = responseRetrieve.body.items[0].fpn.draft_submission_status;
          if ($variables.retainRunValidationVar === 'N') {

            $variables.validationColor = 'runvalidation_orange';

          }
          else if ($variables.retainRunValidationVar === 'Y') {

            $variables.validationColor = 'runvalidation_green';

          }
          if ($variables.fpnDraftSubmitStatus === 'SUBMIT') {
            $variables.disableSubmitButton = true;
          } else {
            $variables.disableSubmitButton = false;
          }
        },
      ].map(sequence => sequence()));


    }
  }

  return SubmitButtonActionChain;
});
