define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ISAddButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const mergeAccountIndirect = await $functions.mergeAccountIndirect($variables.indirectSharedADP.data, $variables.selectedISaccountADP.data);

      $variables.indirectSharedADP.data = mergeAccountIndirect;

      const ojDialogIsTabClose = await Actions.callComponentMethod(context, {
        selector: '#oj-dialog-isTab',
        method: 'close',
      });
    }
  }

  return ISAddButtonActionChain;
});
