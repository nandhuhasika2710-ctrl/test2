define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
  'ojs/ojarraytreedataprovider',
  'ojs/ojflattenedtreedataproviderview',
  'ojs/ojkeyset'
], (
  ActionChain,
  Actions,
  ActionUtils,
  ArrayTreeDataProvider,
  FlattenedTreeDataProviderView,
  keySet
) => {
  'use strict';

  class TableBeforeRowEditEndChain extends ActionChain {
    async run(context, { cancelEdit, rowKey, rowIndex, rowData }) {
      const { $variables, $functions } = context;

      $variables.retainRunValidationVar = 'N';

      $variables.validationColor = 'runvalidation_orange';
      $variables.fpnDraftSubmitStatus = 'DRAFT';

      $variables.expandLevel = 'both';

      // use existing array or empty one, but do not clone yet
      let expandedKeyArray = Array.isArray($variables.expandedKeys)
        ? [...$variables.expandedKeys]   // clone it
        : [];

      // Fire refresh event
      // await Actions.fireDataProviderEvent(context, {
      //   refresh: null,
      //   target: $variables.temptableADP
      // });

      // Avoid unnecessary object cloning
      const input1 = $variables.accountCurrent;
      if (rowData.outputCode) {
        input1.outputCode = rowData.outputCode;
      }

      // Update ADP
      const updatedData = await $functions.updateADP(
        $variables.temptableADP.data,
        input1
      );
      $variables.temptableADP.data = updatedData;

      // Convert array to tree
      const treeData = $functions.convertArrayIntoTree(updatedData);

      const treeOptions = {
        keyAttributes: 'id',
        keyAttributesScope: 'all'
      };

      const arrayTreeDP = new ArrayTreeDataProvider(treeData, treeOptions);

      const expandLevel = $variables.expandLevel || 'location';
      const additionalKeys = [];

      if ((expandLevel === 'location' || expandLevel === 'both') && rowData.fpn_location_id) {
        additionalKeys.push(`location-${rowData.fpn_location_id}`);
      }

      if ((expandLevel === 'output' || expandLevel === 'both') && rowData.fpn_output_id) {
        additionalKeys.push(`output-${rowData.fpn_output_id}`);
      }

      // Add unique only
      const set = new Set([...expandedKeyArray, ...additionalKeys]);
      expandedKeyArray = Array.from(set);
      console.log("Expanded Keys Before KeySet:", expandedKeyArray);
      console.log("Type Check:", expandedKeyArray.map(k => typeof k));

      let expandedKeySet = new keySet.ExpandedKeySet();

      // Clean invalid keys first
      expandedKeyArray = expandedKeyArray.filter(
        k => typeof k === 'string' || typeof k === 'number'
      );

      // IMPORTANT: do NOT reassign
      if (expandedKeyArray.length > 0) {
        expandedKeySet = expandedKeySet.add(expandedKeyArray);
      }

      const flattenedTreeDP = new FlattenedTreeDataProviderView(arrayTreeDP, {
        expanded: expandedKeySet
      });

      // Assign back
      $variables.arrayTreeDP = arrayTreeDP;
      $variables.dataSource = flattenedTreeDP;
      $variables.expandedKeys = expandedKeyArray;

      console.log('Tree view updated and expanded keys preserved:', expandedKeyArray);
    }
  }

  return TableBeforeRowEditEndChain;
});
