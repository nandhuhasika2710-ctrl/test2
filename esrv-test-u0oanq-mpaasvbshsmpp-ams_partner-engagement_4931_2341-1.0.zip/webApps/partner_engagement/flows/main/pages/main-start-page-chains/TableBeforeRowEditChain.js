define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TableBeforeRowEditChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.rowKey 
     * @param {number} params.rowIndex 
     * @param {any} params.rowData 
     */
    async run(context, { rowKey, rowIndex, rowData }) {
      const { $page, $flow, $application, $constants, $variables } = context;



      $variables.accountCurrent = rowData;

      if (
        $variables.accountCurrent.lineStatus === 'Revised' &&
        $application.variables.userRole !== 'PARTNER_USER'
      ) {
        $variables.accountCurrent.lineStatus = 'Proposed';
      }
        $variables.retainRunValidationVar = 'N';
        $variables.validationColor = 'runvalidation_orange';
        $variables.fpnDraftSubmitStatus = 'DRAFT';
    
    }
  }

return TableBeforeRowEditChain;
});
