define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterListenerfinacialplan extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      $variables.financialplanADP.data = $variables.financialPlanearray;

      const response2 = await Actions.callRest(context, {
        endpoint: 'pfmGateway/getSearchoverview',
        uriParams: {
          'p_year': $variables.fpSearchPayload.budgetYear,
          'p_operation': $variables.fpSearchPayload.operation,
          'p_partner_id': $variables.fpSearchPayload.partner,
        },
      });

      const overViewTablePagination = await $functions.overViewTablePagination(response2.body.items);

      $variables.overviewTable = overViewTablePagination;

      const response = await Actions.callRest(context, {
        endpoint: 'pfmGateway/getGetfpn_details',
        uriParams: {
          'pcontract_number': $variables.fpSearchPayload.contractNumber,
          pyear: $variables.fpSearchPayload.budgetYear,
          'ppartner_id': $variables.fpSearchPayload.partner,
          poperation: $variables.fpSearchPayload.operation,
        },
      });

      if (!response.ok) {
      
        return;
      } else {
        const searchTablePagination = await $functions.searchTablePagination(response.body.items);

        $variables.financialSearchPageTable = searchTablePagination;
      }
    }
  }

  return vbEnterListenerfinacialplan;
});
