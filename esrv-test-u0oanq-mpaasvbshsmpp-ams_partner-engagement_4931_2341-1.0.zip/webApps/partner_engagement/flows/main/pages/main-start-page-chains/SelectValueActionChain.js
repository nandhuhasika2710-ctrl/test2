define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SelectValueActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.value
     * @param {object} params.itemContext
     * @param {any} params.previousValue
     */
    async run(context, { event, value, itemContext, previousValue }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;



      const createPayloadFromIndividualNames = await $functions.createPayloadFromIndividualNames($application.variables.userInfoObj.UserID, $application.variables.userInfoObj.FirstName, $application.variables.userInfoObj.LastName, $variables.CurrentUserRole);
      const response3 = await Actions.callRest(context, {
        endpoint: 'pfmGateway/postUserinfo',
        body: createPayloadFromIndividualNames,
      });

      await Actions.resetVariables(context, {
        variables: [
          '$application.variables.code',
        ],
      });

      await Actions.callChain(context, {
        chain: 'application:vbEnterListener',
      });

    }
  }

  return SelectValueActionChain;
});
