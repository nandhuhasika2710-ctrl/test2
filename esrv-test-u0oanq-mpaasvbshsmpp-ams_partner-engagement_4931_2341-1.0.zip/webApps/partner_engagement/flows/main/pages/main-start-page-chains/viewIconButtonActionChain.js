define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
  'ojs/ojarraytreedataprovider',
  'ojs/ojflattenedtreedataproviderview',
], (
  ActionChain,
  Actions,
  ActionUtils,
  ArrayTreeDataProvider,
  FlattenedTreeDataProviderView
) => {
  'use strict';

  class viewIconButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { key, index, current }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.financialPlanStatus',
          '$page.variables.sharedCostLovValue',
          '$page.variables.sharedCostTypeId',
          '$page.variables.riskRatingLovValue',
          '$variables.validationColor',
          '$variables.financialPlanStatus',
          '$variables.sharedCostLovValue',
          '$variables.sharedCostTypeId',
          '$variables.riskRatingLovValue',
        ],
      });
      $variables.canEdit = false;
      $variables.financialplanTab = 'Edit';
      $variables.financialPlanStatus = current.row.fpn_status;
      $variables.currentFpnCode = current.row.fpn_code;

      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $variables.treeTableADP,
      });

      // $variables.fpnIdKey = key;

      const response = await Actions.callRest(context, {
        endpoint: 'OICService/getRetrieve',
        uriParams: {
          fpnCode: $variables.currentFpnCode,
        },
      });

      const convertFpnPayloadWithId = await $functions.convertFpnPayloadWithId(response.body.items);
      const testcode = await $functions.testcode(convertFpnPayloadWithId);
      $variables.testVariable = testcode;

      $variables.temptableADP.data = testcode;
      // console.log("testcode"+JSON.stringify(testcode));
      // console.log("tempADP"+JSON.stringify($variables.temptableADP.data));

      const tree = $functions.convertArrayIntoTree($variables.temptableADP.data); // Assuming you exposed this func
      const arrayTreeDP = new ArrayTreeDataProvider(tree, { keyAttributes: 'id' });
      $variables.arrayTreeDP = arrayTreeDP;  // save if needed
      $variables.dataSource = new FlattenedTreeDataProviderView($variables.arrayTreeDP);

      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $variables.treeTableADP,
      });

      $variables.fpnDraftSubmitStatus = response.body.items[0].fpn.draft_submission_status || 'DRAFT';
      if ($variables.fpnDraftSubmitStatus === 'DRAFT') {
        await Actions.callChain(context, {
          chain: 'draftStatusAssign',
        });

      }
      else if ($variables.fpnDraftSubmitStatus === 'SUBMIT') {

        await Actions.callChain(context, {
          chain: 'statusAssign',
        });
      }


      $variables.tempdirectSharedArray = $variables.testVariable[0].fpn.direct_shared || [];
      $variables.directSharedTableADP.data = $variables.tempdirectSharedArray;
      $variables.indirectSharedArray = $variables.testVariable[0].fpn.indirect_support || [];
      $variables.indirectSharedArray.forEach(item => {
        if (item.fpn_isc_id === null) {
          item.account_id = 15;  // Default account_id of IS
          item.account_number = 611120;  // Default account_number of IS
          item.account_description = "Partner - Indirect Support - IS";  // Default description
          item.lookup_type_id = 34;  // Default lookup_type_id
          item.account = "Indirect Support";  // Default account name
          // Leave the remaining fields as null (no changes to them)
          item.fpn_isc_id = null;  // Ensure fpn_isc_id remains null
          item.shared_cost = null;  // Ensure shared_cost remains null
          item.total_cost = null;  // Ensure total_cost remains null
        }
      });
      $variables.indirectSharedADP.data = $variables.indirectSharedArray;
      $variables.fpnComment = $variables.testVariable[0].fpn.fpn_comments || '';
      // $variables.riskRatingLovValue = $variables.testVariable[0].fpn.essential_controls || '';
      $variables.riskRatingLovValue = $variables.testVariable[0].fpn.essential_controls === '0%' ? '' : $variables.testVariable[0].fpn.essential_controls || '';
      $variables.headerStatusValue = $variables.testVariable[0].fpn.fpn_status || '';

      $variables.genralInfo.operation = response.body.items[0].fpn.operation_name;
      $variables.genralInfo.budgetYear = response.body.items[0].fpn.budget_year;
      $variables.genralInfo.contractCurrency = response.body.items[0].fpn.contract_currency_code;
      $variables.genralInfo.toataloriginalbudget = response.body.items[0].fpn.total_original_budget;
      $variables.genralInfo.partnerName = response.body.items[0].fpn.partner_name;
      $variables.genralInfo.partnerERPSite = response.body.items[0].fpn.partner_site_code;
      $variables.genralInfo.contractNumber = response.body.items[0].fpn.contract_number;
      $variables.genralInfo.totalDirectProgramme = response.body.items[0].fpn.total_direct_programme_cost;
      $variables.genralInfo.totalNegotiatedBudget = response.body.items[0].fpn.total_negotiated_budget;
      $variables.genralInfo.totalDirectShared = response.body.items[0].fpn.total_direct_shared_cost;
      $variables.genralInfo.totalIndirectSupportCost = response.body.items[0].fpn.total_indirect_support_cost;
      $variables.genralInfo.totalPFRExpenses = response.body.items[0].fpn.total_expenses;
      $variables.sharedCostTypeId = response?.body?.items?.[0]?.fpn?.indirect_support?.[0]?.lookup_type_id ?? 34;
      $variables.sharedCostLovValue = (response?.body?.items?.[0]?.fpn?.indirect_support?.[0]?.shared_cost || '') === ''
        ? 'No PISC:0%'
        : response?.body?.items?.[0]?.fpn?.indirect_support?.[0]?.shared_cost;
      $variables.retainRunValidationVar = response.body.items[0].fpn.validation_state;


    }
  }

  return viewIconButtonActionChain;
});
