define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SelectValueChangeChainDelete extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any[]} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
         $variables.selectedAccount = value;

      const response2 = await Actions.callRest(context, {
        endpoint: 'pfmGateway/getAccounts',
        uriParams: {
          'p_account_type': 'DP',
        },
      });

      const selectedAccountTable = await $functions.selectedAccountTable(response2.body.items, $variables.selectedAccount);

      $variables.selectedAccountTableADP.data = selectedAccountTable;
    }
  }

  return SelectValueChangeChainDelete;
});
