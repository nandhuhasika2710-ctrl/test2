define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class unlockActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key
     * @param {number} params.index
     * @param {any} params.current
     */
    async run(context, { key, index, current }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      /* ===============================
         OPEN PROGRESS BAR
      ================================ */
      await Actions.callComponentMethod(context, {
        selector: '#progressbar',
        method: 'open',
      });

      try {

      
        const response = await Actions.callRest(context, {
          endpoint: 'pfmGateway/getFpnclaim',
          uriParams: {
            'p_fpn_code': current.item.data.fpn_code,
          },
        });

        if (!response.ok || !response.body.items || response.body.items.length === 0) {
          throw {
            summary: 'FPN Details Load Failed',
            message: response.status + ' - ' + response.statusText,
          };
        }

        /* ===============================
           ACCESS CHECK
        ================================ */
        const isSuperUser = $application.variables.userRole === 'PFM_SUPERUSER';
        const isLockOwner =
          $application.variables.userInfoObj.UserID === response.body.items[0].locked_by;
        let lockedUserName = response.body.items[0].locked_by;

        if (!isSuperUser && !isLockOwner) {
          throw {
            summary: 'Access Denied to Unlock FPN',
            message: `This FPN is locked by ${lockedUserName}.`,
            type: 'warning',
          };
        }

      
        $variables.unclockDetails.activity_instance_id = '';
        $variables.unclockDetails.instance_id = '';
        $variables.unclockDetails.is_locked = 'N';
        $variables.unclockDetails.locked_by = response.body.items[0].locked_by;
        $variables.unclockDetails.task_id = '';
        $variables.unclockDetails.unlocked_by = $application.variables.userInfoObj.UserID;

        const claimTaskPayload =
          await $functions.claimTaskPayload(
            $variables.unclockDetails,
            current.item.data.fpn_code
          );

        const response3 = await Actions.callRest(context, {
          endpoint: 'pfmGateway/postFpnclaim',
          body: claimTaskPayload,
        });

        if (!response3.ok) {
          throw {
            summary: 'Unlock FPN Failed',
            message: response3.status + ' - ' + response3.statusText,
          };
        }

        /* ===============================
           UI REFRESH + SUCCESS MESSAGE
        ================================ */
        await Actions.fireDataProviderEvent(context, {
          refresh: null,
          target: $variables.fpSearchResultSDP,
        });

        await Actions.fireNotificationEvent(context, {
          summary: 'FPN Unlocked Successfully',
          type: 'confirmation',
          displayMode: 'transient',
        });

        Actions.callChain(context, {
          chain: 'vbEnterListener',
        });
        return;

      } catch (err) {

        /* ===============================
           CENTRAL ERROR HANDLING
        ================================ */
        await Actions.fireNotificationEvent(context, {
          summary: err.summary || 'Unlock Operation Failed',
          message: err.message || 'An unexpected error occurred',
          type: err.type || 'error',
          displayMode: 'transient',
        });

      } finally {

        /* ===============================
           CLOSE PROGRESS BAR (ALWAYS)
        ================================ */
        await Actions.callComponentMethod(context, {
          selector: '#progressbar',
          method: 'close',
        });
      }
    }
  }

  return unlockActionChain;
});
