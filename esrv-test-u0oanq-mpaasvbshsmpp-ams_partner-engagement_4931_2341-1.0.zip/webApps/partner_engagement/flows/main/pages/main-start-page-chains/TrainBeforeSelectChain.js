define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TrainBeforeSelectChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
   if ($variables.financialPlanStatus === 'Agreed') {
        $variables.selectedStatus = 3;
      }
       }
  }

  return TrainBeforeSelectChain;
});
