define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TabBarSelectionChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.selection 
     */
    async run(context, { selection }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $flow.variables.selectedTab = selection;

      if (selection === 'oj-tab-bar-2058186034-1-tab-1') {
        $application.variables.pageTitle = 'Overview';
      } else if (selection === 'oj-tab-bar-2058186034-1-tab-2') {
        if (true) {
          $application.variables.pageTitle = 'Financial Plan';
          $variables.financialplanTab = 'Tab';
          $variables.menuValue = [];

          $variables.menuValue = $variables.defaultViewColumns;
        }
      } else if (selection === 'oj-tab-bar-2058186034-1-tab-3') {
        if (true) {
          $application.variables.pageTitle = 'Project Financial Report';

          const toPfrSearch = await Actions.navigateToPage(context, {
            page: 'pfr-search',
            params: {
              pfrTab: 'Tab',
            },
          });
        }
      } else if (selection === 'oj-tab-bar-2058186034-1-tab-4') {
        if (true) {
          $application.variables.pageTitle = 'Prepayment';

          const toPrepaymentSearch = await Actions.navigateToPage(context, {
            page: 'prepayment-search',
            params: {
              prepaymentTab: 'Tab',
            },
          });
        }
      } else if (selection === 'oj-tab-bar-2058186034-1-tab-5') {
        if (true) {
          $application.variables.pageTitle = 'Refund';
        }
      } else if (selection === 'oj-tab-bar-2058186034-1-tab-6') {
        if (true) {
          $application.variables.pageTitle = 'Reports';
        }
      } else {
        $application.variables.pageTitle = undefined;
      }
    }
  }

  return TabBarSelectionChangeChain;
});
