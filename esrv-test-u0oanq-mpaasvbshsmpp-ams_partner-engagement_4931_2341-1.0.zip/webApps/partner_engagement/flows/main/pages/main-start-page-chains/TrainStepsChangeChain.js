define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TrainStepsChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any[]} params.steps 
     */
    async run(context, { steps }) {
      const { $page, $flow, $application, $constants, $variables } = context;
    }
  }

  return TrainStepsChangeChain;
});
