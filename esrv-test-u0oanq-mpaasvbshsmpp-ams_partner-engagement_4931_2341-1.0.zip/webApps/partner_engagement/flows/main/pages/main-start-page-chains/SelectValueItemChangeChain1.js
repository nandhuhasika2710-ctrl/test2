define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SelectValueItemChangeChain1 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.previousValue
     * @param {any} params.value
     * @param {string} params.updatedFrom
     * @param {any} params.key
     * @param {any} params.data
     * @param {any} params.metadata
     * @param {any} params.valueItem
     */
    async run(context, { event, previousValue, value, updatedFrom, key, data, metadata, valueItem }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
            const createPayloadFromIndividualNames = await $functions.createPayloadFromIndividualNames($application.variables.userInfoObj.UserID, $application.variables.userInfoObj.FirstName, $application.variables.userInfoObj.LastName, $variables.CurrentUserRole);
      const response3 = await Actions.callRest(context, {
            endpoint: 'pfmGateway/postUserinfo',
            body: createPayloadFromIndividualNames,
          });

      await Actions.resetVariables(context, {
        variables: [
    '$application.variables.code',
  ],
      });

      await Actions.callChain(context, {
        chain: 'application:vbEnterListener',
      });
    }
  }

  return SelectValueItemChangeChain1;
});
