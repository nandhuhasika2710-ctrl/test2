define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class DSaddAcountValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any[]} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      $variables.selectedDSaccount = value;

      const response = await Actions.callRest(context, {
        endpoint: 'pfmGateway/getAccounts',
        uriParams: {
          'p_account_type': 'DS',
        },
      });

      const selectedDSAccountTable = await $functions.selectedDSAccountTable(response.body.items, $variables.selectedDSaccount);

      $variables.selectedDSaccountADP.data = selectedDSAccountTable;
    }
  }

  return DSaddAcountValueChangeChain;
});
