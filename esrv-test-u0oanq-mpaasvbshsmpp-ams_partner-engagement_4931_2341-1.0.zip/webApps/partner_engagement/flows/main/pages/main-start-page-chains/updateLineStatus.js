define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
  'ojs/ojarraytreedataprovider',
  'ojs/ojflattenedtreedataproviderview',
  'ojs/ojkeyset'
], (
  ActionChain,
  Actions,
  ActionUtils,
  ArrayTreeDataProvider,
  FlattenedTreeDataProviderView,
  keySet
) => {
  'use strict';

  class updateLineStatus extends ActionChain {
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

     
      const updatedData = await $functions.updateAccountLineStatus(
        $variables.temptableADP.data,
        $variables.selectedDataTableADP.data,
        $variables.lineStausUpdate
      );
      $variables.temptableADP.data = updatedData;

      
      const treeData = $functions.convertArrayIntoTree(updatedData);

      const arrayTreeDP = new ArrayTreeDataProvider(treeData, {
        keyAttributes: 'id',
        keyAttributesScope: 'all'
      });

      
      let expandedKeyArray = Array.isArray($variables.expandedKeys)
        ? [...$variables.expandedKeys]
        : [];

     
      if ($variables.selectedDataTableADP?.data?.length > 0) {
        const selectedRow = $variables.selectedDataTableADP.data[0];

        if (selectedRow.fpn_location_id) {
          const locationKey = `location-${selectedRow.fpn_location_id}`;
          if (!expandedKeyArray.includes(locationKey)) {
            expandedKeyArray.push(locationKey);
          }
        }

        if (selectedRow.fpn_output_id) {
          const outputKey = `output-${selectedRow.fpn_output_id}`;
          if (!expandedKeyArray.includes(outputKey)) {
            expandedKeyArray.push(outputKey);
          }
        }
      }

      const expandedKeySet = new keySet.ExpandedKeySet(expandedKeyArray);

      const flattenedTreeDP = new FlattenedTreeDataProviderView(arrayTreeDP, {
        expanded: expandedKeySet
      });

      
      $variables.arrayTreeDP = arrayTreeDP;
      $variables.dataSource = flattenedTreeDP;
      $variables.expandedKeys = expandedKeyArray;

   
      await Actions.callComponentMethod(context, {
        selector: '#oj-dialog-status',
        method: 'close',
      });
    }
  }

  return updateLineStatus;
});
