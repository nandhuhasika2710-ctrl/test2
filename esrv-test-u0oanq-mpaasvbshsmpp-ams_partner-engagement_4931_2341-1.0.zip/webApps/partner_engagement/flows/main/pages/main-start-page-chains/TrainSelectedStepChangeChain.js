define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TrainSelectedStepChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.selectedStep 
     */
    async run(context, { selectedStep }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if ($variables.financialPlanStatus === 'Agreed') {
        $variables.selectedStatus = 3;
      }
    }
  }

  return TrainSelectedStepChangeChain;
});
