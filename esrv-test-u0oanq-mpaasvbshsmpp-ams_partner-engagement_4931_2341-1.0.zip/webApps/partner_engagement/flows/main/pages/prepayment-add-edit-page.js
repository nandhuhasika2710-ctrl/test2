define([
  "ojs/ojvalidator-regexp",
  "ojs/ojvalidator-required", "ojs/ojconverter-datetime"
], function (RegExpValidator, RequiredValidator, DateTimeConverter) {
  'use strict';

  class PageModule {

    maskExceptLast4(input) {
      if (typeof input !== 'string') {
        // convert to string just in case
        input = String(input);
      }
      const length = input.length;
      if (length <= 4) {
        // If 4 or fewer characters, maybe show as-is or all masked except nothing
        return input;
      }
      const last4 = input.slice(-4);
      const masked = 'x'.repeat(length - 4) + last4;
      return masked;
    }
    // formatKValue(context) {
    //   const value = context.value;

    //   if (value === null || value === 0) {
    //     return "";
    //   }

    //   if (value >= 1000) {
    //     return (value / 1000).toFixed(1).replace(/\.0$/, '') + "K";
    //   }

    //   return value;
    // }

    formatKValue(context) {
      const value = context.value;   // 

      if (value === null || value === undefined) return "";
      if (value === 0) return "0";  // 

      const absVal = Math.abs(value);

      if (absVal >= 1000) {
        const formatted = (absVal / 1000)
          .toFixed(1)
          .replace(/\.0$/, '') + "K";

        return value < 0 ? "-" + formatted : formatted;
      }

      return value.toString();
    }

    prepareChartData(apiResponse) {
      if (!apiResponse || !apiResponse.items || apiResponse.items.length === 0) {
        return {
          chartGroups: [],
          chartSeries: [],
          pieChartData: []
        };
      }

      const safeVal = (v) => {
        if (v === null || v === undefined) return null;
        return Number(v);   // ✅ keep 0
      };

      const data = apiResponse.items[0];
      const barData = data.bar_chart || [];
      const pieData = data.pie_chart || [];

      // Groups
      const chartGroups = barData.map(item => item.category);

      // Series
      const chartSeries = [
        {
          name: "Balance from Previous Year(s)",
          items: barData.map(item => safeVal(item.prev_balance))
        },
        {
          name: "Prepayment Issued (Current Year)",
          items: barData.map(item => safeVal(item.prepayment))
        },
        {
          name: "Expenses to Date",
          items: barData.map(item => safeVal(item.expenses))
        },
        {
          name: "Remaining Available Balance",
          items: barData.map(item => safeVal(item.remaining))
          // items: barData.map(item => Math.abs(safeVal(item.remaining)))
        }
      ];

      // Pie
      const pieChartData = pieData.map(item => ({
        id: item.id,
        label: item.label,
        value: Number(item.value) || 0
      }));

      return {
        chartGroups,
        chartSeries,
        pieChartData
      };
    }
    //decimal pricision//
    validatePrecision(valueStr, allowedPrecision) {
      if (valueStr == null || valueStr === '') {
        // decide whether empty is valid or not; here we treat empty as invalid
        return false;
      }

      const str = String(valueStr).trim();

      // optional: reject if not numeric
      if (isNaN(Number(str))) {
        return false;
      }

      const parts = str.split('.');
      if (parts.length === 1) {
        // no decimal point → zero decimals → OK
        return true;
      }
      if (parts.length > 2) {
        // more than one dot → invalid format
        return false;
      }

      const decimalPart = parts[1];
      return decimalPart.length <= allowedPrecision;
    }

    //get current date//
    getTodayString() {
      const d = new Date();
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, '0');
      const dd = String(d.getDate()).padStart(2, '0');
      return yyyy + '-' + mm + '-' + dd;
    }

    // Custom validator function returning an array of validators
    getMyFormattedDate(date) {
      let conv = new DateTimeConverter.IntlDateTimeConverter({
        pattern: "dd/MM/yyyy"
      });
      return conv.format(date);
    }
    getCommentValidator(param) {

      return [{
        validate: (value) => {
          if (value === null || String(value) === "") {
            if (param === 'Revised') {

              throw new Error("This is a mandatory field.");
            }

          }
          else {
            let pattern = /^[^<>]{3,250}$/;
            let validValue = pattern.test(value);

            if (!validValue) {
              throw new Error("Please enter plain text only (3–250 characters). Rich text or HTML is not allowed.");
            }
          }

        },
        getHint: () => "Please enter plain text only (3–250 characters). Rich text or HTML is not allowed."
      }];
    }

    buildOPAPostInstancesPayload(input) {
      console.log("input" + JSON.stringify(input));
      function formatDate(dateStr) {
        if (!dateStr) return "";
        const date = new Date(dateStr);
        if (isNaN(date)) return "";
        // Convert to YYYY-MM-DD
        return date.toISOString().split("T")[0];
      }
      const descriptionText = `Prepayment Invoice for ${input.document_number} - Comments: ${input.comments || ''}`;
      const payload = {
        params: {
          applicationName: "PartnerFinancialManagmentApplication",
          processName: "NegotiatePartnershipAgreementPrepaymentProcess"
        },
        dataObject: {
          inputPayload: {


            prepayment_request_number: input.prepayment_request_number || "",
            prepayment_request_amount: String(input.prepayment_request_amount || ""),
            prepayment_request_business_unit: input.prepayment_request_business_unit || "",
            prepayment_request_status: input.prepayment_request_status || "",
            comments: descriptionText,
            prepayment_partner_submission_date: formatDate(input.prepayment_partner_submission_date),
            prepayment_request_currency: input.prepayment_request_currency || "",
            supplier_number: input.supplier_number || "",
            supplier_site: input.supplier_site || "",
            contract_currency_code: input.contract_currency || "",
            masked_bank_account: input.masked_bank_account || "",
            in_capacity_of: input.in_capacity_of || "",
            fpn_number: input.fpn_number,
            ppa_number: input.ppa_number,
            cost_center: input.cost_center,
            prepayment_status_agreed_date: formatDate(new Date()),
            created_by: input.created_by || "",
            last_updated_by: input.last_updated_by || ""


          }
        }
      };

      console.log("OPA Payload:", JSON.stringify(payload, null, 2));
      return payload;
    }

    buildOPAUpdateTaskPayload(input) {
      function formatDate(dateStr) {
        if (!dateStr) return "";
        const date = new Date(dateStr);
        if (isNaN(date)) return "";
        // Convert to YYYY-MM-DD
        return date.toISOString().split("T")[0];
      }
      const descriptionText = `Updated Prepayment Invoice for ${input.prepayment_request_number} - Comments: ${input.comments || ''}`;
      return {
        inputPayload: {
          prepayment_request_business_unit: input.prepayment_request_business_unit || "",
          prepayment_request_status: input.prepayment_request_status || "",
          prepayment_request_number: input.prepayment_request_number || "",
          prepayment_request_amount: String(input.prepayment_request_amount || ""),
          prepayment_partner_submission_date: formatDate(input.prepayment_partner_submission_date),
          prepayment_status_agreed_date: formatDate(new Date()),
          supplier_number: input.supplier_number || "",
          supplier_site: input.supplier_site || "",
          prepayment_request_currency: input.prepayment_request_currency || "",
          comments: descriptionText,
          fpn_number: input.fpn_number,
          ppa_number: input.ppa_number,
          cost_center: input.cost_center,
          contract_currency_code: input.contract_currency || "",
          masked_bank_account: input.masked_bank_account || "",
          in_capacity_of: input.in_capacity_of || "",
          created_by: input.created_by || "",
          last_updated_by: input.last_updated_by || ""
        }
      };
    }

    buildUpdateFromPartnerPayload(instanceId, invoiceNumber) {
      return {
        message: [
          {
            pfr: {
              invoiceNumber: invoiceNumber || ""
            },
            correlate: invoiceNumber || ""
          }
        ],
        instanceId: instanceId, // passed from previous response
        appName: "PartnerFinancialManagmentApplication",
        processName: "NegotiatePartnershipAgreementPrepaymentProcess",
        operation: "updateFromPartner"
      };
    }



  }

  return PageModule;
});
