define(['vb/action/actionChain'], (ActionChain) => {
  'use strict';

  class RowExpanderExpandChain extends ActionChain {
    async run(context, { rowKey }) {
      const { $variables } = context;

      if (!rowKey) {
        console.warn('RowExpanderExpandChain: missing rowKey');
        return;
      }

      let expandedKeys = Array.isArray($variables.expandedKeys)
        ? [...$variables.expandedKeys]
        : [];

      // If the rowKey is not already expanded, add it
      if (!expandedKeys.includes(rowKey)) {
        expandedKeys.push(rowKey);
      }

      // Update the user-expanded keys (don't overwrite programmatic ones)
      $variables.expandedKeys = expandedKeys;

      console.log('Row expanded, updated expandedKeys:', expandedKeys);
    }
  }

  return RowExpanderExpandChain;
});