define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
  'ojs/ojarraytreedataprovider',
  'ojs/ojflattenedtreedataproviderview',
  'ojs/ojkeyset'
], (
  ActionChain,
  Actions,
  ActionUtils,
  ArrayTreeDataProvider,
  FlattenedTreeDataProviderView,
  keySet
) => {
  'use strict';

  class recalculatePfrActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const tempData = $variables.temptableADP?.data || [];
      const pfrData = tempData[0]?.pfr || {};
      const directShared = pfrData.direct_shared?.[0];
      const indirectSupport = pfrData.indirect_support?.[0];

      const fpn_ds_id = directShared?.fpn_ds_id || '';
      const fpn_isc_id = indirectSupport?.fpn_isc_id || '';

      const PFRpaylod = await $functions.createPayloadForPFR($variables.temptableADP.data, $variables.reporting_period, $variables.pfrgenralInfo, $variables.pfrComment || '', $application.variables.userInfoObj.UserID, $variables.directSharedTableADP?.data || [], $variables.indirectSharedADP?.data || [], $variables.sharedCostTypeId || '', $variables.riskRatingTypeId, 'DRAFT', $variables.indirectPartnerType, $variables.indirectPartnerPercentage, $application.variables.userRole, $variables.retainRunValidationVar, $variables.mode);

      const recalculatedPfr = await Actions.callRest(context, {
        endpoint: 'OICService/postPfrActionRecalculatePFR2',
        body: PFRpaylod,
      });
      if (recalculatedPfr.body.Status.toUpperCase() !== 'SUCCESS') {

        await Actions.fireNotificationEvent(context, {
          summary: 'PFR Recalculate Failed',
          message: recalculatedPfr.body.StatusMessage,
          type: 'error',
        });



      // const recalculatedPfr = await Actions.callRest(context, {
      //   endpoint: 'pfmGateway/postPfrRecalculate',
      //   body: PFRpaylod,
      // });

      // if (recalculatedPfr.status !== 200) {
      //   await Actions.fireNotificationEvent(context, {
      //     summary: 'Recalculate Failed',
      //     displayMode: 'transient',
      //     type: 'error',
      //   });

        return;
      }
      else {
        await Actions.fireNotificationEvent(context, {
          summary: 'Recalculate Successfull',
          type: 'confirmation',
        });
        const editPFRPayloadWithIds = await $functions.editPFRPayloadWithIds(recalculatedPfr.body.items);
        const testCode = await $functions.testCode(editPFRPayloadWithIds);
        // $variables.headerStatusValue = recalculatedPfr.body.items[0].pfr.pfr_status || '';

        $variables.headerStatusValue = recalculatedPfr.body.items[0].pfr.pfr_status || '';
        $variables.reporting_period.pfr_code = recalculatedPfr.body.items[0].pfr.reporting_period[0].pfr_code;
        $variables.reporting_period.pfr_type = recalculatedPfr.body.items[0].pfr.reporting_period[0].pfr_type;
        $variables.reporting_period.start_date = recalculatedPfr.body.items[0].pfr.reporting_period[0].reporting_period_start_date;
        $variables.reporting_period.end_date = recalculatedPfr.body.items[0].pfr.reporting_period[0].reporting_period_end_date;
        $variables.testVariable = testCode;
        const updateTreeData = () => {
          // FULL deep clone – breaks VB immutability
          const adpData = JSON.parse(JSON.stringify($variables.temptableADP.data));
          console.log("adpdata" + JSON.stringify(adpData));

          const recOutputs = recalculatedPfr.body.items[0].pfr.outputs || [];
          console.log("recOutputs" + JSON.stringify(recOutputs));
          if (!adpData.length) return adpData;

          adpData[0].pfr.outputs?.forEach(output => {
            const recOut = recOutputs.find(
              r => String(r.output_code) === String(output.outputCode)
            );
            if (!recOut) return;

            // OUTPUT
            output.expenses_ytd = recOut.output_expenses_ytd;
            output.remaining_balance = recOut.output_remaining_balance;
            output.reported_expenses = recOut.output_reported_expenses;
            output.ds_expenses = recOut.output_direct_shared_expenses;
            output.psc_expenses = recOut.output_indirect_support_expenses;
            output.negotiated_expenses = recOut.output_total_negotiated_expenses;

            output.locations?.forEach(loc => {
              const recLoc = recOut.locations?.find(
                r => String(r.location_code) === String(loc.locationCode)
              );
              if (!recLoc) return;

              // LOCATION
              loc.expenses_ytd = recLoc.location_expenses_ytd;
              loc.remaining_balance = recLoc.location_remaining_balance;
              loc.reported_expenses = recLoc.location_reported_expenses;

              loc.accounts?.forEach(acc => {
                const recAcc = recLoc.accounts?.find(
                  r => String(r.account) === String(acc.accountCode)
                );
                if (!recAcc) return;

                // ACCOUNT
                acc.expenses_ytd = recAcc.account_expenses_ytd;
                acc.remaining_balance = recAcc.account_remaining_balance;
                acc.reported_expenses = recAcc.account_reported_expenses;
              });
            });
          });

          return adpData;
        };
        const updatedTreeData = updateTreeData();

        $variables.temptableADP.data = updatedTreeData;
        console.log("temptableADP" + JSON.stringify($variables.temptableADP.data));
        const recDirectShared = $variables.testVariable[0].pfr.direct_shared || [];
        const uiDirectShared = $variables.directSharedTableADP.data || [];
        console.log("recDirectShared" + JSON.stringify(recDirectShared));
        console.log("uiDirectShared" + JSON.stringify(uiDirectShared));

        $variables.directSharedTableADP.data = uiDirectShared.map(ds => {
          const rec = recDirectShared.find(
            r => String(r.account_number) === String(ds.account_number)
          );

          if (!rec) return ds;

          return {
            ...ds,
            expenses_ytd: rec.expenses_ytd,
            remaining_balance: rec.remaining_balance,
            reported_expenses: rec.reported_expenses
          };
        });

        const recIndirect = $variables.testVariable[0].pfr.indirect_support || [];
        const uiIndirect = $variables.indirectSharedADP.data || [];
        console.log("recIndirect" + JSON.stringify(recIndirect));
        console.log("uiIndirect" + JSON.stringify(uiIndirect));

        $variables.indirectSharedADP.data = uiIndirect.map(is => {
          const rec = recIndirect.find(
            r => String(r.account_number) === String(is.account_number)
          );

          if (!rec) return is;

          return {
            ...is,
            expenses_ytd: rec.expenses_ytd,
            remaining_balance: rec.remaining_balance,
            reported_expenses: rec.reported_expenses,
            total_cost: rec.total_cost ?? is.total_cost
          };
        });
        $variables.pfrComment = $variables.testVariable[0].pfr.pfr_comments || '';
        $variables.fpnCode = $variables.testVariable[0].pfr.fpn_code || '';
        // $variables.sharedCostLovValue =
        const response4 = await Actions.callRest(context, {
          endpoint: 'pfmGateway/getPfrChangelog2',
          uriParams: {
            'p_pfr_code': recalculatedPfr.body.items[0].pfr.pfr_code,
          },
        });

        $variables.changeLogPfrExportADP.data = response4?.body?.items || [];
        const tree = await $functions.convertArrayIntoTree($variables.temptableADP.data);
        const arrayTreeDP = new ArrayTreeDataProvider(tree, {
          keyAttributes: 'id',
          keyAttributesScope: 'all'
        });

        // preserve previously expanded keys
        let expandedKeyArray = Array.isArray($variables.expandedKeys)
          ? [...$variables.expandedKeys]
          : [];

        // optionally auto-expand first updated row (if needed)
        if ($variables.selectedDataTableADP?.data?.length > 0) {
          const selectedRow = $variables.selectedDataTableADP.data[0];

          if (selectedRow.pfr_location_code) {
            const locationKey = `location-${selectedRow.pfr_location_code}`;
            if (!expandedKeyArray.includes(locationKey)) {
              expandedKeyArray.push(locationKey);
            }
          }

          if (selectedRow.pfr_output_code) {
            const outputKey = `output-${selectedRow.pfr_output_code}`;
            if (!expandedKeyArray.includes(outputKey)) {
              expandedKeyArray.push(outputKey);
            }
          }
        }

        const expandedKeySet = new keySet.ExpandedKeySet(expandedKeyArray);

        const flattenedTreeDP = new FlattenedTreeDataProviderView(arrayTreeDP, {
          expanded: expandedKeySet
        });

        $variables.arrayTreeDP = arrayTreeDP;
        $variables.dataSource = flattenedTreeDP;
        $variables.expandedKeys = expandedKeyArray;

        $variables.pfrgenralInfo.totalPFRExpenses = recalculatedPfr.body.items[0].pfr.total_pfr_expenses;
      }
    }
  }

  return recalculatePfrActionChain;
});
