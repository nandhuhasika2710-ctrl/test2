define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class pfrUpdatePageAccessControl extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context, { pfr_status }) {
      const { $variables, $application } = context;
      // console.log("tempTableADP" + JSON.stringify($variables.temptableADP.data));

      const role = $application.variables.userRole;
      const status = pfr_status.trim();
      if (role === 'VIEW_ONLY') {
        $variables.canEdit = false;
        $variables.canView = false;
        return;
      }
      if ($variables.viewMode === 'VIEW') {
        $variables.canEdit = false;
        $variables.canView = false;
        return;
      }
      // Set defaults
      $variables.canEdit = false;
      $variables.canView = false;

      switch (status) {
        case 'Draft':
          if (role === 'PARTNER_USER') {
            $variables.canEdit = true;
            $variables.canView = true;
          }
          else if (role === 'SENIOR_PROGRAMME_OFFICER' || role === 'JUNIOR_PROGRAMME_OFFICER') {
            $variables.canEdit = false;
            $variables.canView = true;
          }
          else if (role === 'SENIOR_PROJECT_CONTROL' || role === 'JUNIOR_PROJECT_CONTROL') {
            $variables.canEdit = false;
            $variables.canView = true;
          }
          else if (role === 'PFM_SUPERUSER') {
            $variables.canEdit = true;
            $variables.canView = true;
          }
          break;
        //     case 'Rescoped':
        //       if (loginType === 'Partner') {
        //         $variables.canView = true;
        //       } else if (role === 'PROGRAMME_OFFICER') {
        //         $variables.canEdit = true;
        //         $variables.canView = true;
        //       } else {
        //         $variables.canView = true;
        //       }
        //       break;

        case 'Proposed':
          if (role === 'PARTNER_USER') {
            $variables.canEdit = true;
            $variables.canView = true;
          } else if (role === 'SENIOR_PROGRAMME_OFFICER' || role === 'JUNIOR_PROGRAMME_OFFICER') {
            $variables.canView = true;
            $variables.canEdit = false;
          }
          else if (role === 'SENIOR_PROJECT_CONTROL' || role === 'JUNIOR_PROJECT_CONTROL') {
            $variables.canView = true;
            $variables.canEdit = true;
          }
          else if (role === 'PFM_SUPERUSER') {
            $variables.canEdit = true;
            $variables.canView = true;
          }
          break;

        case 'Revised':
          if (role === 'PARTNER_USER') {
            $variables.canEdit = true;
            $variables.canView = true;
          } else if (role === 'SENIOR_PROGRAMME_OFFICER' || role === 'JUNIOR_PROGRAMME_OFFICER') {
            $variables.canEdit = false;
            $variables.canView = true;
          } else if (role === 'SENIOR_PROJECT_CONTROL' || role === 'JUNIOR_PROJECT_CONTROL') {
            $variables.canView = true;
            $variables.canEdit = false;
          }
          else if (role === 'PFM_SUPERUSER') {
            $variables.canEdit = true;
            $variables.canView = true;
          }
          break;
          case 'Verified':
          if (role === 'PARTNER_USER') {
            $variables.canEdit = false;
            $variables.canView = true;
          } else if (role === 'SENIOR_PROGRAMME_OFFICER' || role === 'JUNIOR_PROGRAMME_OFFICER') {
            $variables.canEdit = false;
            $variables.canView = true;
          } else if (role === 'SENIOR_PROJECT_CONTROL' || role === 'JUNIOR_PROJECT_CONTROL') {
            $variables.canView = true;
            $variables.canEdit = true;
          }
          else if (role === 'PFM_SUPERUSER') {
            $variables.canEdit = true;
            $variables.canView = true;
          }
          break;
        // case 'Endorsed':
        //   if (role === 'PARTNER_USER') {
        //     $variables.canEdit = true;
        //     $variables.canView = true;
        //   } else if (role === 'SENIOR_PROGRAMME_OFFICER' || role === 'JUNIOR_PROGRAMME_OFFICER') {
        //     $variables.canEdit = true;
        //     $variables.canView = true;
        //   } else if (role === 'SENIOR_PROJECT_CONTROL' || role === 'JUNIOR_PROJECT_CONTROL') {
        //     $variables.canView = true;
        //     $variables.canEdit = false;
        //   }
        //   break;

        case 'Agreed':
          if (role === 'PARTNER_USER') {
            $variables.canEdit = false;
            $variables.canView = true;
          } else if (role === 'SENIOR_PROGRAMME_OFFICER' || role === 'JUNIOR_PROGRAMME_OFFICER') {
            $variables.canEdit = true;
            $variables.canView = true;
          } else if (role === 'SENIOR_PROJECT_CONTROL' || role === 'JUNIOR_PROJECT_CONTROL') {
            $variables.canView = true;
            $variables.canEdit = true;
          }
          else if (role === 'PFM_SUPERUSER') {
            $variables.canEdit = true;
            $variables.canView = true;
          }
          break;

        case 'Approved':
          if (role === 'PARTNER_USER') {
            $variables.canEdit = false;
            $variables.canView = true;
          } else if (role === 'SENIOR_PROGRAMME_OFFICER' || role === 'JUNIOR_PROGRAMME_OFFICER') {
            $variables.canEdit = false;
            $variables.canView = true;
          } else if (role === 'SENIOR_PROJECT_CONTROL' || role === 'JUNIOR_PROJECT_CONTROL') {
            $variables.canView = true;
            $variables.canEdit = false;
          }
          else if (role === 'PFM_SUPERUSER') {
            $variables.canEdit = true;
            $variables.canView = true;
          }
          break;


        //     case 'Under Review':
        //       if (loginType === 'Partner') {
        //         $variables.canEdit = true;
        //         $variables.canView = true;
        //       } else if (role === 'PROGRAMME_OFFICER') {
        //         $variables.canEdit = true;
        //         $variables.canView = true;
        //       } else if (role === 'PROJECT_CONTROL') {
        //         $variables.canView = true;
        //       }
        //       break;

        //     case 'Closed':
        //       if (role === 'REPRESENTATIVE') {
        //         $variables.canEdit = true;
        //       }
        //       $variables.canView = true;
        //       break;

        //     case 'Deleted':
        //       // No edit or view expected at FPN level — usually line-item only
        //       $variables.canEdit = false;
        //       $variables.canView = false;
        //       break;

        //     default:
        //       // If status is unknown, deny all access
        //       $variables.canEdit = false;
        //       $variables.canView = false;
        //       break;
        //   }
      }
      console.log('[AccessControl] Status:', status);
      console.log('[AccessControl] Role:', role);
      //   console.log('[AccessControl] LoginType:', loginType);
      console.log('[AccessControl] canEdit:', $variables.canEdit);
      console.log('[AccessControl] canView:', $variables.canView);
      //   console.log('[AccessControl] showPrepaymentBtn:', $variables.showPrepaymentBtn);
      //   console.log('[AccessControl] canCreditNote:', $variables.canCreditNote);    
    }
  }

  return pfrUpdatePageAccessControl;
});
