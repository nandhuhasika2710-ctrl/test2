define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class statusAssign extends ActionChain {
    async run(context) {
      const { $application, $variables, $flow } = context;

      const statusOrder = [
        { id: '0', label: $application.translations.appBundle.train_pfrlabel_draft, },
        { id: '1', label: $application.translations.appBundle.train_label_proposed },
        { id: '2', label: $application.translations.appBundle.train_pfrlabel_verifiedrevised },
        { id: '3', label: $application.translations.appBundle.train_pfrlabel_agreed },
        { id: '4', label: $application.translations.appBundle.train_pfrlabel_approved }

      ];

      const statusIndexMap = {
        'Draft': 0,
        'Proposed': 1,
        'Verified/Revised': 2,
        'Verified': 2,
        'Revised': 2,
        'Agreed': 3,
        'Approved': 4,
        'Rejected':0,
        'Canceled':0
      };

      const currentIndex = statusIndexMap[$variables.pfr_Status];

      if (currentIndex === undefined) return;

      $variables.steps = statusOrder.map((step, index) => {

        const isCompleted = index <= currentIndex;

        return {
          ...step,
          disabled: true,
          visited: isCompleted,
          messageType: isCompleted ? 'confirmation' : 'none'
        };
      });
    }
  }

  return statusAssign;
});
