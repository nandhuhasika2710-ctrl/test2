define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class onClickExportPFRData extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
      console.log("Tree Table ADP Data: ", JSON.stringify($variables.temptableADP.data));
      console.log("Direct Shared Data: ", JSON.stringify($variables.directSharedTableADP.data));
      // console.log("Indirect Shared Data: ", JSON.stringify($flow.variables.indirectSharedADP.data));
      const pfrData = $variables.temptableADP.data;  // Assuming this contains the main data
      const directSharedData = $variables.directSharedTableADP.data;

      const response = await Actions.callRest(context, {
        endpoint: 'pfmGateway/getAccounts',
        uriParams: {
          'p_account_type': 'DP',
        },
      });

      const response2 = await Actions.callRest(context, {
        endpoint: 'pfmGateway/getAccounts',
        uriParams: {
          'p_account_type': 'DS',
        },
      });


      await $functions.exportPFRDataToExcel(pfrData, response.body.items, response2.body.items, directSharedData, $variables.pfr_code);


    }
  }

  return onClickExportPFRData;
});
