define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class importIconClickChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const importExcelToADP = await $functions.importExcelToADP(event);

      await Actions.fireNotificationEvent(context, {
        summary: JSON.stringify(event),
      });
    }
  }

  return importIconClickChain;
});
