define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class directSharedTableBeforeRowEditChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.rowKey 
     * @param {number} params.rowIndex 
     * @param {any} params.rowData 
     */
    async run(context, { rowKey, rowIndex, rowData }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.directSharedCurrentRow = rowData;
      console.log("rowdata" + JSON.stringify(rowData));
      // if ($variables.directSharedCurrentRow.account_line_status === 'Draft') {
      //   $variables.directSharedCurrentRow.account_line_status = 'Proposed';
      // }
    
    
      $variables.retainRunValidationVar = 'N';
      $variables.validationColor = 'runvalidation_orange';
      $variables.pfrDraftSubmitStatus = 'DRAFT';

  }
}

  return directSharedTableBeforeRowEditChain;
});
