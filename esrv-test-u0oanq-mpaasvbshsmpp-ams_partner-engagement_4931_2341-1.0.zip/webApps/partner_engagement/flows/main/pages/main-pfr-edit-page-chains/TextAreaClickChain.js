define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TextAreaClickChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables } = context;
       if ($variables.clearCommentOnce && $variables.pfrComment) {
        
        $variables.clearCommentOnce = false;

        await Actions.resetVariables(context, {
          variables: [
    '$variables.pfrComment',
    '$variables.temptableADP.data.pfr.pfr_comments',
  ],
        });

       
      }
    }
  }

  return TextAreaClickChain;
});
