define([
  'vb/action/actionChain',
  'vb/action/actions',
  'ojs/ojarraytreedataprovider',
  'ojs/ojflattenedtreedataproviderview',
  'ojs/ojkeyset'
], (
  ActionChain,
  Actions,
  ArrayTreeDataProvider,
  FlattenedTreeDataProviderView,
  keySet
) => {
  'use strict';

  class TableBeforeRowEditEndChain extends ActionChain {
    async run(context, { rowKey, rowData }) {
      const { $variables, $functions } = context;

      // Ensure lineStatus is updated
      if ($variables.accountCurrent.lineStatus === 'Draft') {
        $variables.accountCurrent.lineStatus = 'Proposed';
      }

      // Preserve user-expanded keys
      const userExpandedKeys = Array.isArray($variables.expandedKeys)
        ? [...$variables.expandedKeys]
        : [];

      // Refresh the DataProvider
      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $variables.temptableADP
      });

      // Prepare updated row
      const updatedRow = { ...$variables.accountCurrent };
      if (rowData.outputCode) updatedRow.outputCode = rowData.outputCode;

      // Update the main data array
      const updatedData = await $functions.updateADP($variables.temptableADP.data, updatedRow);
      $variables.temptableADP.data = updatedData;

      // Convert to tree
      const treeData = $functions.convertArrayIntoTree(updatedData);
      const arrayTreeDP = new ArrayTreeDataProvider(treeData, { keyAttributes: 'id' });

      // Keys to programmatically expand for this edit
      const editExpandedKeys = [];
      if (rowData.id) editExpandedKeys.push(rowData.id);
      if (rowData.parentKey) editExpandedKeys.push(rowData.parentKey);
      if (rowData.loc) editExpandedKeys.push(`location-${rowData.loc}`);
      if (rowData.output) editExpandedKeys.push(`output-${rowData.outputCode}`);

      // Merge user keys and edit keys for this view only
      const mergedExpandedKeys = Array.from(new Set([...userExpandedKeys, ...editExpandedKeys]));

      // Flattened DataProvider view
      const flattenedTreeDP = new FlattenedTreeDataProviderView(arrayTreeDP, {
        expanded: new keySet.ExpandedKeySet(mergedExpandedKeys)
      });

      // Assign to context variables
      $variables.arrayTreeDP = arrayTreeDP;
      $variables.dataSource = flattenedTreeDP;

      // Preserve original user-expanded keys
      $variables.expandedKeys = userExpandedKeys;

      console.log('Merged expandedKeys for view:', mergedExpandedKeys);
      console.log('User-expanded keys preserved:', userExpandedKeys);
    }
  }

  return TableBeforeRowEditEndChain;
});