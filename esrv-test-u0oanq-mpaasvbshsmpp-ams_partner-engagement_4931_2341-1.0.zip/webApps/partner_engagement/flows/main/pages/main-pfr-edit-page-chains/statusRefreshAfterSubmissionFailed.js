define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class statusRefreshAfterSubmissionFailed extends ActionChain {

     /**
      * @param {Object} context
      * @param {Object} params
      * @param {string} params.pfr_status
      */
     async run(context, { pfr_status }) {
      const { $application, $variables, $flow } = context;

      const statusOrder = [
        { id: '0', label: $application.translations.appBundle.train_pfrlabel_draft, },
        { id: '1', label: $application.translations.appBundle.train_label_proposed },
        { id: '2', label: $application.translations.appBundle.train_pfrlabel_verifiedrevised },
        { id: '3', label: $application.translations.appBundle.train_pfrlabel_agreed },
        { id: '4', label: $application.translations.appBundle.train_pfrlabel_approved }

      ];

      const statusIndexMap = {
        'Draft': 0,
        'Proposed': 1,
        'Verified/Revised': 2,
        'Verified': 2,
        'Revised': 2,
        'Agreed': 3,
        'Approved': 4,
        'Rejected': 0,
        'Canceled': 0
      };


      const currentIndex = statusIndexMap[pfr_status];

      if (currentIndex === undefined) return;

      $variables.steps = statusOrder.map((step, index) => {

        let messageType = 'none';
        let visited = false;

        if (index < currentIndex) {
          messageType = 'confirmation'; // Previous → tick
          visited = true;
        }
        else if (index === currentIndex) {
          messageType = 'info'; // Current → circle
          visited = true;
        }

        return {
          ...step,
          disabled: true,
          visited,
          messageType
        };
      });

    }
  }

  return statusRefreshAfterSubmissionFailed;
});
