define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class MenuMenuActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.menuId 
     */
    async run(context, { menuId }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      if (menuId === 'status') {
        $variables.retainRunValidationVar = 'N';
        $variables.validationColor = 'runvalidation_orange';
        $variables.pfrDraftSubmitStatus = 'DRAFT';
        if ($variables.ojTabBar20581860342SelectedItem === 'oj-tab-bar-2058186034-2-tab-1') {
          const selectedOutpuandLocations = await $functions.selectedOutpuandLocations($variables.temptableADP.data, $variables.selectedADP);

          $variables.selectedDataTableADP.data = selectedOutpuandLocations;

          const ojDialogStatusOpen = await Actions.callComponentMethod(context, {
            selector: '#oj-dialog-status',
            method: 'open',
          });
        }
        else if ($variables.ojTabBar20581860342SelectedItem === 'oj-tab-bar-2058186034-2-tab-2') {
          const dsgetSelectedRows = await $functions.dsgetSelectedRows($variables.directSharedTableADP.data, $variables.DSselectedRows);

          $variables.dsStatusUpdateRowsADP.data = dsgetSelectedRows;

          const ojDialogDsStatusOpen = await Actions.callComponentMethod(context, {
            selector: '#oj-dialog-ds-status',
            method: 'open',
          });
        }
      }
    }
  }

  return MenuMenuActionChain;
});
