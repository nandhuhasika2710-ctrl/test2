define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class cancelButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $variables.temptableADP,
      });

      await Actions.fireDataProviderEvent(context, {
        target: $variables.directSharedTableADP,
        refresh: null,
      });

      await Actions.fireDataProviderEvent(context, {
        target: $variables.indirectSharedADP,
        refresh: null,
      });

      const toPfrSearch = await Actions.navigateToPage(context, {
        page: 'pfr-search',
      });
    }
  }

  return cancelButtonActionChain;
});
