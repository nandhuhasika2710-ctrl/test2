define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class menuUpdatePageValueListener extends ActionChain {

    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.tableColumnArray = event.value.map(v=>$page.variables.tableColumnArrayAll.find(i=>i.field === v));

    }
  }

  return menuUpdatePageValueListener;
});