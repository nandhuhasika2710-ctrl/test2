define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ISTableBeforeRowEditEndChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.cancelEdit 
     * @param {any} params.rowKey 
     * @param {number} params.rowIndex 
     * @param {any} params.rowData 
     */
    async run(context, { cancelEdit, rowKey, rowIndex, rowData }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const dsupdateAdpData = await $functions.dsupdateAdpData($variables.indirectSharedADP, $variables.indirectSharedCurrentRow);

      $variables.indirectSharedADP.data = dsupdateAdpData;
    }
  }

  return ISTableBeforeRowEditEndChain;
});
