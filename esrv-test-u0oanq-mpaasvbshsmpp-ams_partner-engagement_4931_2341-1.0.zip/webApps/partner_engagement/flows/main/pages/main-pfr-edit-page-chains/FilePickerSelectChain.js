define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
  'ojs/ojarraytreedataprovider',
  'ojs/ojflattenedtreedataproviderview',
  'ojs/ojkeyset'
], (
  ActionChain,
  Actions,
  ActionUtils,
  ArrayTreeDataProvider,
  FlattenedTreeDataProviderView,
  keySet
) => {
  'use strict';

  class FilePickerSelectChain extends ActionChain {
    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object[]} params.files
     */
    async run(context, { files }) {
      const { $variables, $functions } = context;

      await Actions.callComponentMethod(context, {
        selector: '#progressbar',
        method: 'open',
      });

      await Actions.resetVariables(context, {
        variables: [
    '$variables.excelImportFailedData',
    '$variables.excelImportMessages',
  ],
      });

      try {

        if (!files || files.length === 0) {
          await Actions.fireNotificationEvent(context, {
            summary: 'No files selected.',
            type: 'warning',
          });
          return;
        }

        const file = files[0];
        const fileName = file.name.toLowerCase();


        if (!(fileName.endsWith('.xlsx') || fileName.endsWith('.xls'))) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Invalid File',
            message: 'Upload only Excel file (.xlsx or .xls)',
            type: 'error',
          });
          return;
        }


        const [responseDP, responseDS] = await Promise.all([
          Actions.callRest(context, {
            endpoint: 'pfmGateway/getAccounts',
            uriParams: { p_account_type: 'DP' },
          }),
          Actions.callRest(context, {
            endpoint: 'pfmGateway/getAccounts',
            uriParams: { p_account_type: 'DS' },
          })
        ]);


        const { directProgramme, directShared,headers } =
          await $functions.parseExcelFile(file);

        const normalizedHeaders = (headers || []).map(h =>
          String(h || '').trim().toLowerCase()
        );

        // console.log("headerssssssssss" + headers);

        const isPFR =
          normalizedHeaders.includes('pfr') &&
          normalizedHeaders.includes('new expense');

        const isFPN =
          normalizedHeaders.includes('fpn') &&
          normalizedHeaders.includes('baseline');



        // =========================
        // 4. STRICT VALIDATION RULES
        // =========================

        const expectedType = "PFR";
         if (expectedType === 'PFR' && !isPFR) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Invalid File',
            message: 'Please upload a valid PFR Excel file.',
            type: 'error',
          });
          return;
        }


        const {
          validRows: validDP,
          invalidRows: invalidDP
        } = await $functions.validateRowsAgainstTree(
          directProgramme,
          $variables.temptableADP.data,
          responseDP.body.items
        );

        const {
          validRows: validDS,
          invalidRows: invalidDS
        } = await $functions.validateDirectSharedRows(directShared, $variables.directSharedTableADP.data, responseDS.body.items);

        console.log("Invalid DP:", invalidDP);
        console.log("Invalid DS:", invalidDS);

        const totalInvalid = invalidDP.length + invalidDS.length;
        const totalValid = validDP.length + validDS.length;


        if (totalInvalid > 0) {


          if (totalValid > 0) {
            const failedAll = [...invalidDP, ...invalidDS];

            $variables.excelImportFailedData = failedAll;
            $variables.excelImportMessages.primaryMessages = 'Excel Import Failed';
            $variables.excelImportMessages.secondaryMessages = totalValid === 0
              ? 'We could not process this file because all rows contain errors. Please fix the data and try again.'
              : `Some rows could not be processed (${totalInvalid} errors found). Please check the failed report for more details`;

            await Actions.callComponentMethod(context, {
              selector: '#uploaderrordialog',
              method: 'open',
            });
          }

          return;
        }
        const updatedTree = await $functions.importFlatRowsToTree(
          validDP,
          $variables.temptableADP.data
        );

        $variables.temptableADP.data = updatedTree;

        const arrayTreeDP = new ArrayTreeDataProvider(
          $functions.convertArrayIntoTree(updatedTree),
          { keyAttributes: 'id', keyAttributesScope: 'all' }
        );

        let expandedKeyArray = Array.isArray($variables.expandedKeys)
          ? [...$variables.expandedKeys]
          : [];

        if (validDP.length > 0) {
          const firstRow = validDP[0];

          if (firstRow.fpn_location_id) {
            expandedKeyArray.push(`location-${firstRow.fpn_location_id}`);
          }

          if (firstRow.fpn_output_id) {
            expandedKeyArray.push(`output-${firstRow.fpn_output_id}`);
          }
        }

        const expandedKeySet = new keySet.ExpandedKeySet(expandedKeyArray);

        const flattenedTreeDP = new FlattenedTreeDataProviderView(arrayTreeDP, {
          expanded: expandedKeySet
        });

        $variables.arrayTreeDP = arrayTreeDP;
        $variables.dataSource = flattenedTreeDP;
        $variables.expandedKeys = expandedKeyArray;


        const existingData = $variables.directSharedTableADP.data || [];

        const updatedData = existingData.map(item => {
          const match = validDS.find(
            row => Number(row.accountCode) === item.account_number
          );

          if (match) {
            return {
              ...item,
              reported_expenses: match.reported_expenses,
              account_line_comments: match.comments || null
            };
          }

          return { ...item };
        });

        $variables.directSharedTableADP.data = updatedData;


        await Actions.fireNotificationEvent(context, {
          summary: 'Excel import successfull',
          message: `Your file was processed successfully. ${validDP.length + validDS.length} records were updated`,
          type: 'success',
        });

      } catch (error) {
        console.error(error);

        await Actions.fireNotificationEvent(context, {
          summary: 'Unexpected Error',
          message: 'We encountered an unexpected issue while processing your file. Please try again or contact support if the issue continues.',
          type: 'error',
        });

      } finally {

        await Actions.callComponentMethod(context, {
          selector: '#progressbar',
          method: 'close',
        });
      }
    }
  }

  return FilePickerSelectChain;
});