define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
  'ojs/ojarraytreedataprovider',
  'ojs/ojflattenedtreedataproviderview',
], (
  ActionChain,
  Actions,
  ActionUtils,
  ArrayTreeDataProvider,
  FlattenedTreeDataProviderView
) => {
  'use strict';

  class vbEnterListener extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
      const role = $application.variables.userRole;




      const results = await Promise.all([

        async () => {

          if ($variables.mode === 'CREATE') {
            try {
              await Actions.callComponentMethod(context, {
                selector: '#progressbar',
                method: 'open',
              });

              /* ------------------- STEP 0 : POST PFR VERSION ------------------- */
              const response5 = await Actions.callRest(context, {
                endpoint: 'pfmGateway/postPfrVersion',
                uriParams: { fpn_code: $variables.fpnCode },
              });

              let incrementPfrCode = false;
              let approvedPfrCode = null;

              try {
                const respBody = response5?.body || {};
                const message = respBody?.responsemessage || '';

                if (respBody.status_code === '201' && (message.includes('Status: Approved') || message.includes('Status: Canceled'))
                ) {
                  const balanceMatch = message.match(/Remaining Balance:\s*(\d+)/);
                  const remainingBalance = balanceMatch ? parseFloat(balanceMatch[1]) : 0;

                  if (remainingBalance > 0) {
                    incrementPfrCode = true;
                    const pfrMatch = message.match(/PFR Code:\s*([\w\-]+)/);
                    approvedPfrCode = pfrMatch ? pfrMatch[1] : null;
                  } else {
                    await Actions.fireNotificationEvent(context, {
                      summary: 'Unable to Create New  PFR',
                      message: 'Cannot create new PFR because remaining balance is 0.',
                    });

                    const progressbarClose3 = await Actions.callComponentMethod(context, {
                      selector: '#progressbar',
                      method: 'close',
                    });

                    await Actions.navigateBack(context, {
                    });
                    return;
                  }

                }
              } catch (err) {

                console.error('Error parsing response5:', err);
              }

              /* ------------------- STEP 1 : RETRIEVE FPN ------------------- */
              const response2 = await Actions.callRest(context, {
                endpoint: 'OICService/getRetrieve',
                uriParams: { fpnCode: $variables.fpnCode },
              });

              if (!response2.ok) {
                await Actions.fireNotificationEvent(context, {
                  summary: 'Failed to Retrieve Data from FPN',
                  message: response2.statusText,
                });
                await Actions.callComponentMethod(context, {
                  selector: '#progressbar',
                  method: 'close',
                });
                return;
              }

              const items = response2.body.items || [];
              const fpn = items[0]?.fpn || {};

              $variables.sharedCostLovValue = fpn.indirect_support?.[0]?.partner_type || '';
              $variables.riskRatingLovValue = fpn.essential_controls || '';

              const createPFR =
                await $functions.createPFRPayloadWithIds(items, incrementPfrCode, approvedPfrCode);

              const testCode = await $functions.testCode(createPFR);

              /* ------------------- STEP 2 : RESET + INIT ------------------- */
              await Actions.resetVariables(context, {
                variables: ['$variables.reporting_period'],
              });

              $variables.testVariable = testCode;
              $variables.temptableADP.data = testCode;

              $variables.tempdirectSharedArray = testCode[0]?.pfr?.direct_shared || [];
              $variables.directSharedTableADP.data = $variables.tempdirectSharedArray;

              $variables.indirectSharedArray = testCode[0]?.pfr?.indirect_support || [];
              $variables.indirectSharedADP.data = $variables.indirectSharedArray;

              Object.assign($variables.pfrgenralInfo, {
                operation: fpn.operation_name,
                budgetYear: fpn.budget_year,
                contractCurrency: fpn.contract_currency_code,
                toataloriginalbudget: fpn.total_original_budget,
                partnerName: fpn.partner_name,
                partnerERPSite: fpn.partner_site_code,
                contractNumber: fpn.contract_number,
                totalDirectProgramme: fpn.total_direct_programme_cost,
                totalNegotiatedBudget: fpn.total_negotiated_budget,
                totalDirectShared: fpn.total_direct_shared_cost,
                totalIndirectSupportCost: fpn.total_indirect_support_cost,
                totalPFRExpenses: fpn.total_pfr_expenses,
              });

              $variables.reporting_period.pfr_code = testCode[0]?.pfr?.pfr_code || '';

              await new Promise(r => setTimeout(r, 2000));

              /* ------------------- STEP 3 : RECALCULATE ------------------- */
              const PFRpayload = await $functions.createPayloadForPFR($variables.temptableADP.data, $variables.reporting_period, $variables.pfrgenralInfo, $variables.pfrComment || '', $application.variables.userInfoObj.UserID, $variables.directSharedTableADP?.data || [], $variables.indirectSharedADP?.data || [], $variables.sharedCostLovValue || '', $variables.riskRatingTypeId, 'DRAFT', $variables.indirectPartnerType, $variables.indirectPartnerPercentage, $application.variables.userRole, 'N', $variables.mode);

              // const response = await Actions.callRest(context, {
              //   endpoint: 'pfmGateway/postPfrRecalculate',
              //   body: PFRpayload,
              // });
              const response = await Actions.callRest(context, {
                endpoint: 'OICService/postPfrActionRecalculatePFR2',
                body: PFRpayload,
              });
              if (response.body.Status.toUpperCase() !== 'SUCCESS') {

                await Actions.fireNotificationEvent(context, {
                  summary: 'PFR Recalculate Failed',
                  message: response.body.StatusMessage,
                  type: 'error',
                });
                const progressbarClose2 = await Actions.callComponentMethod(context, {
                  selector: '#progressbar',
                  method: 'close',
                });

                return;
              }
                $variables.validationColor = 'runvalidation_orange';
                $variables.pfrDraftSubmitStatus = 'DRAFT';
                // const editPFRPayloadWithIds = await $functions.editPFRPayloadWithIds(response.body.items);
                const updateExpenses = await $functions.testCode(response.body.items);
                const updatedData = JSON.parse(JSON.stringify($variables.temptableADP.data));
                const updatePfrData =
                  await $functions.updatePfrData(updatedData, updateExpenses);

                $variables.temptableADP.data = updatePfrData;

                const rp = response.body.items[0].pfr.reporting_period[0];
                Object.assign($variables.reporting_period, {
                  pfr_code: rp.pfr_code,
                  pfr_type: rp.pfr_type || '',
                  start_date: rp.reporting_period_start_date || '',
                  end_date: rp.reporting_period_end_date || '',
                });

                $variables.tempdirectSharedArray = updatePfrData[0]?.pfr?.direct_shared || [];
                $variables.directSharedTableADP.data = $variables.tempdirectSharedArray;

                $variables.indirectSharedArray = updatePfrData[0]?.pfr?.indirect_support || [];
                $variables.indirectSharedADP.data = $variables.indirectSharedArray;

                $variables.pfrComment = updatePfrData[0]?.pfr?.pfr_comments || '';

                const updatedTree =
                  await $functions.convertArrayIntoTree(updatePfrData);
             $variables.dataSource = null;
              const arrayTreeDP = new ArrayTreeDataProvider(updatedTree, { keyAttributes: 'id' });
              $variables.arrayTreeDP = arrayTreeDP;  // save if needed
              $variables.dataSource = new FlattenedTreeDataProviderView($variables.arrayTreeDP);
console.log("testttt"+JSON.stringify($variables.dataSource, null, 2));
                const pfr = response.body.items[0].pfr;

                $variables.sharedCostLovValue =
                  pfr.indirect_support?.[0]?.partner_type || '';

                // $variables.riskRatingLovValue = pfr.budget_flexibility || '';

                Object.assign($variables.pfrgenralInfo, {
                //   operation: pfr.operation_name,
                //   budgetYear: pfr.budget_year,
                //   contractCurrency: pfr.contract_currency_code,
                //   toataloriginalbudget: pfr.total_original_budget,
                //   partnerName: pfr.partner_name,
                //   partnerERPSite: fpn.partner_site_code,
                //   contractNumber: pfr.contract_number,
                //   totalDirectProgramme: pfr.total_direct_programme_cost,
                //   totalNegotiatedBudget: pfr.total_negotiated_budget,
                //   totalDirectShared: pfr.total_direct_shared_cost,
                //   totalIndirectSupportCost: pfr.total_indirect_support_cost,
                  totalPFRExpenses: pfr.total_pfr_expenses,
                });

                await Actions.callChain(context, {
                  chain: 'pfrUpdatePageAccessControl',
                  params: {
                    'pfr_status': 'Draft',
                  },
                });

                await Actions.callComponentMethod(context, {
                  selector: '#progressbar',
                  method: 'close',
                });
              } catch (error) {

                await Actions.fireNotificationEvent(context, {
                  summary: 'PFR Creation Failed',
                  message: 'Something went wrong,Please try later',
                });

                const progressbarClose = await Actions.callComponentMethod(context, {
                  selector: '#progressbar',
                  method: 'close',
                });

              }
            }

          else if ($variables.mode === 'EDIT') {

            try {
              await Actions.callComponentMethod(context, {
                selector: '#progressbar',
                method: 'open',
              });
              // const response = await Actions.callRest(context, {
              //   endpoint: 'pfmGateway/getPfrHeaderdetails',
              //   uriParams: {
              //     'p_pfr_code': $variables.pfr_code,
              //   },
              // });
              const response = await Actions.callRest(context, {
                endpoint: 'OICService/getPFR',
                uriParams: {
                  'p_pfr_code': $variables.pfr_code,
                },
              });

              await Actions.callChain(context, {
                chain: 'pfrUpdatePageAccessControl',
                params: {
                  'pfr_status': response.body.items[0].pfr.pfr_status,
                },
              });

              const editPFRPayloadWithIds = await $functions.editPFRPayloadWithIds(response.body.items);
              const testCode = await $functions.testCode(editPFRPayloadWithIds);
              // console.log("testCode" + JSON.stringify(testCode));
              $variables.reporting_period.pfr_code = response.body.items[0].pfr.reporting_period[0].pfr_code;
              $variables.reporting_period.pfr_type = response.body.items[0].pfr.reporting_period[0].pfr_type;
              $variables.reporting_period.reporting_period_start_date = response.body.items[0].pfr.reporting_period[0].reporting_period_start_date;
              $variables.reporting_period.reporting_period_end_date = response.body.items[0].pfr.reporting_period[0].reporting_period_end_date;
              $variables.testVariable = testCode;
              $variables.temptableADP.data = testCode;
              $variables.headerStatusValue = $variables.testVariable[0].pfr.pfr_status || '';
              $variables.tempdirectSharedArray = $variables.testVariable[0].pfr.direct_shared || [];
              $variables.directSharedTableADP.data = $variables.tempdirectSharedArray;
              $variables.indirectSharedArray = $variables.testVariable[0].pfr.indirect_support || [];
              $variables.indirectSharedADP.data = $variables.indirectSharedArray;
              $variables.pfrComment = response.body.items[0].pfr.pfr_comments || '';
              $variables.fpnCode = response.body.items[0].pfr.fpn_code;
              $variables.sharedCostLovValue = response?.body?.items?.[0]?.pfr?.indirect_support?.[0]?.partner_type || '';
              let draftSubmissionStatus = response.body.items[0].pfr.draft_submission_status;
              let budgetFlexibility = response.body.items[0].pfr.budget_flexibility;

              // if (draftSubmissionStatus) {

              //   if (draftSubmissionStatus.startsWith("DRAFT-") || draftSubmissionStatus.startsWith("SUBMIT-")) {
              //     let percentageValue = draftSubmissionStatus.split('-')[1];
              //     budgetFlexibility = percentageValue + '%';
              //   }
              // }
              const getValidationState3 = await Actions.callRest(context, {
                endpoint: 'pfmGateway/getUpdateValidationstate',
                uriParams: {
                  'doc_type': 'PFR',
                  'pfr_code': $variables.pfr_code,
                },
              });
              const validationItem = getValidationState3?.body?.items && getValidationState3.body.items.length > 0 ? getValidationState3.body.items[0] : null;
              if (validationItem) {
                $variables.retainRunValidationVar =
                  validationItem.validation_state || 'N';

                $variables.pfrDraftSubmitStatus =
                  validationItem.draft_submission_status || 'DRAFT';
              }
              if ($variables.retainRunValidationVar === 'N') {

                $variables.validationColor = 'runvalidation_orange';

              }
              else if ($variables.retainRunValidationVar === 'Y') {

                $variables.validationColor = 'runvalidation_green';

              }
              if ($variables.pfrDraftSubmitStatus === 'SUBMIT') {
                $variables.disableSubmitButton = true;
              } else {
                $variables.disableSubmitButton = false;
              }


              if (draftSubmissionStatus.startsWith("DRAFT")) {
                await Actions.callChain(context, {
                  chain: 'draftStatusAssign',
                });

              }
              else
                if (draftSubmissionStatus.startsWith("SUBMIT")) {
                  await Actions.callChain(context, {
                    chain: 'statusAssign',
                  });
                }
              // $variables.riskRatingLovValue = $variables.testVariable[0].pfr.budget_flexibility === '0%' ? '' : $variables.testVariable[0].pfr.budget_flexibility || '';
              $variables.riskRatingLovValue = budgetFlexibility;
              const response4 = await Actions.callRest(context, {
                endpoint: 'pfmGateway/getPfrChangelog2',
                uriParams: {
                  'p_pfr_code': $variables.pfr_code,
                },
              });
              $variables.changeLogPfrExportADP.data = response4?.body?.items || [];
              const response3 = await Actions.callRest(context, {
                endpoint: 'OICService/getRetrieve',
                uriParams: {
                  fpnCode: $variables.fpnCode,
                },
              });
              // $variables.fpnCode = response3.body.items[0].fpn.fpn_code;
              const tree = await $functions.convertArrayIntoTree($variables.temptableADP.data);
              const arrayTreeDP = new ArrayTreeDataProvider(tree, { keyAttributes: 'id' });
              $variables.arrayTreeDP = arrayTreeDP;  // save if needed
              $variables.dataSource = new FlattenedTreeDataProviderView($variables.arrayTreeDP);
              $variables.pfrgenralInfo.operation = response.body.items[0].pfr.operation_name;
              $variables.pfrgenralInfo.budgetYear = response.body.items[0].pfr.budget_year;
              $variables.pfrgenralInfo.contractCurrency = response.body.items[0].pfr.contract_currency_code;
              $variables.pfrgenralInfo.toataloriginalbudget = response.body.items[0].pfr.total_original_budget;
              $variables.pfrgenralInfo.partnerName = response.body.items[0].pfr.partner_name;
              $variables.pfrgenralInfo.partnerERPSite = response.body.items[0].pfr.partner_site_code;
              $variables.pfrgenralInfo.contractNumber = response.body.items[0].pfr.contract_number;
              $variables.pfrgenralInfo.totalDirectProgramme = response.body.items[0].pfr.total_direct_programme_cost;
              $variables.pfrgenralInfo.totalNegotiatedBudget = response.body.items[0].pfr.total_negotiated_budget;
              $variables.pfrgenralInfo.totalDirectShared = response.body.items[0].pfr.total_direct_shared_cost;
              $variables.pfrgenralInfo.totalIndirectSupportCost = response.body.items[0].pfr.total_indirect_support_cost;
              $variables.pfrgenralInfo.totalPFRExpenses = response.body.items[0].pfr.total_pfr_expenses;
              $variables.pfrgenralInfo.costCenter = response3.body.items[0].fpn.cost_center;
              $variables.pfrgenralInfo.costCenterName = response3.body.items[0].fpn.cost_center_name;
              $variables.pfrgenralInfo.poNumber = response3.body.items[0].fpn.po_number;
              $variables.pfrgenralInfo.operationCode = response3.body.items[0].fpn.operation_code;
              $variables.pfrgenralInfo.partnerNumber = response3.body.items[0].fpn.partner_number;
              // $variables.ojTabBar20581860342SelectedItem='oj-tab-bar-2058186034-2-tab-1';
              await Actions.callComponentMethod(context, {
                selector: '#progressbar',
                method: 'close',
              });
            } catch (error) {

              await Actions.fireNotificationEvent(context, {
                summary: 'PFR Loading Failed',
                message: 'Something went wrong,Please try later',
              });

              const progressbarClose = await Actions.callComponentMethod(context, {
                selector: '#progressbar',
                method: 'close',
              });

            }





          }
        },
      ].map(sequence => sequence()));
    }
  }
  return vbEnterListener;
});
