define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TableBeforeRowEditChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.rowKey 
     * @param {number} params.rowIndex 
     * @param {any} params.rowData 
     */
    async run(context, { rowKey, rowIndex, rowData }) {
      const { $page, $flow, $application, $constants, $variables, $current } = context;

      $variables.accountCurrent = rowData;
      // $variables.accountCurrent.lineStatus = 'Proposed';
      $variables.retainRunValidationVar = 'N';
      $variables.validationColor = 'runvalidation_orange';
      $variables.pfrDraftSubmitStatus = 'DRAFT';

      
      if ($variables.accountCurrent.lineStatus === 'Draft') {
        $variables.accountCurrent.lineStatus = 'Proposed';
      }

    }
  }

  return TableBeforeRowEditChain;
});
