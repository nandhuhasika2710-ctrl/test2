define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
  'ojs/ojarraytreedataprovider',
  'ojs/ojflattenedtreedataproviderview',
], (
  ActionChain,
  Actions,
  ActionUtils,
  ArrayTreeDataProvider,
  FlattenedTreeDataProviderView
) => {
  'use strict';

  class onClickSubmitPFR extends ActionChain {
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      let taskId = $variables.taskId;
      let instanceId;

      await Actions.callComponentMethod(context, { selector: '#progressbar', method: 'open' });
      const addUserOpaPayload = await $application.functions.addUserOpaPayload($application.variables.userInfoObj.FirstName, $application.variables.userInfoObj.LastName, $application.variables.userInfoObj.FirstName + " " + $application.variables.userInfoObj.LastName, $application.variables.userInfoObj.UserID, $application.variables.opaUserGroup);

      const response6 = await Actions.callRest(context, {
        endpoint: 'opaOic/postPlatformUserprovisioning',
        body: addUserOpaPayload,
      });

      if (!response6.ok) {

        await Actions.fireNotificationEvent(context, {
          summary: 'User Provisioning Service Failed',
          type: 'error',
        });

        await Actions.callComponentMethod(context, {
          selector: '#progressbar',
          method: 'close',
        });

        return;
      }

      const opaAccessTokenPayload = await $application.functions.opaAccessTokenPayload($application.variables.userInfoObj.UserID);

      const response7 = await Actions.callRest(context, {
        endpoint: 'opaOic/postPlatformUserassertionmgmt',
        body: opaAccessTokenPayload,
      });

      if (!response7.ok) {

        const errorMsg =
          response7.body?.error_description ||
          response7.body?.error ||
          response7.statusText;

        await Actions.fireNotificationEvent(context, {
          summary: 'OPA Token Generation Failed',
          message: errorMsg,
          type: 'error',
        });

        await Actions.callComponentMethod(context, {
          selector: '#progressbar',
          method: 'close',
        });

        return;
      }

      const formatAsBearerToken = await $application.functions.formatAsBearerToken(response7.body.access_token);

      $variables.opaAccessToken = formatAsBearerToken;

      try {
        // VALIDATION
        const tempData = $variables.temptableADP?.data || [];
        const pfrData = tempData[0]?.pfr || {};
        const validateFpnData = await $functions.validateFpnData(
          pfrData,
          $variables.pfrComment,
          $variables.reporting_period.pfr_type,
          $variables.directSharedTableADP.data,
          $variables.indirectSharedADP.data
        );

        if (!validateFpnData.valid) {
          await Actions.fireNotificationEvent(context, {
            summary: 'PFR SubmissionFailed',
            message: validateFpnData.message,
            type: 'error',
            displayMode: 'transient',
          });
          return;
        }

        if ($variables.reportingperiodValidation !== 'valid') {
          await Actions.fireNotificationEvent(context, {
            summary: 'PFR Submission Failed',
            message: 'Please check mandatory fields in Reporting period section before saving.',
            type: 'error',
            displayMode: 'transient',
          });
          return;
        }
        // CREATE PFR PAYLOAD
        const PFRpaylod = await $functions.createPayloadForPFR($variables.temptableADP.data, $variables.reporting_period, $variables.pfrgenralInfo, $variables.pfrComment, $application.variables.userInfoObj.UserID, $variables.directSharedTableADP.data, $variables.indirectSharedADP.data, $variables.sharedCostTypeId || '', $variables.riskRatingTypeId, 'SUBMIT', $variables.indirectPartnerType, $variables.indirectPartnerPercentage, $application.variables.userRole, $variables.retainRunValidationVar, $variables.mode);

        // -----------------------
        // RECALCULATE PFR
        const recalcResp = await Actions.callRest(context, {
          endpoint: 'OICService/postPfrActionRecalculatePFR2',
          body: PFRpaylod,
        });

        if (recalcResp.body.Status.toUpperCase() !== 'SUCCESS') {
          await Actions.fireNotificationEvent(context, {
            summary: 'PFR Submission Failed',
            message: recalcResp.body.StatusMessage,
            type: 'error',
            displayMode: 'transient',
          });
          return;
        }

        // const recalculateResponse = await Actions.callRest(context, {
        //   endpoint: 'pfmGateway/postPfrRecalculate',
        //   body: PFRpaylod,
        // });

        // if (recalculateResponse.status !== 200) {
        //   await Actions.fireNotificationEvent(context, {
        //     summary: 'Recalculate Failed',
        //     displayMode: 'transient',
        //     type: 'error',
        //   });

        //   return;
        // }

        // -----------------------
        // CREATE PFR
        const responseCreate = await Actions.callRest(context, {
          endpoint: 'OICService/postPfrActionCreatePFR',
          body: recalcResp.body,
        });

        // const responseCreate = await Actions.callRest(context, {
        //   endpoint: 'pfmGateway/postPFR',
        //   body: recalculateResponse.body,
        // });

        if (responseCreate.body.Status !== '201') {
          // const statusCode = String(responseCreate?.body?.status_code || responseCreate?.status);
          // if (statusCode !== '201') {
          await Actions.fireNotificationEvent(context, {
            summary: 'PFR Submission Failed',
            message: responseCreate.body.StatusMessage,
            type: 'error',
            displayMode: 'transient',
          });
          await Actions.callRest(context, {
            endpoint: 'pfmGateway/putUpdateValidationstate',
            uriParams: {
              doc_type: 'PFR',
              draft_submission_status: 'DRAFT',
              pfr_code: $variables.reporting_period.pfr_code,
            },
          });
          await Actions.callChain(context, {
            chain: 'statusRefreshAfterSubmissionFailed',
            params: {
              'pfr_status': $variables.temptableADP.data.pfr.pfr_status,
            },
          });

          return;
        }

        // -----------------------
        // RETRIEVE PFR
        const pfr_code = responseCreate.body.StatusMessage;
        const responseRetrieve = await Actions.callRest(context, {
          endpoint: 'OICService/getPFR',
          uriParams: { p_pfr_code: pfr_code },
        });


        // const responseRetrieve = await Actions.callRest(context, {
        //   endpoint: 'pfmGateway/getPfrHeaderdetails',
        //   uriParams: {
        //     'p_pfr_code': pfr_code,
        //   },
        // });

        if (!responseRetrieve.ok) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Please Refresh Again',
            message: `Failed to Retrieve PFR Data: ${responseRetrieve.statusText}`,
            type: 'error',
            displayMode: 'transient',
          });
          return;
        }

        const items = responseRetrieve.body.items[0];
        const pfr = items?.pfr || {};
        const reporting = pfr.reporting_period?.[0] || {};
        $variables.pfr_Status = pfr.pfr_status;
        // UPDATE VARIABLES
        const editPFRPayloadWithIds = await $functions.editPFRPayloadWithIds(responseRetrieve.body.items);
        const testCode = await $functions.testCode(editPFRPayloadWithIds);
        $variables.temptableADP.data = testCode;
        $variables.testVariable = testCode;
        $variables.reporting_period.pfr_code = reporting.pfr_code;
        $variables.reporting_period.pfr_type = reporting.pfr_type;
        $variables.reporting_period.reporting_period_start_date = reporting.reporting_period_start_date;
        $variables.reporting_period.reporting_period_end_date = reporting.reporting_period_end_date;
        // $variables.headerStatusValue = $variables.testVariable[0].pfr.pfr_status || '';
        $variables.headerStatusValue = $variables.testVariable[0].pfr.pfr_status || '';
        $variables.tempdirectSharedArray = testCode[0].pfr.direct_shared || [];
        $variables.directSharedTableADP.data = $variables.tempdirectSharedArray;
        $variables.indirectSharedArray = testCode[0].pfr.indirect_support || [];
        $variables.indirectSharedADP.data = $variables.indirectSharedArray;
        $variables.pfrComment = testCode[0].pfr.pfr_comments || '';
        $variables.fpnCode = $variables.testVariable[0].pfr.fpn_code || '';
        $variables.sharedCostLovValue = pfr.indirect_support?.[0]?.shared_cost || '';
        // -----------------------
        // DRAFT SUBMISSION STATUS → BUDGET FLEXIBILITY
        // -----------------------
        let draftSubmissionStatus = pfr.draft_submission_status;
        let budgetFlexibility = pfr.budget_flexibility;

        // if (draftSubmissionStatus) {
        //   if (draftSubmissionStatus.startsWith("DRAFT-") || draftSubmissionStatus.startsWith("SUBMIT-")) {
        //     let percentageValue = draftSubmissionStatus.split('-')[1];
        //     budgetFlexibility = percentageValue + '%';
        //   }
        // }

        const tree = await $functions.convertArrayIntoTree($variables.temptableADP.data);
        $variables.arrayTreeDP = new ArrayTreeDataProvider(tree, { keyAttributes: 'id' });
        $variables.dataSource = new FlattenedTreeDataProviderView($variables.arrayTreeDP);
        $variables.pfrgenralInfo.operation = pfr.operation_name;
        $variables.pfrgenralInfo.budgetYear = pfr.budget_year;
        $variables.pfrgenralInfo.contractCurrency = pfr.contract_currency_code;
        $variables.pfrgenralInfo.toataloriginalbudget = pfr.total_original_budget;
        $variables.pfrgenralInfo.partnerName = pfr.partner_name;
        $variables.pfrgenralInfo.partnerERPSite = pfr.partner_site_code;
        $variables.pfrgenralInfo.contractNumber = pfr.contract_number;
        $variables.pfrgenralInfo.totalDirectProgramme = pfr.total_direct_programme_cost;
        $variables.pfrgenralInfo.totalNegotiatedBudget = pfr.total_negotiated_budget;
        $variables.pfrgenralInfo.totalDirectShared = pfr.total_direct_shared_cost;
        $variables.pfrgenralInfo.totalIndirectSupportCost = pfr.total_indirect_support_cost;
        $variables.pfrgenralInfo.totalPFRExpenses = pfr.total_pfr_expenses;
        $variables.pfrgenralInfo.costCenter = pfr.cost_center;
        $variables.pfrgenralInfo.costCenterName = pfr.cost_center_name;
        $variables.pfrgenralInfo.poNumber = pfr.po_number;
        $variables.pfrgenralInfo.operationCode = pfr.operation_code;
        $variables.pfrgenralInfo.partnerNumber = pfr.partner_number;



        // -----------------------
        // CHANGELOG & FPN RETRIEVE
        const responseChangeLog = await Actions.callRest(context, {
          endpoint: 'pfmGateway/getPfrChangelog2',
          uriParams: {
            'p_pfr_code': pfr_code,
          },
        });
        $variables.changeLogPfrExportADP.data = responseChangeLog.body.items || [];
        // INLINE OPA HANDLING
        if (!taskId) {
          const instanceResponse = await Actions.callRest(context, {
            endpoint: 'OPA/getInstances',
            uriParams: { businessKeyLike: $variables.reporting_period.pfr_code },
            headers: { Authorization: $variables.opaAccessToken },
          });

          const activeInstance = instanceResponse.body?.items?.find(i => i.state === 'ACTIVE');
          instanceId = activeInstance?.rootInstanceId;

          if (instanceId) {
            const activitiesResp = await Actions.callRest(context, {
              endpoint: 'OPA/getInstancesInstanceIdActivities',
              uriParams: { instanceId },
              headers: { Authorization: $variables.opaAccessToken },
            });

            const activityInstanceId = activitiesResp.body?.activities?.[0]?.activityInstanceId;

            if (!activityInstanceId) {
              await Actions.fireNotificationEvent(context, {
                summary: 'Workflow Error',
                message: 'No active activity found in OPA instance.',
                type: 'warning',
                displayMode: 'transient',
              });
              return;
            }

            const auditResp = await Actions.callRest(context, {
              endpoint: 'OPA/getAuditInstancesInstanceIdActivitiesActivityInstanceId',
              uriParams: { instanceId, activityInstanceId },
              headers: { Authorization: $variables.opaAccessToken },
            });

            taskId = auditResp.body?.taskId;

            if (!taskId) {
              await Actions.fireNotificationEvent(context, {
                summary: 'Workflow Error',
                message: 'Task not ready in OPA for this PFR.',
                type: 'warning',
                displayMode: 'transient',
              });
              return;
            }

            // -----------------------
            // BUILD PAYLOAD & UPDATE OPA TASK
            const buildPayload = await $functions.buildPFROPAUpdateInstancesPayload($variables.temptableADP.data, $variables.reporting_period, $variables.pfrgenralInfo, $variables.pfrComment, $application.variables.userInfoObj.UserID, $variables.directSharedTableADP.data, $variables.indirectSharedADP.data, $variables.sharedCostTypeId || '', $variables.riskRatingLovValue, 'SUBMIT', $variables.indirectPartnerType, $variables.indirectPartnerPercentage, $application.variables.userRole, $variables.retainRunValidationVar, $variables.mode);


            const patchResp = await Actions.callRest(context, {
              endpoint: 'OPA/putTasksIdPayload',
              uriParams: { id: taskId },
              body: buildPayload,
              headers: { Authorization: $variables.opaAccessToken },
            });

            if (!patchResp.ok) {
              await Actions.fireNotificationEvent(context, {
                summary: 'OPA Error',
                message: 'Failed to update task payload in OPA.',
                type: 'error',
                displayMode: 'transient',
              });
              return;
            }

            const completeResp = await Actions.callRest(context, {
              endpoint: 'OPA/completeatask',
              uriParams: { id: taskId },
              body: { comment: 'Task completed successfully', outcome: buildPayload.inputRequest.pfr_status },
              headers: { Authorization: $variables.opaAccessToken },
            });

            const opaError =
              completeResp.body && (completeResp.body.errorCode || (completeResp.body.status && completeResp.body.status !== 200));

            if (opaError) {
              await Actions.fireNotificationEvent(context, {
                summary: 'PFR Submission Failed',
                message: completeResp.body.message,
                type: 'error',
                displayMode: 'transient',
              });
              await Actions.callRest(context, {
                endpoint: 'pfmGateway/putUpdateValidationstate',
                uriParams: {
                  doc_type: 'PFR',
                  draft_submission_status: 'DRAFT',
                  pfr_code: $variables.reporting_period.pfr_code,
                },
              });
              return;
            }
            else {
              // SUCCESS NOTIFICATION
              await Actions.fireNotificationEvent(context, {
                summary: 'Submit Successful',
                message: 'PFR submitted successfully.',
                type: 'confirmation',
                displayMode: 'persist',
              });
              if (draftSubmissionStatus.startsWith("DRAFT")) {
                await Actions.callChain(context, {
                  chain: 'draftStatusAssign',
                });

              }
              else
                if (draftSubmissionStatus.startsWith("SUBMIT")) {
                  await Actions.callChain(context, {
                    chain: 'statusAssign',
                  });
                }

              const results = await Promise.all([
                async () => {

                  await Actions.navigateToPage(context, { page: 'pfr-search' });
                },
                async () => {
                  if (buildPayload.inputRequest.pfr_status === 'Agreed') {
                    await Actions.callChain(context, {
                      chain: 'printPfrActionChain',
                      params: {
                        mode: 'SUBMIT',
                        status: buildPayload.inputRequest.pfr_status,
                        pfrCode: buildPayload.inputRequest.pfr_code,
                      },
                    });
                  }
                },
              ].map(sequence => sequence()));

            }

          } else {
            // NO ACTIVE INSTANCE
            if ($application.variables.userRole === 'PARTNER_USER' && $variables.pfr_Status === 'Proposed') {
              // CREATE INSTANCE INLINE
              const createPayload = await $functions.buildPFROPAPostInstancesPayload($variables.temptableADP.data, $variables.reporting_period, $variables.pfrgenralInfo, $variables.pfrComment, $application.variables.userInfoObj.UserID, $variables.directSharedTableADP.data, $variables.indirectSharedADP.data, $variables.sharedCostTypeId || '', $variables.riskRatingLovValue, 'SUBMIT', $variables.indirectPartnerType, $variables.indirectPartnerPercentage, $application.variables.userRole, $variables.retainRunValidationVar, $variables.mode);


              const createResp = await Actions.callRest(context, {
                endpoint: 'OPA/postInstances',
                body: createPayload,
                headers: { Authorization: $variables.opaAccessToken },
              });

              if (!createResp.ok) {
                await Actions.fireNotificationEvent(context, {
                  summary: 'OPA Instance Error',
                  message: 'Failed to create new OPA instance for PFR.',
                  type: 'error',
                  displayMode: 'transient',
                });
                return;
              } else {
                // SUCCESS NOTIFICATION
                await Actions.fireNotificationEvent(context, {
                  summary: 'Submit Successful',
                  message: 'PFR submitted successfully.',
                  type: 'confirmation',
                  displayMode: 'persist',
                });
                if (draftSubmissionStatus.startsWith("DRAFT")) {
                  await Actions.callChain(context, {
                    chain: 'draftStatusAssign',
                  });

                }
                else
                  if (draftSubmissionStatus.startsWith("SUBMIT")) {
                    await Actions.callChain(context, {
                      chain: 'statusAssign',
                    });
                  }

                await Actions.navigateToPage(context, { page: 'pfr-search' });
              }
            } else {
              await Actions.fireNotificationEvent(context, {
                summary: 'Submit Failed',
                message: 'No Active Instance Found. Please check the status',
                type: 'error',
                displayMode: 'transient',
              });
              await Actions.callRest(context, {
                endpoint: 'pfmGateway/putUpdateValidationstate',
                uriParams: {
                  doc_type: 'PFR',
                  draft_submission_status: 'DRAFT',
                  pfr_code: $variables.reporting_period.pfr_code,
                },
              });
              return;
            }
          }
        }



      } catch (e) {
        await Actions.fireNotificationEvent(context, {
          summary: 'System Error',
          message: 'An unexpected error occurred while submitting the PFR.',
          type: 'error',
          displayMode: 'transient',
        });
        console.error(e);
        await Actions.callRest(context, {
          endpoint: 'pfmGateway/putUpdateValidationstate',
          uriParams: {
            doc_type: 'PFR',
            draft_submission_status: 'DRAFT',
            pfr_code: $variables.reporting_period.pfr_code,
          },
        });
        return;
      } finally {
        await Actions.callComponentMethod(context, { selector: '#progressbar', method: 'close' });
      }
    }
  }

  return onClickSubmitPFR;
});
