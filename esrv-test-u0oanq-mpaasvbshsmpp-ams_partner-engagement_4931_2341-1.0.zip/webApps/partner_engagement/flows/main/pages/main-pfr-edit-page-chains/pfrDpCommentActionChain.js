define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class pfrDpCommentActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     * @param {any} params.key
     * @param {number} params.index
     * @param {any} params.current
     */
    async run(context, { event, originalEvent, key, index, current }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const separateDppfrCommentIds = await $functions.separateDppfrCommentIds(key);

      $variables.dppfrCommentsObj.accountId = separateDppfrCommentIds.accountid;
      $variables.dppfrCommentsObj.locationId = separateDppfrCommentIds.locationid;
      $variables.dppfrCommentsObj.outputId = separateDppfrCommentIds.outputid;

      const dppfrcommentHistoryDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#dppfrcommentHistoryDialog',
        method: 'open',
      });
    }
  }

  return pfrDpCommentActionChain;
});
