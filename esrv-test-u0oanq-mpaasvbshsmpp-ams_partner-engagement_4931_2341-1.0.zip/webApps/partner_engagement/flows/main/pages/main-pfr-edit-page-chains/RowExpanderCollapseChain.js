define(['vb/action/actionChain'], (ActionChain) => {
  'use strict';

  class RowExpanderCollapseChain extends ActionChain {
    async run(context, { rowKey }) {
      const { $variables } = context;
      if (!rowKey) return;

      let expandedKeys = Array.isArray($variables.expandedKeys)
        ? [...$variables.expandedKeys]
        : [];

      // Remove the collapsed row key
      expandedKeys = expandedKeys.filter(k => k !== rowKey);

      // Update the user-expanded keys (don't overwrite programmatic ones)
      $variables.expandedKeys = expandedKeys;

      console.log('Row collapsed, updated expandedKeys:', expandedKeys);
    }
  }

  return RowExpanderCollapseChain;
});