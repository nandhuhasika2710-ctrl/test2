define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ExportDataDataChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.previousValue
     * @param {any} params.value
     * @param {string} params.updatedFrom
     * @param {any} params.data
     */
    async run(context, { event, previousValue, value, updatedFrom, data }) {
      const { $page, $flow, $application, $constants, $variables } = context;
       const response4 = await Actions.callRest(context, {
               endpoint: 'pfmGateway/getPfrChangelog2',
               uriParams: {
                 'p_pfr_id': $variables.p_pfr_Id,
               },
             });
             $variables.changeLogPfrExportADP.data = response4?.body?.items || [];
            
    }
  }

  return ExportDataDataChangeChain;
});
