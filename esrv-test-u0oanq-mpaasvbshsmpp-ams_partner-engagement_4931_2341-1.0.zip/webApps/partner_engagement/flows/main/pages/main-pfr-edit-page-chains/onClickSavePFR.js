define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
  'ojs/ojarraytreedataprovider',
  'ojs/ojflattenedtreedataproviderview',
], (
  ActionChain,
  Actions,
  ActionUtils,
  ArrayTreeDataProvider,
  FlattenedTreeDataProviderView
) => {
  'use strict';

  class onClickSavePFR extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      // Open progress bar to show the user we're working
      await Actions.callComponentMethod(context, {
        selector: '#progressbar',
        method: 'open',
      });

      try {
        // Step 1: Extract data for validation and payload preparation
        const tempData = $variables.temptableADP?.data || [];
        const pfrData = tempData[0]?.pfr || {};
        const directShared = pfrData.direct_shared?.[0];
        const indirectSupport = pfrData.indirect_support?.[0];

        const pfr_ds_id = directShared?.pfr_ds_id || '';
        const pfr_isc_id = indirectSupport?.pfr_isc_id || '';

        // Step 2: Validate FPN data
        const validateFpnData = await $functions.validateFpnData(
          pfrData,
          $variables.pfrComment,
          $variables.reporting_period.pfr_type,
          $variables.directSharedTableADP.data,
          $variables.indirectSharedADP.data
        );

        if (!validateFpnData.valid) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Validation Failed',
            message: validateFpnData.message,
            displayMode: 'transient',
            type: 'error',
          });

          return;
        }

        // Check if the reporting period is valid
        if ($variables.reportingperiodValidation !== 'valid') {
          await Actions.fireNotificationEvent(context, {
            summary: 'Please check mandatory fields in Reporting period section before saving.',
            displayMode: 'transient',
            type: 'error',
          });
          return;
        }

        // Step 3: Prepare PFR payload
        const PFRpaylod = await $functions.createPayloadForPFR($variables.temptableADP.data, $variables.reporting_period, $variables.pfrgenralInfo, $variables.pfrComment, $application.variables.userInfoObj.UserID, $variables.directSharedTableADP.data, $variables.indirectSharedADP.data, $variables.sharedCostTypeId, $variables.riskRatingTypeId, 'DRAFT', $variables.indirectPartnerType, $variables.indirectPartnerPercentage, $application.variables.userRole, $variables.retainRunValidationVar, $variables.mode);

        // Step 4: Call recalculate API
        const recalculateResponse = await Actions.callRest(context, {
          endpoint: 'OICService/postPfrActionRecalculatePFR2',
          body: PFRpaylod,
        });

        if (recalculateResponse.body.Status.toUpperCase() !== 'SUCCESS') {
          await Actions.fireNotificationEvent(context, {
            summary: 'PFR Recalculate Failed',
            message: recalculateResponse.body.StatusMessage,
            type: 'error',
            displayMode: 'transient',
          });
          return;
        }
        // const recalculateResponse = await Actions.callRest(context, {
        //   endpoint: 'pfmGateway/postPfrRecalculate',
        //   body: PFRpaylod,
        // });

        // if (recalculateResponse.status !== 200) {
        //   await Actions.fireNotificationEvent(context, {
        //     summary: 'Recalculate Failed',
        //     displayMode: 'transient',
        //     type: 'error',
        //   });

        //   return;
        // }
        // Step 5: Create PFR

        // const response2 = await Actions.callRest(context, {
        //   endpoint: 'pfmGateway/postPFR',
        //   body: recalculateResponse.body,
        // });

        const response2 = await Actions.callRest(context, {
          endpoint: 'OICService/postPfrActionCreatePFR',
          body: recalculateResponse.body,
        });

        if (response2.body.Status !== '201') {
          // const statusCode = String(response2?.body?.status_code || response2?.status);
          // if (statusCode !== '201') {
          await Actions.fireNotificationEvent(context, {
            summary: 'PFR Save Failed',
            message: response2.body.StatusMessage,
            type: 'error',
            displayMode: 'transient',
          });
          await Actions.callRest(context, {
            endpoint: 'pfmGateway/putUpdateValidationstate',
            uriParams: {
              doc_type: 'PFR',
              draft_submission_status: 'DRAFT',
              pfr_code: $variables.reporting_period.pfr_code,
            },
          });



          return;
        } else {
          const pfr_code = response2.body.StatusMessage;
          // const pfr_code = response2.body.responsemessage;

          // Step 6: Handle success responses and update variables
          const results = await Promise.all([
            async () => {
              const response = await Actions.callRest(context, {
                endpoint: 'OICService/getPFR',
                uriParams: {
                  'p_pfr_code': pfr_code,
                },
              });

              // const response = await Actions.callRest(context, {
              //   endpoint: 'pfmGateway/getPfrHeaderdetails',
              //   uriParams: {
              //     'p_pfr_code': pfr_code,
              //   },
              // });

              if (!response.ok) {
                await Actions.fireNotificationEvent(context, {
                  summary: 'Failed to Retrieve PFR Data',
                  message: `Error: ${response.statusText}`,
                  type: 'warning',
                  displayMode: 'transient',
                });
              }
              const response21 = await Actions.callRest(context, {
                endpoint: 'pfmGateway/putUpdateValidationstate',
                uriParams: {
                  'doc_type': 'PFR',
                  'validation_state': $variables.retainRunValidationVar,
                  'pfr_code': response.body.items[0].pfr.pfr_code,
                  'draft_submission_status': 'DRAFT',
                },
              });
              // Process response data
              const items = response.body.items[0];
              const pfr = items?.pfr || {};
              $variables.pfr_Status = response.body.items[0].pfr.pfr_status;
              const editPFRPayloadWithIds = await $functions.editPFRPayloadWithIds(response.body.items);
              const testCode = await $functions.testCode(editPFRPayloadWithIds);
              $variables.reporting_period.pfr_code = response.body.items[0].pfr.reporting_period[0].pfr_code;
              $variables.reporting_period.pfr_type = response.body.items[0].pfr.reporting_period[0].pfr_type;
              $variables.reporting_period.reporting_period_start_date = response.body.items[0].pfr.reporting_period[0].reporting_period_start_date;
              $variables.reporting_period.reporting_period_end_date = response.body.items[0].pfr.reporting_period[0].reporting_period_end_date;
              $variables.testVariable = testCode;
              $variables.temptableADP.data = testCode;
              $variables.tempdirectSharedArray = $variables.testVariable[0].pfr.direct_shared || [];
              $variables.headerStatusValue = response.body.items[0].pfr.pfr_status || '';
              $variables.directSharedTableADP.data = $variables.tempdirectSharedArray;
              $variables.indirectSharedArray = $variables.testVariable[0].pfr.indirect_support || [];
              $variables.indirectSharedADP.data = $variables.indirectSharedArray;
              $variables.pfrComment = $variables.testVariable[0].pfr.pfr_comments || '';
              $variables.fpnCode = $variables.testVariable[0].pfr.fpn_code || '';
              $variables.sharedCostLovValue = response?.body?.items?.[0]?.pfr?.indirect_support?.[0]?.shared_cost || '';
              let draftSubmissionStatus = response.body.items[0].pfr.draft_submission_status;
              let budgetFlexibility = response.body.items[0].pfr.budget_flexibility;

              // if (draftSubmissionStatus) {

              //   if (draftSubmissionStatus.startsWith("DRAFT-") || draftSubmissionStatus.startsWith("SUBMIT-")) {
              //     let percentageValue = draftSubmissionStatus.split('-')[1];
              //     budgetFlexibility = percentageValue + '%';
              //   }
              // } 
              const tree = await $functions.convertArrayIntoTree($variables.temptableADP.data);
              const arrayTreeDP = new ArrayTreeDataProvider(tree, { keyAttributes: 'id' });
              $variables.arrayTreeDP = arrayTreeDP;
              $variables.dataSource = new FlattenedTreeDataProviderView($variables.arrayTreeDP);
              $variables.pfrgenralInfo.operation = pfr.operation_name;
              $variables.pfrgenralInfo.budgetYear = pfr.budget_year;
              $variables.pfrgenralInfo.contractCurrency = pfr.contract_currency_code;
              $variables.pfrgenralInfo.toataloriginalbudget = pfr.total_original_budget;
              $variables.pfrgenralInfo.partnerName = pfr.partner_name;
              $variables.pfrgenralInfo.partnerERPSite = pfr.partner_site_code;
              $variables.pfrgenralInfo.contractNumber = pfr.contract_number;
              $variables.pfrgenralInfo.totalDirectProgramme = pfr.total_direct_programme_cost;
              $variables.pfrgenralInfo.totalNegotiatedBudget = pfr.total_negotiated_budget;
              $variables.pfrgenralInfo.totalDirectShared = pfr.total_direct_shared_cost;
              $variables.pfrgenralInfo.totalIndirectSupportCost = pfr.total_indirect_support_cost;
              $variables.pfrgenralInfo.totalPFRExpenses = pfr.total_pfr_expenses;
              $variables.pfrgenralInfo.costCenter = pfr.cost_center;
              $variables.pfrgenralInfo.costCenterName = pfr.cost_center_name;
              $variables.pfrgenralInfo.poNumber = pfr.po_number;
              $variables.pfrgenralInfo.operationCode = pfr.operation_code;
              $variables.pfrgenralInfo.partnerNumber = pfr.partner_number;
              if (draftSubmissionStatus.startsWith("DRAFT")) {
                await Actions.callChain(context, {
                  chain: 'draftStatusAssign',
                });

              }
              else
                if (draftSubmissionStatus.startsWith("SUBMIT")) {
                  await Actions.callChain(context, {
                    chain: 'statusAssign',
                  });
                }
              $variables.disableSubmitButton = true;
              $variables.retainRunValidationVar = 'N';
              $variables.validationColor = 'runvalidation_orange';
            },
            async () => {
              const response4 = await Actions.callRest(context, {
                endpoint: 'pfmGateway/getPfrChangelog2',
                uriParams: {
                  'p_pfr_code': pfr_code,
                },
              });

              $variables.changeLogPfrExportADP.data = response4.body.items || [];
            },
          ].map(sequence => sequence()));

          // Step 7: Show success message

          await Actions.fireNotificationEvent(context, {
            summary: 'PFR Saved Successfully',
            displayMode: 'persist',
            type: 'confirmation',
          });

        }



      } catch (error) {
        console.error('Unexpected error during PFR save:', error);
        await Actions.fireNotificationEvent(context, {
          summary: 'Unexpected Error',
          message: 'An unexpected error occurred. Please try again.',
          type: 'error',
        });
      } finally {

        // Close the progress bar regardless of success or failure
        await Actions.callComponentMethod(context, {
          selector: '#progressbar',
          method: 'close',
        });
      }
    }
  }

  return onClickSavePFR;
});
