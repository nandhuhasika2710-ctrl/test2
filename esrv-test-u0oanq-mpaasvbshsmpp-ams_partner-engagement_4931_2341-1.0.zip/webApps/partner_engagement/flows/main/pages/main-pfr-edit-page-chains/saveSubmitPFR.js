define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
  'ojs/ojarraytreedataprovider',
  'ojs/ojflattenedtreedataproviderview',
], (
  ActionChain,
  Actions,
  ActionUtils,
  ArrayTreeDataProvider,
  FlattenedTreeDataProviderView
) => {
  'use strict';

  class saveSubmitPFR extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
        await Actions.callComponentMethod(context, {
        selector: '#progressbar',
        method: 'open',
      });

      try {
        // Step 1: Extract data for validation and payload preparation
        const tempData = $variables.temptableADP?.data || [];
        const pfrData = tempData[0]?.pfr || {};
        const directShared = pfrData.direct_shared?.[0];
        const indirectSupport = pfrData.indirect_support?.[0];

        const pfr_ds_id = directShared?.pfr_ds_id || '';
        const pfr_isc_id = indirectSupport?.pfr_isc_id || '';

        // Step 2: Validate FPN data
        const validateFpnData = await $functions.validateFpnData(
          pfrData,
          $variables.pfrComment,
          $variables.reporting_period.pfr_type,
          $variables.directSharedTableADP.data,
          $variables.indirectSharedADP.data
        );

        if (!validateFpnData.valid) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Validation Failed',
            message: validateFpnData.message,
            displayMode: 'transient',
            type: 'error',
          });

          return;
        }

        // Check if the reporting period is valid
        if ($variables.reportingperiodValidation !== 'valid') {
          await Actions.fireNotificationEvent(context, {
            summary: 'Please check mandatory fields in Reporting period section before saving.',
            displayMode: 'transient',
            type: 'error',
          });
          return;
        }

        // Step 3: Prepare PFR payload
        const PFRpaylod = await $functions.createPayloadForPFR($variables.temptableADP.data, $variables.reporting_period, $variables.pfrgenralInfo, $variables.pfrComment, $application.variables.userInfoObj.UserID, $variables.directSharedTableADP.data, $variables.indirectSharedADP.data, $variables.sharedCostLovValue, $variables.riskRatingLovValue, 'DRAFT');

        // Step 4: Call recalculate API
        const recalculateResponse = await Actions.callRest(context, {
          endpoint: 'OICService/postPfrActionRecalculatePFR2',
          body: PFRpaylod,
        });

        if (recalculateResponse.body.Status.toUpperCase() !== 'SUCCESS') {
          await Actions.fireNotificationEvent(context, {
            summary: 'PFR Recalculate Failed',
            message: recalculateResponse.body.StatusMessage,
            type: 'error',
            displayMode: 'transient',
          });
          return;
        }

        // Step 5: Create PFR
        const response2 = await Actions.callRest(context, {
          endpoint: 'OICService/postPfrActionCreatePFR',
          body: recalculateResponse.body,
        });

        if (response2.body.Status !== '201') {
          await Actions.fireNotificationEvent(context, {
            summary: 'PFR Save Failed',
            message: response2.body.StatusMessage,
            type: 'error',
            displayMode: 'transient',
          });
          return;
        }



        // Step 6: Handle success responses and update variables
        const results = await Promise.all([
          async () => {
            const response = await Actions.callRest(context, {
              endpoint: 'OICService/getPFR',
              uriParams: { 'p_pfr_id': $variables.p_pfr_Id },
            });

            if (!response.ok) {
              await Actions.fireNotificationEvent(context, {
                summary: 'Failed to Retrieve PFR Data',
                message: `Error: ${response.statusText}`,
                type: 'warning',
                displayMode: 'transient',
              });
            }

            // Process response data
            $variables.pfr_Status = response.body.items[0].pfr.pfr_status;
            await Actions.callChain(context, { chain: 'statusAssign' });
        const testCode = await $functions.testCode(response.body.items);
        $variables.reporting_period.pfr_code = response.body.items[0].pfr.reporting_period[0].pfr_code;
        $variables.reporting_period.pfr_type = response.body.items[0].pfr.reporting_period[0].pfr_type;
        $variables.reporting_period.reporting_period_start_date = response.body.items[0].pfr.reporting_period[0].reporting_period_start_date;
        $variables.reporting_period.reporting_period_end_date = response.body.items[0].pfr.reporting_period[0].reporting_period_end_date;
        $variables.testVariable = testCode;
        $variables.temptableADP.data = testCode;
        $variables.tempdirectSharedArray = $variables.testVariable[0].pfr.direct_shared || [];
        $variables.directSharedTableADP.data = $variables.tempdirectSharedArray;
        $variables.indirectSharedArray = $variables.testVariable[0].pfr.indirect_support || [];
        $variables.indirectSharedADP.data = $variables.indirectSharedArray;
        $variables.pfrComment = $variables.testVariable[0].pfr.pfr_comments || '';
        $variables.fpnId = $variables.testVariable[0].pfr.fpn_id || '';
        $variables.sharedCostLovValue = response?.body?.items?.[0]?.pfr?.indirect_support?.[0]?.shared_cost || '';
        $variables.riskRatingLovValue = $variables.testVariable[0].pfr.budget_flexibility === '0%' ? '' : $variables.testVariable[0].pfr.budget_flexibility || '';
            const tree = await $functions.convertArrayIntoTree($variables.temptableADP.data);
            const arrayTreeDP = new ArrayTreeDataProvider(tree, { keyAttributes: 'id' });
            $variables.arrayTreeDP = arrayTreeDP;
            $variables.dataSource = new FlattenedTreeDataProviderView($variables.arrayTreeDP);
        //      $variables.pfrgenralInfo.operation = response.body.items[0].pfr.operation_name;
        // $variables.pfrgenralInfo.budgetYear = response.body.items[0].pfr.budget_year;
        // $variables.pfrgenralInfo.contractCurrency = response.body.items[0].pfr.contract_currency_code;
        // $variables.pfrgenralInfo.toataloriginalbudget = response.body.items[0].pfr.total_original_budget;
        // $variables.pfrgenralInfo.partnerName = response.body.items[0].pfr.partner_name;
        // $variables.pfrgenralInfo.partnerERPSite = response.body.items[0].pfr.partner_site_code;
        // $variables.pfrgenralInfo.contractNumber = response.body.items[0].pfr.contract_number;
        // $variables.pfrgenralInfo.totalDirectProgramme = response.body.items[0].pfr.total_direct_programme_cost;
        // $variables.pfrgenralInfo.totalNegotiatedBudget = response.body.items[0].pfr.total_negotiated_budget;
        // $variables.pfrgenralInfo.totalDirectShared = response.body.items[0].pfr.total_direct_shared_cost;
        // $variables.pfrgenralInfo.totalIndirectSupportCost = response.body.items[0].pfr.total_indirect_support_cost;
        $variables.pfrgenralInfo.totalPFRExpenses = response.body.items[0].pfr.total_pfr_expenses;
          },
          async () => {
            const response4 = await Actions.callRest(context, {
              endpoint: 'pfmGateway/getPfrChangelog2',
              uriParams: { 'p_pfr_id': $variables.p_pfr_Id },
            });

            if (!response4.ok) {
              await Actions.fireNotificationEvent(context, {
                summary: 'Failed to Retrieve Change Log',
                type: 'warning',
                displayMode: 'transient',
              });
            }

            $variables.changeLogPfrExportADP.data = response4.body.items || [];
          },
          async () => {
            const response3 = await Actions.callRest(context, {
              endpoint: 'OICService/getRetrieve',
              uriParams: { fpnCode: $variables.fpnId },
            });

            if (!response3.ok) {
              await Actions.fireNotificationEvent(context, {
                summary: 'Failed to Retrieve FPN Data',
                message: `Error: ${response3.statusText}`,
                type: 'warning',
                displayMode: 'transient',
              });
            }

            $variables.fpnCode = response3.body.items[0].fpn.fpn_code;
          },
        ].map(sequence => sequence()));

        // Step 7: Show success message
        await Actions.fireNotificationEvent(context, {
          summary: 'PFR Saved Successfully',
          displayMode: 'persist',
          type: 'confirmation',
        });

      } catch (error) {
        console.error('Unexpected error during PFR save:', error);
        await Actions.fireNotificationEvent(context, {
          summary: 'Unexpected Error',
          message: 'An unexpected error occurred. Please try again.',
          type: 'error',
        });
      } finally {
        // Close the progress bar regardless of success or failure
        await Actions.callComponentMethod(context, {
          selector: '#progressbar',
          method: 'close',
        });
      }
    }
  }

  return saveSubmitPFR;
});
