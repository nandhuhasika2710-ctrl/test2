define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class directSharedTableBeforeRowEditEndChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.cancelEdit 
     * @param {any} params.rowKey 
     * @param {number} params.rowIndex 
     * @param {any} params.rowData 
     */
    async run(context, { cancelEdit, rowKey, rowIndex, rowData }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

if ($variables.directSharedCurrentRow.account_line_status === 'Draft') {
        $variables.directSharedCurrentRow.account_line_status = 'Proposed';
      }
      const dsupdateAdpData = await $functions.dsupdateAdpData($variables.directSharedTableADP, $variables.directSharedCurrentRow);
 console.log("dsupdateAdpData"+JSON.stringify($variables.directSharedTableADP.data));
      console.log("dsupdateAdpData"+JSON.stringify($variables.directSharedCurrentRow));

      $variables.directSharedTableADP.data = dsupdateAdpData;
    }
  }

  return directSharedTableBeforeRowEditEndChain;
});
